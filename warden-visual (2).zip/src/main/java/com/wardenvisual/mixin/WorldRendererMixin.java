package com.wardenvisual.mixin;

import com.wardenvisual.Diag;
import com.wardenvisual.Features;
import com.wardenvisual.View;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.WorldRenderer;
import net.minecraft.client.world.ClientWorld;
import org.joml.Matrix4f;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Captures the real view/projection matrices (exact ESP) and applies Time Warp every frame. */
@Mixin(WorldRenderer.class)
public abstract class WorldRendererMixin {
    @ModifyVariable(method = "render", at = @At("HEAD"), argsOnly = true, ordinal = 0, require = 0)
    private Matrix4f wardenvisual$m0(Matrix4f m) {
        View.feed(m);
        Diag.view++;
        return m;
    }

    @ModifyVariable(method = "render", at = @At("HEAD"), argsOnly = true, ordinal = 1, require = 0)
    private Matrix4f wardenvisual$m1(Matrix4f m) {
        View.feed(m);
        return m;
    }

    @ModifyVariable(method = "render", at = @At("HEAD"), argsOnly = true, ordinal = 2, require = 0)
    private Matrix4f wardenvisual$m2(Matrix4f m) {
        View.feed(m);
        return m;
    }

    @Inject(method = "render", at = @At("HEAD"), require = 0)
    private void wardenvisual$time(CallbackInfo ci) {
        if (!Features.TIME.on) return;
        ClientWorld w = MinecraftClient.getInstance().world;
        if (w == null) return;
        w.setTime(w.getTime(), Features.TIME.v("t"), false);
        Diag.time++;
    }
}
