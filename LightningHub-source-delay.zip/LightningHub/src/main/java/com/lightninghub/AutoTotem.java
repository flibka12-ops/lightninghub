package com.lightninghub;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.screen.slot.SlotActionType;

/** Авто-тотем: если во второй руке нет тотема бессмертия, берёт его из инвентаря. */
public final class AutoTotem {
	private static int cooldown = 0;

	public static void tick(MinecraftClient mc) {
		if (!Config.S.autoTotem) return;

		ClientPlayerEntity p = mc.player;
		if (p == null || mc.interactionManager == null || mc.currentScreen != null) return;

		if (cooldown > 0) {
			cooldown--;
			return;
		}
		if (p.getOffHandStack().isOf(Items.TOTEM_OF_UNDYING)) return;

		// Слоты инвентаря игрока: 9-35 основной, 36-44 хотбар (45 - вторая рука).
		for (int slot = 9; slot <= 44; slot++) {
			ItemStack st = p.playerScreenHandler.getSlot(slot).getStack();
			if (st.isOf(Items.TOTEM_OF_UNDYING)) {
				// SWAP с кнопкой 40 = обмен слота со второй рукой.
				mc.interactionManager.clickSlot(p.playerScreenHandler.syncId, slot, 40, SlotActionType.SWAP, p);
				cooldown = 6;
				return;
			}
		}
	}

	private AutoTotem() {
	}
}
