package com.wardenvisual;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Function;

/** Warden-themed menu with gear panels. Mouse and keys are polled via GLFW (works with touch-as-mouse). */
public class WardenMenuScreen extends Screen {
    public static boolean capturing = false;

    private static final int ROW_H = 30;
    private static final int GAP = 6;
    private static final int[] VALID_KEYS = buildKeys();

    private static final class Item {
        Feature f;
        String label;
        Runnable action;
        boolean info;
        int h = ROW_H, x, y, w;
    }

    private int tab = 0;
    private double scrollMain = 0, scrollSide = 0;
    private boolean wasDown = true; // ignore the click that opened the menu
    private String active = null;
    private Feature sel = null;
    private float sideAnim = 0f;
    private final Map<String, Float> anim = new HashMap<>();
    private List<Item> items = new ArrayList<>();

    // key capture
    private boolean cap = false;
    private Feature capF = null;
    private final List<Integer> capKeys = new ArrayList<>();
    private boolean capSawAny = false;

    // per-frame input state
    private int mx, my;
    private boolean down, pressed;
    private int clipX1, clipY1, clipX2, clipY2;
    private boolean blocked;

    public WardenMenuScreen() {
        super(Text.literal("Warden Visual"));
        rebuild();
    }

    private static int[] buildKeys() {
        List<Integer> l = new ArrayList<>();
        l.add(GLFW.GLFW_KEY_SPACE);
        l.add(GLFW.GLFW_KEY_APOSTROPHE);
        for (int k = 44; k <= 57; k++) l.add(k);
        l.add(59);
        l.add(61);
        for (int k = 65; k <= 93; k++) l.add(k);
        l.add(96);
        for (int k = 257; k <= 269; k++) l.add(k);
        for (int k = 280; k <= 284; k++) l.add(k);
        for (int k = 290; k <= 314; k++) l.add(k);
        for (int k = 320; k <= 336; k++) l.add(k);
        for (int k = 340; k <= 348; k++) l.add(k);
        int[] a = new int[l.size()];
        for (int i = 0; i < a.length; i++) a[i] = l.get(i);
        return a;
    }

    private void rebuild() {
        items = new ArrayList<>();
        scrollMain = 0;
        String name = Features.TABS[tab];
        for (Feature f : Features.tab(name)) {
            Item it = new Item();
            it.f = f;
            items.add(it);
        }
        if (name.equals("MISC")) {
            Item reset = new Item();
            reset.label = "Reset all settings";
            reset.action = () -> {
                Features.resetAll();
                sel = null;
            };
            items.add(reset);
            Item info = new Item();
            info.info = true;
            info.h = 112;
            items.add(info);
        }
    }

    @Override
    public boolean shouldPause() {
        return false;
    }

    @Override
    public boolean shouldCloseOnEsc() {
        return !cap;
    }

    @Override
    public void removed() {
        capturing = false;
        Features.save();
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        if (sel != null && sideAnim > 0.5f && mouseX >= sideX) scrollSide -= verticalAmount * 16;
        else scrollMain -= verticalAmount * 16;
        return true;
    }

    private int sideX = 100000;

    private static String clockText(int ticks) {
        int minutes = (int) (((ticks / 1000.0) + 6.0) % 24.0 * 60.0);
        return String.format("%02d:%02d", minutes / 60, minutes % 60);
    }

    private static int timeColor(float f) {
        int[] stops = {0xFFF2A65A, 0xFF74C7F2, 0xFF74C7F2, 0xFFE8743B, 0xFF11182B, 0xFF11182B, 0xFFF2A65A};
        float p = f * (stops.length - 1);
        int i = Math.min(stops.length - 2, (int) p);
        return Ui.lerp(stops[i], stops[i + 1], p - i);
    }

    private boolean hov(int x, int y, int w, int h) {
        if (blocked) return false;
        if (mx < clipX1 || mx >= clipX2 || my < clipY1 || my >= clipY2) return false;
        return mx >= x && mx < x + w && my >= y && my < y + h;
    }

    // ------------------------------------------------------------------ render

    @Override
    public void render(DrawContext ctx, int rawMx, int rawMy, float delta) {
        MinecraftClient mc = MinecraftClient.getInstance();
        long handle = mc.getWindow().getHandle();
        down = GLFW.glfwGetMouseButton(handle, GLFW.GLFW_MOUSE_BUTTON_LEFT) == GLFW.GLFW_PRESS;
        pressed = down && !wasDown;
        wasDown = down;
        mx = rawMx;
        my = rawMy;
        double t = System.currentTimeMillis() / 1000.0;

        if (!down && active != null) {
            active = null;
            Features.save();
        }
        updateCapture(handle);
        capturing = cap;

        // ---- background ----
        ctx.fill(0, 0, width, height, 0xB0030A0D);
        ctx.fillGradient(0, height / 2, width, height, 0x00000000, 0x4021D6C4);
        for (int i = 0; i < 26; i++) {
            double sx = Math.abs((Math.sin(i * 91.3) * 437.5) % 1.0);
            double sy = Math.abs((Math.sin(i * 17.7) * 931.1) % 1.0);
            double speed = 4 + 8 * Math.abs((Math.sin(i * 3.3) * 77.7) % 1.0);
            int x = (int) (sx * width);
            int y = (int) (height - ((t * speed + sy * height) % height));
            int al = 30 + (int) (50 * (0.5 + 0.5 * Math.sin(t * 2 + i)));
            ctx.fill(x, y, x + 2, y + 2, Ui.a(0x21D6C4, al));
        }

        // ---- layout ----
        boolean open = sel != null;
        sideAnim += ((open ? 1f : 0f) - sideAnim) * 0.25f;
        if (Math.abs(sideAnim - (open ? 1f : 0f)) < 0.01f) sideAnim = open ? 1f : 0f;

        int pw = Math.min(width - 16, 430);
        int ph = Math.min(height - 78, 248);
        int sw = Math.min(210, Math.max(150, width - 16));
        boolean overlay = pw + sw + 20 > width;
        int total = overlay ? pw : pw + (int) (sideAnim * (sw + 8));
        int px = (width - total) / 2;
        int py = (height - ph) / 2 - 6;
        int sxFull = overlay ? px + pw - sw : px + pw + 8;
        int sxStart = overlay ? width : px + pw - sw; // behind main when sliding out
        sideX = (int) (sxStart + (sxFull - sxStart) * sideAnim);
        boolean sideVisible = sideAnim > 0.02f;
        blocked = false;

        // side panel (drawn first so it slides out from behind the main panel)
        boolean mouseInSide = sideVisible && open && mx >= sideX && mx < sideX + sw && my >= py && my < py + ph;
        if (sideVisible) {
            drawSide(ctx, sideX, py, sw, ph, mouseInSide);
        }

        // main panel
        int glow = 70 + (int) (40 * Math.sin(t * 2));
        Ui.round(ctx, px - 1, py - 1, px + pw + 1, py + ph + 1, 9, Ui.a(0x21D6C4, glow));
        Ui.round(ctx, px, py, px + pw, py + ph, 8, Ui.BG);

        // header
        Ui.bold(ctx, "WARDEN VISUAL", px + 36, py + 11, Ui.TEXT);
        int lx = px + 12, ly = py + 18;
        int lc = Ui.a(0x21D6C4, 190 + (int) (65 * Math.sin(t * 3)));
        int[][] pl = {{0, 0}, {5, 0}, {8, -6}, {11, 6}, {14, -3}, {17, 0}, {20, 0}};
        for (int i = 0; i < pl.length - 1; i++) {
            Ui.line(ctx, lx + pl[i][0], ly + pl[i][1], lx + pl[i + 1][0], ly + pl[i + 1][1], lc, 1.5f);
        }
        String crumb = Features.TABS[tab];
        Ui.textR(ctx, crumb, px + pw - 14, py + 12, Ui.ACCENT);
        String hint = "Menu: " + Features.MENU.bind.label() + "  |  /warden";
        Ui.textR(ctx, hint, px + pw - 14 - Ui.w(crumb) - 14, py + 12, Ui.DIM);
        ctx.fill(px + 12, py + 31, px + pw - 12, py + 32, Ui.a(0x21D6C4, 0x38));

        // content area
        int cx1 = px + 12, cx2 = px + pw - 12, cy1 = py + 38, cy2 = py + ph - 8;
        int cw = (cx2 - cx1 - 8) / 2;
        int[] colY = {0, 0};
        for (Item it : items) {
            if (it.info || it.action != null) {
                int y = Math.max(colY[0], colY[1]);
                it.x = cx1;
                it.w = cx2 - cx1;
                it.y = y;
                colY[0] = colY[1] = y + it.h + GAP;
            } else {
                int col = colY[0] <= colY[1] ? 0 : 1;
                it.x = cx1 + col * (cw + 8);
                it.w = cw;
                it.y = colY[col];
                colY[col] += it.h + GAP;
            }
        }
        int contentH = Math.max(colY[0], colY[1]);
        int viewH = cy2 - cy1;
        double maxScroll = Math.max(0, contentH - viewH);
        scrollMain = Math.max(0, Math.min(maxScroll, scrollMain));

        blocked = mouseInSide;
        clipX1 = cx1;
        clipY1 = cy1;
        clipX2 = cx2;
        clipY2 = cy2;
        ctx.enableScissor(cx1, cy1, cx2, cy2);
        for (Item it : items) {
            int y = cy1 + it.y - (int) scrollMain;
            if (y + it.h < cy1 || y > cy2) continue;
            drawItem(ctx, it, it.x, y, it.w);
        }
        ctx.disableScissor();
        if (maxScroll > 0) {
            int sbH = Math.max(12, (int) (viewH * (viewH / (double) contentH)));
            int sbY = cy1 + (int) ((viewH - sbH) * (scrollMain / maxScroll));
            ctx.fill(cx2 + 3, sbY, cx2 + 5, sbY + sbH, Ui.a(0x21D6C4, 0xAA));
        }

        // ---- tabs ----
        int tabW = 62, tabH = 22, tabGap = 8;
        int n = Features.TABS.length + 1;
        int tw = n * tabW + (n - 1) * tabGap;
        int tbx = (width - tw) / 2;
        int tby = py + ph + 10;
        blocked = false;
        for (int i = 0; i < n; i++) {
            int x = tbx + i * (tabW + tabGap);
            boolean isClose = i == Features.TABS.length;
            boolean hover = mx >= x && mx < x + tabW && my >= tby && my < tby + tabH;
            boolean selTab = !isClose && i == tab;
            int bg = selTab ? Ui.ACCENT : (isClose ? (hover ? 0xFF7A2634 : 0xFF4A1A24) : (hover ? Ui.CARD_HOVER : Ui.CARD));
            Ui.round(ctx, x, tby, x + tabW, tby + tabH, 8, bg);
            String label = isClose ? "CLOSE" : Features.TABS[i];
            Ui.textC(ctx, label, x + tabW / 2, tby + 7, selTab ? 0xFF04161A : Ui.TEXT);
            if (pressed && hover) {
                if (isClose) {
                    close();
                    return;
                }
                if (tab != i) {
                    tab = i;
                    sel = null;
                    rebuild();
                }
                return;
            }
        }
    }

    // ------------------------------------------------------------------ widgets

    private float sliderW(DrawContext ctx, String id, int x, int y, int w, String label, String value, float frac,
                          Function<Float, Integer> bar) {
        Ui.text(ctx, label, x, y, Ui.TEXT);
        Ui.textR(ctx, value, x + w, y, Ui.ACCENT);
        int ty = y + 15;
        int x1 = x, x2 = x + w;
        if (bar == null) {
            Ui.round(ctx, x1, ty, x2, ty + 4, 2, Ui.OFF);
            int fw = (int) ((x2 - x1) * frac);
            if (fw > 1) Ui.round(ctx, x1, ty, x1 + fw, ty + 4, 2, Ui.ACCENT);
        } else {
            int step = 2;
            int n = (x2 - x1) / step;
            for (int i = 0; i < n; i++) {
                ctx.fill(x1 + i * step, ty, x1 + i * step + step, ty + 4, bar.apply(i / (float) Math.max(1, n - 1)));
            }
        }
        int kx = x1 + (int) ((x2 - x1) * frac);
        Ui.round(ctx, kx - 4, ty - 3, kx + 4, ty + 7, 4, 0xFF000000);
        Ui.round(ctx, kx - 3, ty - 2, kx + 3, ty + 6, 3, 0xFFFFFFFF);

        boolean hover = hov(x - 2, y + 8, w + 4, 18);
        if (pressed && hover) active = id;
        if (id.equals(active) && down) {
            return Math.max(0f, Math.min(1f, (mx - x1) / (float) (x2 - x1)));
        }
        return -1f;
    }

    /** Draws a switch row; returns true if clicked this frame. */
    private boolean toggleW(DrawContext ctx, String id, int x, int y, int w, String label, boolean on) {
        float p = anim.getOrDefault(id, on ? 1f : 0f);
        p += ((on ? 1f : 0f) - p) * 0.3f;
        anim.put(id, p);
        Ui.text(ctx, label, x, y + 3, on ? Ui.TEXT : Ui.DIM);
        sw(ctx, x + w - 26, y + 2, p);
        return pressed && hov(x - 2, y, w + 4, 18);
    }

    private void sw(DrawContext ctx, int x, int y, float p) {
        Ui.round(ctx, x, y, x + 26, y + 13, 6, Ui.lerp(Ui.OFF, Ui.ACCENT, p));
        int kx = x + 2 + (int) (13 * p);
        Ui.round(ctx, kx, y + 2, kx + 9, y + 11, 4, 0xFFFFFFFF);
    }

    private void gear(DrawContext ctx, int cx, int cy, int col) {
        // ring + 4 spokes: a small cog
        Ui.round(ctx, cx - 5, cy - 5, cx + 6, cy + 6, 5, col);
        Ui.round(ctx, cx - 2, cy - 2, cx + 3, cy + 3, 2, 0xFF102329);
        ctx.fill(cx - 1, cy - 7, cx + 2, cy - 4, col);
        ctx.fill(cx - 1, cy + 5, cx + 2, cy + 8, col);
        ctx.fill(cx - 7, cy - 1, cx - 4, cy + 2, col);
        ctx.fill(cx + 5, cy - 1, cx + 8, cy + 2, col);
        ctx.fill(cx - 5, cy - 5, cx - 3, cy - 3, col);
        ctx.fill(cx + 4, cy - 5, cx + 6, cy - 3, col);
        ctx.fill(cx - 5, cy + 4, cx - 3, cy + 6, col);
        ctx.fill(cx + 4, cy + 4, cx + 6, cy + 6, col);
    }

    // ------------------------------------------------------------------ main items

    private void drawItem(DrawContext ctx, Item it, int x, int y, int w) {
        boolean hover = hov(x, y, w, it.h);
        if (it.info) {
            Ui.round(ctx, x, y, x + w, y + it.h, 7, Ui.CARD);
            Ui.bold(ctx, "Hook status", x + 10, y + 7, Ui.ACCENT);
            String[] lines = {
                    "View: " + Diag.viewMode + "  (matrix " + Diag.matrixFrames + " / fallback " + Diag.fallbackFrames + ")",
                    "Chams (glow) calls: " + Diag.glow,
                    "Fog hook: buffer " + Diag.fogBuf + "  |  public " + Diag.fogPub,
                    "FOV hook calls: " + Diag.fov,
                    "Time hook calls: " + Diag.time};
            for (int i = 0; i < lines.length; i++) Ui.text(ctx, lines[i], x + 10, y + 24 + i * 16, Ui.TEXT);
            return;
        }
        if (it.action != null) {
            Ui.round(ctx, x, y, x + w, y + it.h, 7, hover ? Ui.CARD_HOVER : Ui.CARD);
            Ui.textC(ctx, it.label, x + w / 2, y + 10, 0xFFFF6B7D);
            if (pressed && hover) it.action.run();
            return;
        }
        Feature f = it.f;
        Ui.round(ctx, x, y, x + w, y + it.h, 7, hover ? Ui.CARD_HOVER : Ui.CARD);
        if (sel == f) Ui.roundBorder(ctx, x, y, x + w, y + it.h, 7, Ui.a(0x21D6C4, 150), hover ? Ui.CARD_HOVER : Ui.CARD);

        if (f.sliderRow) {
            Feature.Opt o = f.opts.get(0);
            float fr = (o.val - o.min) / (float) (o.max - o.min);
            float r = sliderW(ctx, f.id + ".row", x + 10, y + 6, w - 20, f.name, o.val + o.unit, fr, null);
            if (r >= 0) o.val = o.min + Math.round(r * (o.max - o.min));
            return;
        }

        // gear on the right
        int gx = x + w - 16, gy = y + it.h / 2;
        boolean gearHover = hov(x + w - 30, y, 30, it.h);
        boolean selected = sel == f;
        gear(ctx, gx, gy, selected ? Ui.ACCENT : (gearHover ? Ui.TEXT : Ui.DIM));
        if (pressed && gearHover) {
            if (selected) {
                sel = null;
            } else {
                sel = f;
                scrollSide = 0;
                cap = false;
            }
            return;
        }

        if (f.bindOnly) {
            Ui.text(ctx, f.name, x + 10, y + 10, Ui.TEXT);
            Ui.textR(ctx, f.bind.label(), x + w - 36, y + 10, Ui.ACCENT);
            return;
        }

        boolean on = f.on;
        float p = anim.getOrDefault(f.id, on ? 1f : 0f);
        p += ((on ? 1f : 0f) - p) * 0.3f;
        anim.put(f.id, p);
        Ui.text(ctx, f.name, x + 10, y + 7, on ? Ui.TEXT : Ui.DIM);
        if (f.bind.isSet()) Ui.text(ctx, "[" + f.bind.label() + "]", x + 10, y + 18, Ui.a(0x7FA3A8, 170));
        sw(ctx, x + w - 62, y + 8, p);
        if (f.col != null) {
            Ui.round(ctx, x + w - 62, y + 20, x + w - 36, y + 26, 3, 0xFF000000 | f.col.rgb());
        }
        if (pressed && hov(x, y, w - 32, it.h)) {
            f.on = !f.on;
            Features.save();
        }
    }

    // ------------------------------------------------------------------ side panel

    private void drawSide(DrawContext ctx, int sx, int py, int sw, int ph, boolean mouseInSide) {
        Feature f = sel != null ? sel : null;
        Ui.round(ctx, sx - 1, py - 1, sx + sw + 1, py + ph + 1, 9, Ui.a(0x21D6C4, 90));
        Ui.round(ctx, sx, py, sx + sw, py + ph, 8, Ui.BG);
        if (f == null) return;

        // header
        Ui.bold(ctx, f.name, sx + 12, py + 11, Ui.TEXT);
        boolean xHover = mx >= sx + sw - 26 && mx < sx + sw - 6 && my >= py + 6 && my < py + 26 && !blockedSide();
        Ui.textR(ctx, "x", sx + sw - 12, py + 11, xHover ? Ui.TEXT : Ui.DIM);
        ctx.fill(sx + 10, py + 31, sx + sw - 10, py + 32, Ui.a(0x21D6C4, 0x38));
        if (pressed && xHover) {
            sel = null;
            cap = false;
            return;
        }

        int vx1 = sx + 10, vx2 = sx + sw - 10, vy1 = py + 36, vy2 = py + ph - 6;
        int w = vx2 - vx1;
        // the side panel owns the mouse inside its rect
        blocked = false;
        clipX1 = vx1 - 4;
        clipX2 = vx2 + 4;
        clipY1 = vy1;
        clipY2 = vy2;

        // measure
        int h = measureSide(f);
        double maxScroll = Math.max(0, h - (vy2 - vy1));
        scrollSide = Math.max(0, Math.min(maxScroll, scrollSide));
        int y = vy1 - (int) scrollSide;

        ctx.enableScissor(vx1 - 4, vy1, vx2 + 4, vy2);
        Col c = f.col;
        if (c != null) {
            Ui.text(ctx, "COLOR", vx1, y, Ui.DIM);
            y += 14;
            // preview
            Ui.round(ctx, vx1, y, vx2, y + 14, 5, 0xFF05090B);
            Ui.round(ctx, vx1, y, vx2, y + 14, 5, c.argb());
            y += 22;
            if (!c.rainbow) {
                float r = sliderW(ctx, f.id + ".h", vx1, y, w, "Color", (int) (c.h * 360) + "°", c.h,
                        v -> 0xFF000000 | Col.hsv(v, 1f, 1f));
                if (r >= 0) c.h = r;
                y += 28;
            }
            final float hh = c.hue();
            float r2 = sliderW(ctx, f.id + ".s", vx1, y, w, "Whiteness", (int) ((1f - c.s) * 100) + "%", 1f - c.s,
                    v -> 0xFF000000 | Col.hsv(hh, 1f - v, c.b));
            if (r2 >= 0) c.s = 1f - r2;
            y += 28;
            float r3 = sliderW(ctx, f.id + ".b", vx1, y, w, "Darkness", (int) ((1f - c.b) * 100) + "%", 1f - c.b,
                    v -> 0xFF000000 | Col.hsv(hh, c.s, 1f - v));
            if (r3 >= 0) c.b = 1f - r3;
            y += 28;
            float r4 = sliderW(ctx, f.id + ".a", vx1, y, w, "Transparency", (int) ((1f - c.a) * 100) + "%", 1f - c.a,
                    v -> Ui.lerp(0xFF152127, 0xFF000000 | c.rgb(), 1f - v));
            if (r4 >= 0) c.a = 1f - r4;
            y += 28;
            if (toggleW(ctx, f.id + ".rb", vx1, y, w, "Rainbow", c.rainbow)) {
                c.rainbow = !c.rainbow;
                Features.save();
            }
            y += 26;
        }
        if (!f.opts.isEmpty()) {
            Ui.text(ctx, "OPTIONS", vx1, y, Ui.DIM);
            y += 14;
            for (Feature.Opt o : f.opts) {
                if (o.toggle) {
                    if (toggleW(ctx, f.id + ".o." + o.id, vx1, y, w, o.name, o.on())) {
                        o.val = o.on() ? 0 : 1;
                        Features.save();
                    }
                    y += 24;
                } else {
                    float fr = (o.val - o.min) / (float) (o.max - o.min);
                    String vs = o.clock ? clockText(o.val) : o.val + o.unit;
                    Function<Float, Integer> bar = o.clock ? v -> timeColor(v) : null;
                    float r = sliderW(ctx, f.id + ".o." + o.id, vx1, y, w, o.name, vs, fr, bar);
                    if (r >= 0) {
                        int v = o.min + Math.round(r * (o.max - o.min));
                        if (o.clock) v = Math.round(v / 100f) * 100;
                        o.val = Math.max(o.min, Math.min(o.max, v));
                    }
                    y += 28;
                }
            }
        }

        // bind
        Ui.text(ctx, "KEYBIND  (up to 3 keys)", vx1, y, Ui.DIM);
        y += 14;
        int slotW = (w - 12) / 3;
        boolean capHere = cap && capF == f;
        for (int i = 0; i < 3; i++) {
            int bx = vx1 + i * (slotW + 6);
            String label;
            if (capHere) {
                label = i < capKeys.size() ? Keys.name(capKeys.get(i)) : (i == capKeys.size() ? "..." : "-");
            } else {
                label = f.bind.keys[i] != 0 ? Keys.name(f.bind.keys[i]) : "-";
            }
            boolean hv = hov(bx, y, slotW, 22);
            Ui.round(ctx, bx, y, bx + slotW, y + 22, 6, capHere ? Ui.a(0x21D6C4, 70) : (hv ? Ui.CARD_HOVER : Ui.CARD));
            if (capHere) Ui.roundBorder(ctx, bx, y, bx + slotW, y + 22, 6, Ui.ACCENT, Ui.a(0x0E3B43, 255));
            Ui.textC(ctx, label, bx + slotW / 2, y + 6, capHere ? Ui.ACCENT : Ui.TEXT);
            if (pressed && hv && !capHere) startCapture(f);
        }
        y += 28;
        if (capHere) {
            Ui.text(ctx, "Hold keys together, release to save. Esc = cancel", vx1, y, Ui.DIM);
            y += 16;
        }
        int bw = (w - 6) / 2;
        boolean mh = hov(vx1, y, bw, 22);
        Ui.round(ctx, vx1, y, vx1 + bw, y + 22, 6, mh ? Ui.CARD_HOVER : Ui.CARD);
        Ui.textC(ctx, f.bind.hold ? "Mode: Hold" : "Mode: Toggle", vx1 + bw / 2, y + 6, Ui.TEXT);
        if (pressed && mh && !f.bindOnly) {
            f.bind.hold = !f.bind.hold;
            Features.save();
        }
        int cxs = vx1 + bw + 6;
        boolean ch = hov(cxs, y, bw, 22);
        Ui.round(ctx, cxs, y, cxs + bw, y + 22, 6, ch ? 0xFF4A1A24 : Ui.CARD);
        Ui.textC(ctx, "Clear bind", cxs + bw / 2, y + 6, 0xFFFF6B7D);
        if (pressed && ch) {
            f.bind.clear();
            Features.save();
        }
        ctx.disableScissor();

        if (maxScroll > 0) {
            int sbH = Math.max(12, (int) ((vy2 - vy1) * ((vy2 - vy1) / (double) h)));
            int sbY = vy1 + (int) (((vy2 - vy1) - sbH) * (scrollSide / maxScroll));
            ctx.fill(sx + sw - 5, sbY, sx + sw - 3, sbY + sbH, Ui.a(0x21D6C4, 0xAA));
        }
    }

    private boolean blockedSide() {
        return false;
    }

    private int measureSide(Feature f) {
        int h = 0;
        if (f.col != null) {
            h += 14 + 22 + (f.col.rainbow ? 0 : 28) + 28 * 3 + 26;
        }
        if (!f.opts.isEmpty()) {
            h += 14;
            for (Feature.Opt o : f.opts) h += o.toggle ? 24 : 28;
        }
        h += 14 + 28 + 16 + 30;
        return h;
    }

    // ------------------------------------------------------------------ key capture

    private void startCapture(Feature f) {
        cap = true;
        capF = f;
        capKeys.clear();
        capSawAny = false;
    }

    private void updateCapture(long handle) {
        if (!cap) return;
        if (GLFW.glfwGetKey(handle, GLFW.GLFW_KEY_ESCAPE) == GLFW.GLFW_PRESS) {
            cap = false;
            capF = null;
            return;
        }
        boolean any = false;
        for (int k : VALID_KEYS) {
            if (GLFW.glfwGetKey(handle, k) == GLFW.GLFW_PRESS) {
                any = true;
                if (!capKeys.contains(k) && capKeys.size() < 3) capKeys.add(k);
            }
        }
        if (any) {
            capSawAny = true;
        } else if (capSawAny && !capKeys.isEmpty()) {
            Bind b = capF.bind;
            b.clear();
            for (int i = 0; i < capKeys.size() && i < 3; i++) b.keys[i] = capKeys.get(i);
            cap = false;
            capF = null;
            Features.save();
        }
    }
}
