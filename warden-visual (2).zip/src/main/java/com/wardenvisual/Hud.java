package com.wardenvisual;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.entity.effect.StatusEffectInstance;

import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;

public final class Hud {
    private static String toastText = "";
    private static long toastAt = 0;

    public static void toast(String s) {
        if (!Features.TOASTS.on) return;
        toastText = s;
        toastAt = System.currentTimeMillis();
    }

    public static void render(DrawContext ctx, RenderTickCounter tc) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.world == null) return;
        Keys.poll();
        float tp = tc.getTickProgress(false);
        Esp.render(ctx, tp);
        if (Features.POTIONS.on) potions(ctx, mc);
        if (Features.WATERMARK.on) watermark(ctx, mc);
        toast(ctx);
    }

    private static void watermark(DrawContext ctx, MinecraftClient mc) {
        ClientPlayerEntity me = mc.player;
        Feature wm = Features.WATERMARK;
        int accent = wm.col.argb();
        List<String> parts = new ArrayList<>();
        if (wm.b("nick")) parts.add(me.getName().getString());
        if (wm.b("ping")) {
            ClientPlayNetworkHandler nh = mc.getNetworkHandler();
            PlayerListEntry pe = nh == null ? null : nh.getPlayerListEntry(me.getUuid());
            parts.add((pe == null ? 0 : pe.getLatency()) + " ms");
        }
        if (wm.b("fps")) parts.add(mc.getCurrentFps() + " FPS");
        if (wm.b("time")) {
            LocalTime t = LocalTime.now();
            parts.add(String.format("%02d:%02d", t.getHour(), t.getMinute()));
        }

        String name = "Warden Visual";
        String sep = "   |   ";
        int total = Ui.wb(name);
        for (String p : parts) total += Ui.w(sep) + Ui.w(p);
        int w = total + 30;
        int x = (ctx.getScaledWindowWidth() - w) / 2;
        int y = 5;
        Ui.round(ctx, x - 1, y - 1, x + w + 1, y + 20, 7, Ui.a(accent, 70));
        Ui.round(ctx, x, y, x + w, y + 19, 6, 0xE0071015);
        long ms = System.currentTimeMillis();
        int pulse = 150 + (int) (105 * (0.5 + 0.5 * Math.sin(ms / 400.0)));
        Ui.round(ctx, x + 8, y + 7, x + 13, y + 12, 2, Ui.a(accent, pulse));
        int cx = x + 19;
        int cy = y + 5;
        Ui.bold(ctx, name, cx, cy, accent | 0xFF000000);
        cx += Ui.wb(name);
        for (String p : parts) {
            Ui.text(ctx, sep, cx, cy, Ui.DIM);
            cx += Ui.w(sep);
            Ui.text(ctx, p, cx, cy, Ui.TEXT);
            cx += Ui.w(p);
        }
    }

    private static void toast(DrawContext ctx) {
        long age = System.currentTimeMillis() - toastAt;
        if (toastText.isEmpty() || age > 1800) return;
        float f = age < 1400 ? 1f : 1f - (age - 1400) / 400f;
        int al = (int) (255 * f);
        int w = Ui.w(toastText) + 20;
        int x = (ctx.getScaledWindowWidth() - w) / 2;
        int y = ctx.getScaledWindowHeight() - 62;
        Ui.round(ctx, x, y, x + w, y + 18, 6, Ui.a(0x071015, (int) (210 * f)));
        Ui.textC(ctx, toastText, x + w / 2, y + 5, Ui.a(0xE3F6F3, al));
    }

    private static String roman(int n) {
        String[] r = {"", "I", "II", "III", "IV", "V", "VI", "VII", "VIII", "IX", "X"};
        return n >= 0 && n < r.length ? r[n] : String.valueOf(n);
    }

    private static void potions(DrawContext ctx, MinecraftClient mc) {
        ClientPlayerEntity me = mc.player;
        int accent = Features.POTIONS.col.argb();
        List<String> names = new ArrayList<>();
        List<String> times = new ArrayList<>();
        for (StatusEffectInstance inst : me.getStatusEffects()) {
            names.add(inst.getEffectType().value().getName().getString() + " " + roman(inst.getAmplifier() + 1));
            if (inst.isInfinite()) {
                times.add("inf");
            } else {
                int sec = inst.getDuration() / 20;
                times.add((sec / 60) + ":" + String.format("%02d", sec % 60));
            }
        }
        if (names.isEmpty()) return;
        int w = Ui.wb("Potions");
        for (int i = 0; i < names.size(); i++) w = Math.max(w, Ui.w(names.get(i)) + 14 + Ui.w(times.get(i)));
        w += 18;
        int x = 6, y = 34;
        int h = 22 + names.size() * 12 + 3;
        Ui.round(ctx, x, y, x + w, y + h, 6, 0xCC071015);
        ctx.fill(x + 8, y + 17, x + w - 8, y + 18, Ui.a(accent, 0x70));
        Ui.bold(ctx, "Potions", x + 9, y + 5, accent | 0xFF000000);
        for (int i = 0; i < names.size(); i++) {
            int ry = y + 23 + i * 12;
            Ui.text(ctx, names.get(i), x + 9, ry, Ui.TEXT);
            Ui.textR(ctx, times.get(i), x + w - 9, ry, Ui.DIM);
        }
    }

    private Hud() {
    }
}
