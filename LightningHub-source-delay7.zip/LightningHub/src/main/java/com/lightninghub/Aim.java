package com.lightninghub;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

import java.util.Random;

/**
 * Наводка. Работает каждый кадр, целится в ближайшую к прицелу точку хитбокса, залипает на цели,
 * упреждает движение с поправкой на пинг.
 * Если включена авто-атака с авто-поворотом, прицел ведётся ВСЕГДА (даже при выключенной "Наводке"):
 * плавное ведение выглядит для сервера как нормальный взгляд на цель, а резкий довор перед ударом - нет.
 */
public final class Aim {
	private static final Random RNG = new Random();

	private static long lastFrameNs = 0L;
	private static long lastRunNs = 0L;

	private static Entity current = null;

	private static int trackId = -1;
	private static Vec3d trackPos = Vec3d.ZERO;
	private static Vec3d trackVel = Vec3d.ZERO;

	/** Параметры ведения прицела (из настроек "Наводки" или из настроек авто-атаки). */
	private static final class P {
		Config.Targets targets;
		double range;
		double fov;
		double speed;
		double maxTurn;
		double random;
		boolean head;
	}

	public static void frame(MinecraftClient mc) {
		lastFrameNs = System.nanoTime();
		run(mc);
	}

	public static void tick(MinecraftClient mc) {
		Entity t = current;
		if (t != null && t.isAlive()) {
			Vec3d pos = new Vec3d(t.getX(), t.getY(), t.getZ());
			if (t.getId() == trackId) {
				trackVel = trackVel.multiply(0.5).add(pos.subtract(trackPos).multiply(0.5));
			} else {
				trackId = t.getId();
				trackVel = Vec3d.ZERO;
			}
			trackPos = pos;
		} else {
			trackId = -1;
			trackVel = Vec3d.ZERO;
		}

		if (System.nanoTime() - lastFrameNs > 80_000_000L) {
			run(mc);
		}
	}

	/** Горизонтальная скорость цели (блоков за тик) или -1, если цель не отслеживается. */
	public static double speedOf(Entity e) {
		if (e == null || e.getId() != trackId) return -1.0;
		return Math.hypot(trackVel.x, trackVel.z);
	}

	private static P params(Config.Settings s) {
		P q = new P();
		boolean assist = s.aim && (!s.aimHold || Binds.isDown(Binds.AIM_HOLD));
		if (assist) {
			q.targets = s.aimTargets;
			q.range = s.aimRange;
			q.fov = s.aimFov;
			q.speed = s.aimSpeed;
			q.maxTurn = s.aimMaxTurn;
			q.random = s.aimRandom;
			q.head = s.aimHead;
			return q;
		}
		if (s.autoAttack && s.aaFace) {
			q.targets = s.aaTargets;
			q.range = s.aaRange + 1.2;
			q.fov = s.aaFov;
			q.speed = 65;
			q.maxTurn = 22;
			q.random = 0.3;
			q.head = false;
			return q;
		}
		return null;
	}

	private static void run(MinecraftClient mc) {
		long now = System.nanoTime();
		double dt = Math.min(0.1, Math.max(0.0, (now - lastRunNs) / 1.0e9));
		lastRunNs = now;
		double ticksF = dt * 20.0;

		Config.Settings s = Config.S;
		P q = params(s);
		ClientPlayerEntity p = mc.player;
		if (q == null || p == null || mc.world == null || mc.currentScreen != null
				|| !p.isAlive() || p.isSpectator()) {
			current = null;
			return;
		}

		Vec3d eye = p.getEyePos();
		float curYaw = p.getYaw();
		float curPitch = p.getPitch();
		Vec3d dir = p.getRotationVec(1.0f);

		Entity t = pickTarget(mc, p, q, eye, curYaw, curPitch);
		current = t;
		if (t == null) return;

		Vec3d shift = Vec3d.ZERO;
		if (s.aimPredict && t.getId() == trackId) {
			double lead = MathHelper.clamp(0.6 + latencyMs(mc, p) / 100.0, 0.6, 3.0);
			Vec3d v = trackVel;
			if (v.lengthSquared() < 1.5 * 1.5) {
				shift = new Vec3d(v.x * lead, 0.0, v.z * lead);
			}
		}

		Vec3d spot = Targeting.aimSpot(t, eye, dir, q.head, shift);
		float[] a = Targeting.anglesTo(eye, spot);
		float dYaw = MathHelper.wrapDegrees(a[0] - curYaw);
		float dPitch = a[1] - curPitch;
		double dist = Math.hypot(dYaw, dPitch);
		if (dist < 0.12) return;

		double base = MathHelper.clamp(q.speed / 100.0, 0.01, 0.999);
		double k = 1.0 - Math.pow(1.0 - base, ticksF);
		if (p.getAttackCooldownProgress(0.0f) >= 0.9f) k = Math.min(1.0, k * 1.5);

		float max = (float) (q.maxTurn * ticksF);
		float stepYaw = MathHelper.clamp((float) (dYaw * k), -max, max);
		float stepPitch = MathHelper.clamp((float) (dPitch * k), -max, max);

		float jitter = (float) (q.random * 0.2 * ticksF * Math.min(1.0, dist / 3.0));
		stepYaw += (RNG.nextFloat() - 0.5f) * 2f * jitter;
		stepPitch += (RNG.nextFloat() - 0.5f) * 2f * jitter;

		p.setYaw(curYaw + stepYaw);
		p.setPitch(MathHelper.clamp(curPitch + stepPitch, -90f, 90f));
	}

	private static Entity pickTarget(MinecraftClient mc, ClientPlayerEntity p, P q, Vec3d eye,
			float curYaw, float curPitch) {
		Entity keep = current;
		if (keep != null && keep.isAlive() && Targeting.attackable(p, keep, q.targets)
				&& Targeting.reach(p, keep) <= q.range
				&& delta(eye, keep, q, curYaw, curPitch) <= q.fov * 1.25
				&& Targeting.canSeeEntity(p, keep)) {
			return keep;
		}

		Entity best = null;
		double bestDelta = Double.MAX_VALUE;
		double far = (q.range + 4.0) * (q.range + 4.0);
		for (Entity e : mc.world.getEntities()) {
			if (p.squaredDistanceTo(e) > far) continue;
			if (!Targeting.attackable(p, e, q.targets)) continue;
			if (Targeting.reach(p, e) > q.range) continue;
			double d = delta(eye, e, q, curYaw, curPitch);
			if (d > q.fov || d >= bestDelta) continue;
			if (!Targeting.canSeeEntity(p, e)) continue;
			bestDelta = d;
			best = e;
		}
		return best;
	}

	private static double delta(Vec3d eye, Entity e, P q, float curYaw, float curPitch) {
		float[] a = Targeting.anglesTo(eye, Targeting.aimPoint(e, q.head));
		return Math.hypot(MathHelper.wrapDegrees(a[0] - curYaw), a[1] - curPitch);
	}

	public static double latencyMs(MinecraftClient mc, ClientPlayerEntity p) {
		try {
			if (mc.getNetworkHandler() == null) return 0.0;
			PlayerListEntry e = mc.getNetworkHandler().getPlayerListEntry(p.getUuid());
			return e == null ? 0.0 : Math.max(0, e.getLatency());
		} catch (Throwable t) {
			return 0.0;
		}
	}

	private Aim() {
	}
}
