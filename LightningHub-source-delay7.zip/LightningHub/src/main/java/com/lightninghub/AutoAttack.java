package com.lightninghub;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.util.Hand;
import net.minecraft.util.math.Vec3d;

import java.util.Locale;
import java.util.Random;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

/**
 * Авто-атака.
 * - Бьёт только когда шкала урона заполнена полностью (+1 тик запаса на задержку сети).
 * - Критические удары: в прыжке ждёт начала падения.
 * - Легит-режим: бьёт только того, на кого направлен прицел, со случайной задержкой реакции.
 * - Считает, сколько ударов реально прошло, и замечает, если сервер скрывает HP врагов.
 * - Пишет на экран (строка "АА: ...") причину, почему сейчас не бьёт.
 */
public final class AutoAttack {
	private static final Random RNG = new Random();

	/** Последняя атакованная цель - нужна для Таргет-HUD. */
	public static LivingEntity lastTarget = null;
	public static long lastTargetTime = 0L;

	/** Статистика для Таргет-HUD. */
	public static int sent = 0;
	public static int landed = 0;
	/** Сколько раз подряд цель "краснела" от удара, а HP не менялось (сервер скрывает HP). */
	public static int hiddenHp = 0;

	/** Текст для строки "АА: ..." на экране: что делает авто-атака прямо сейчас. */
	public static String status = null;

	private static int ticks = 0;
	private static int pause = 0;
	/** Trigger Delay: момент (мс, System.nanoTime) когда можно слать пакет удара; 0 - задержка не запущена. */
	private static long fireAt = 0L;
	private static Entity delayTarget = null;
	private static long lostSince = 0L;
	/** Будильник: будит главный поток ровно через N мс, а не на следующем тике (тик = 50 мс). */
	private static final ScheduledExecutorService TIMER = Executors.newSingleThreadScheduledExecutor(r -> {
		Thread th = new Thread(r, "LightningHub-delay");
		th.setDaemon(true);
		return th;
	});

	private static long nowMs() {
		return System.nanoTime() / 1_000_000L;
	}
	private static int critWait = 0;
	/** Сколько ударов подряд не нанесли урона (самокалибровка: сужаем дальность и включаем запас по тику). */
	public static int missStreak = 0;
	/** Последняя атакованная цель - пока она в зоне удара, не переключаемся на другую. */
	private static Entity stickyTarget = null;
	private static long stickyTime = 0L;

	private static LivingEntity pendingTarget = null;
	private static float pendingHp = 0f;
	private static int pendingAt = 0;
	private static boolean pendingHurt = false;
	private static String pendingDiag = null;

	public static void tick(MinecraftClient mc) {
		ticks++;
		trackHit();
		process(mc, true);
	}

	/**
	 * В НАЧАЛЕ тика (до пакета движения): если удар будет готов к концу этого тика, а прицел мимо цели -
	 * доворачиваем камеру на цель. Пакет поворота уходит на сервер раньше удара, поэтому сервер (и античит)
	 * видит, что ты смотришь на цель, и урон засчитывается.
	 */
	public static void prepare(MinecraftClient mc) {
		Config.Settings s = Config.S;
		if (!s.autoAttack || !s.aaFace) return;
		ClientPlayerEntity p = mc.player;
		if (p == null || mc.world == null || mc.interactionManager == null || mc.currentScreen != null) return;
		if (!p.isAlive() || p.isSpectator() || p.isUsingItem()) return;
		if (p.getAttackCooldownProgress(s.aaMargin || missStreak >= 3 ? 0.0f : 1.0f) < 1.0f) return;
		double rng = effRange(s);
		if (Targeting.aimedAt(mc, p, s.aaTargets, rng, s.aaNeedSight, true) != null) return;
		faceNearest(mc, p, s, rng);
	}

	/**
	 * Основная логика. tickStep = true - вызов из тика; false - "пробуждение" от таймера Trigger Delay
	 * (тогда счётчики тиков не двигаем, только проверяем всё заново и шлём удар).
	 */
	private static void process(MinecraftClient mc, boolean tickStep) {
		Config.Settings s = Config.S;
		if (!s.autoAttack) {
			fireAt = 0L;
			delayTarget = null;
			lostSince = 0L;
			critWait = 0;
			status = null;
			return;
		}

		ClientPlayerEntity p = mc.player;
		if (p == null || mc.world == null || mc.interactionManager == null) {
			status = "нет игрока или мира";
			return;
		}
		if (mc.currentScreen != null) {
			status = "открыто окно (меню / инвентарь)";
			return;
		}
		if (!p.isAlive() || p.isSpectator()) {
			status = "игрок мёртв или наблюдатель";
			return;
		}
		if (p.isUsingItem()) {
			status = "используешь предмет (щит / лук / еда)";
			return;
		}

		if (pause > 0) {
			if (tickStep) pause--;
			status = "пауза (шанс попадания)";
			return;
		}

		// Шкала урона заполнена полностью + 1 тик запаса: сервер считает свою шкалу отдельно,
		// и при задержке удар по "почти полной" шкале теряет урон и крит.
		// Запас +1 тик включается в настройках (aaMargin); по умолчанию бьём в тот же тик, когда шкала полная.
		if (p.getAttackCooldownProgress(s.aaMargin || missStreak >= 3 ? -1.0f : 0.0f) < 1.0f) {
			int pct = (int) (p.getAttackCooldownProgress(0.0f) * 100);
			status = "ждёт шкалу урона: " + pct + "%";
			return;
		}

		Entity target = findTarget(mc, p, s, effRange(s));
		if (target == null) {
			// Прицел может на миг соскочить с цели (особенно при наводке) - не сбрасываем
			// Trigger Delay сразу, даём 200 мс, иначе удар при задержке почти никогда не пройдёт.
			if (fireAt != 0L) {
				long nm = nowMs();
				if (lostSince == 0L) lostSince = nm;
				if (nm - lostSince > 200L) {
					fireAt = 0L;
					delayTarget = null;
					lostSince = 0L;
				}
			}
			critWait = 0;
			status = noTargetReason(mc, p, s);
			return;
		}
		lostSince = 0L;

		// Кадры неуязвимости: пока цель "краснеет" после прошлого удара, сервер урон не засчитает.
		if (target instanceof LivingEntity le) {
			if (s.aaIframes && le.hurtTime > 0) {
				status = "цель неуязвима (кадры урона) " + le.hurtTime;
				return;
			}
			// Щит: удар в закрывшегося игрока урона не наносит (кроме топора - он выбивает щит).
			if (s.aaShield && le.isBlocking() && !holdingAxe(p)) {
				status = "цель закрылась щитом";
				return;
			}
		}

		// Криты: в воздухе ждём, пока начнётся падение (до 5 тиков, потом бьём как есть).
		if (s.aaCrit && critPossible(p) && p.fallDistance <= 0.0 && critWait < 5) {
			if (tickStep) critWait++;
			status = "жду падения для крита";
			return;
		}
		critWait = 0;

		// Trigger Delay: после того как всё готово (цель, шкала урона, крит) ждём случайное
		// время от aaDelayMin до aaDelayMax миллисекунд и только потом шлём пакет удара.
		int dMin = Math.max(0, s.aaDelayMin);
		int dMax = Math.max(dMin, s.aaDelayMax);
		if (s.aaTriggerDelay && !s.aaInstant && dMax > 0) {
			if (delayTarget != target) {
				// новая цель - отсчёт заново
				delayTarget = target;
				fireAt = 0L;
			}
			if (fireAt == 0L) {
				int d = dMin + (dMax > dMin ? RNG.nextInt(dMax - dMin + 1) : 0);
				fireAt = nowMs() + d;
			}
			long left = fireAt - nowMs();
			if (left > 0) {
				status = "Trigger Delay: " + left + " мс";
				return;
			}
		}
		fireAt = 0L;
		delayTarget = null;

		// Шанс попадания.
		if (RNG.nextInt(100) >= s.aaChance) {
			pause = 2 + RNG.nextInt(6);
			status = "промах по шансу";
			return;
		}

		// Данные для журнала (до удара).
		String diag = null;
		try {
			Vec3d eyeD = p.getEyePos();
			Vec3d toD = Targeting.aimPoint(target, false).subtract(eyeD);
			double cos = Math.max(-1.0, Math.min(1.0, p.getRotationVec(1.0f).dotProduct(toD.normalize())));
			boolean onRay = Targeting.aimedAt(mc, p, Config.Targets.ALL, 6.0, false, false) == target;
			diag = String.format(Locale.ROOT, "%.2f,%d,%.2f,%.1f,%d,%b,%b,%b,%d,%.2f,%b",
					Targeting.reach(p, target), (int) Aim.latencyMs(mc, p), Aim.speedOf(target),
					Math.toDegrees(Math.acos(cos)),
					target instanceof LivingEntity tl ? tl.hurtTime : -1,
					p.isSprinting(), p.isOnGround(), target.isOnGround(), missStreak, effRange(s), onRay);
		} catch (Throwable ignored) {
		}

		mc.interactionManager.attackEntity(p, target);
		p.swingHand(Hand.MAIN_HAND);
		sent++;
		status = "удар! (всего " + sent + ")";

		stickyTarget = target;
		stickyTime = nowMs();

		if (target instanceof LivingEntity le) {
			lastTarget = le;
			lastTargetTime = System.currentTimeMillis();

			if (pendingTarget != null) finishHit();
			pendingTarget = le;
			pendingHp = le.getHealth() + le.getAbsorptionAmount();
			pendingAt = ticks + 10;
			pendingHurt = false;
			pendingDiag = diag;
		}
	}

	private static boolean holdingAxe(ClientPlayerEntity p) {
		try {
			return net.minecraft.registry.Registries.ITEM.getId(p.getMainHandStack().getItem()).getPath().endsWith("_axe");
		} catch (Throwable t) {
			return false;
		}
	}

	/** Можно ли сейчас нанести критический удар (условия ванильного крита, кроме падения). */
	private static boolean critPossible(ClientPlayerEntity p) {
		return !p.isOnGround() && !p.isTouchingWater() && !p.isClimbing() && !p.hasVehicle()
				&& !p.isSprinting() && !p.hasStatusEffect(StatusEffects.BLINDNESS);
	}

	// ----------------------------------------------------------------- выбор цели

	/**
	 * Рабочая дальность: настройка минус поправка на лаг. Если удары не проходят (сервер видит цель дальше,
	 * чем клиент) - сужаем дальность до 0.6 бл., пока удары снова не начнут попадать.
	 */
	public static double effRange(Config.Settings s) {
		double cut = Math.min(0.6, 0.2 * Math.max(0, missStreak - 1));
		return Math.max(1.0, s.aaRange - cut);
	}

	private static Entity findTarget(MinecraftClient mc, ClientPlayerEntity p, Config.Settings s, double rng) {
		// Легитный режим: только то, на что направлен прицел (в пределах дальности).
		if (s.aaNeedAim) {
			Entity aimed = Targeting.aimedAt(mc, p, s.aaTargets, rng, s.aaNeedSight, true);
			return aimed;
		}

		// Обычный режим: лучшая цель в радиусе по выбранному приоритету.
		Vec3d eye = p.getEyePos();
		Vec3d look = p.getRotationVec(1.0f);

		// Залипание: бьём ту же цель, пока она жива, в зоне и видна (не мечемся между врагами).
		Entity st = stickyTarget;
		if (s.aaSticky && st != null && nowMs() - stickyTime < 1500L && st.isAlive()
				&& Targeting.attackable(p, st, s.aaTargets) && Targeting.reach(p, st) <= rng
				&& (!s.aaNeedSight || Targeting.canSeeEntity(p, st))) {
			return st;
		}

		Entity best = null;
		double bestScore = Double.MAX_VALUE;
		double far = (rng + 4.0) * (rng + 4.0);
		for (Entity e : mc.world.getEntities()) {
			if (p.squaredDistanceTo(e) > far) continue;
			if (!Targeting.attackable(p, e, s.aaTargets)) continue;
			double dist = Targeting.reach(p, e);
			if (dist > rng) continue;
			if (s.aaNeedSight && !Targeting.canSeeEntity(p, e)) continue;

			double score;
			switch (s.aaPriority) {
				case LOWEST_HP -> {
					LivingEntity le = (LivingEntity) e;
					score = le.getHealth() + le.getAbsorptionAmount();
				}
				case CROSSHAIR -> {
					Vec3d to = Targeting.aimPoint(e, false).subtract(eye).normalize();
					score = Math.acos(Math.max(-1.0, Math.min(1.0, look.dotProduct(to))));
				}
				default -> score = dist;
			}
			if (score < bestScore) {
				bestScore = score;
				best = e;
			}
		}
		return best;
	}

	/**
	 * Авто-поворот: цель в зоне удара, но прицел чуть мимо (вплотную, стрейф, цель сбоку).
	 * Берём ближайшую к прицелу видимую цель в конусе aaFov и сразу доворачиваем камеру в её хитбокс.
	 */
	private static Entity faceNearest(MinecraftClient mc, ClientPlayerEntity p, Config.Settings s, double rng) {
		Vec3d eye = p.getEyePos();
		float curYaw = p.getYaw();
		float curPitch = p.getPitch();
		Entity best = null;
		double bestDelta = Double.MAX_VALUE;
		double far = (rng + 4.0) * (rng + 4.0);
		for (Entity e : mc.world.getEntities()) {
			if (p.squaredDistanceTo(e) > far) continue;
			if (!Targeting.attackable(p, e, s.aaTargets)) continue;
			if (Targeting.reach(p, e) > rng) continue;
			float[] a = Targeting.anglesTo(eye, Targeting.aimPoint(e, false));
			double d = Math.hypot(net.minecraft.util.math.MathHelper.wrapDegrees(a[0] - curYaw), a[1] - curPitch);
			if (d > s.aaFov || d >= bestDelta) continue;
			if (s.aaIframes && e instanceof LivingEntity le && le.hurtTime > 1) continue;
			if (s.aaNeedSight && !Targeting.canSeeEntity(p, e)) continue;
			bestDelta = d;
			best = e;
		}
		if (best == null) return null;

		Vec3d spot = Targeting.aimSpot(best, eye, p.getRotationVec(1.0f), false, Vec3d.ZERO);
		float[] t = Targeting.anglesTo(eye, spot);
		p.setYaw(t[0]);
		p.setPitch(net.minecraft.util.math.MathHelper.clamp(t[1], -90f, 90f));
		return best;
	}

	/** Объясняет простыми словами, почему цели нет (показывается в строке "АА: ..."). */
	private static String noTargetReason(MinecraftClient mc, ClientPlayerEntity p, Config.Settings s) {
		int near = 0;
		int team = 0;
		double nearest = Double.MAX_VALUE;
		for (Entity e : mc.world.getEntities()) {
			if (!Targeting.valid(p, e, s.aaTargets)) continue;
			double d = Targeting.reach(p, e);
			if (d > 6.0) continue;
			near++;
			if (s.ignoreTeam && e.isTeammate(p)) {
				team++;
			} else {
				nearest = Math.min(nearest, d);
			}
		}

		if (near == 0) {
			return s.aaTargets == Config.Targets.PLAYERS
					? "рядом нет игроков (до 6 бл.)"
					: "рядом никого нет (до 6 бл.)";
		}
		if (team == near) {
			return "все рядом - союзники по команде (выключи «Не бить союзников»)";
		}
		String dist = String.format(Locale.ROOT, "%.1f", nearest);
		if (s.aaNeedAim) {
			return "наведи прицел на цель (ближайшая: " + dist + " бл.)";
		}
		return "вне дальности или за стеной (ближайшая: " + dist + " бл.)";
	}

	// ----------------------------------------------------------------- статистика попаданий

	/** Следит за последним ударом: упало ли HP цели и краснела ли она (анимация урона). */
	private static void trackHit() {
		if (pendingTarget == null) return;
		if (pendingTarget.hurtTime > 0) pendingHurt = true;
		if (ticks >= pendingAt) finishHit();
	}

	private static void finishHit() {
		LivingEntity t = pendingTarget;
		pendingTarget = null;
		if (t == null) return;

		float now = t.getHealth() + t.getAbsorptionAmount();
		boolean hpDropped = !t.isAlive() || now < pendingHp - 0.01f;

		if (pendingDiag != null) {
			Diag.log((hpDropped || pendingHurt) + "," + hpDropped + "," + pendingHurt + "," + pendingDiag);
			pendingDiag = null;
		}
		if (hpDropped || pendingHurt) {
			landed++;
			missStreak = 0;
		} else {
			missStreak++;
		}
		if (pendingHurt && !hpDropped) {
			hiddenHp++; // цель получила урон, а HP не изменилось
		} else if (hpDropped) {
			hiddenHp = 0;
		}
	}

	private AutoAttack() {
	}
}
