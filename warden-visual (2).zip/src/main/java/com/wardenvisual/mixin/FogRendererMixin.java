package com.wardenvisual.mixin;

import com.wardenvisual.Diag;
import com.wardenvisual.Features;
import net.minecraft.client.render.fog.FogRenderer;
import org.joml.Vector4f;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.nio.ByteBuffer;

/**
 * Deep Fog. Two independent paths so at least one works:
 *  - the private buffer writer (distances + color written straight into the fog UBO)
 *  - the public applyFog(Camera, viewDistance, ...) (view distance in chunks + returned color)
 */
@Mixin(FogRenderer.class)
public abstract class FogRendererMixin {
    private static final String BUF = "applyFog(Ljava/nio/ByteBuffer;ILorg/joml/Vector4f;FFFFFF)V";
    private static final String PUB = "applyFog(Lnet/minecraft/client/render/Camera;ILnet/minecraft/client/render/RenderTickCounter;FLnet/minecraft/client/world/ClientWorld;)Lorg/joml/Vector4f;";

    private static float end() {
        return Features.FOG.v("dist");
    }

    private static float start() {
        return end() * Features.FOG.v("start") / 100f;
    }

    // ---- buffer path ----
    @Inject(method = BUF, at = @At("HEAD"), require = 0)
    private void wardenvisual$color(ByteBuffer buffer, int bufPos, Vector4f fogColor,
                                    float a, float b, float c, float d, float e, float f, CallbackInfo ci) {
        if (!Features.FOG.on) return;
        Diag.fogBuf++;
        int col = Features.FOG.col.rgb();
        fogColor.set(((col >> 16) & 255) / 255f, ((col >> 8) & 255) / 255f, (col & 255) / 255f, 1f);
    }

    @ModifyVariable(method = BUF, at = @At("HEAD"), argsOnly = true, ordinal = 0, require = 0)
    private float wardenvisual$envStart(float v) {
        return Features.FOG.on ? start() : v;
    }

    @ModifyVariable(method = BUF, at = @At("HEAD"), argsOnly = true, ordinal = 1, require = 0)
    private float wardenvisual$envEnd(float v) {
        return Features.FOG.on ? end() : v;
    }

    @ModifyVariable(method = BUF, at = @At("HEAD"), argsOnly = true, ordinal = 2, require = 0)
    private float wardenvisual$rdStart(float v) {
        return Features.FOG.on ? start() : v;
    }

    @ModifyVariable(method = BUF, at = @At("HEAD"), argsOnly = true, ordinal = 3, require = 0)
    private float wardenvisual$rdEnd(float v) {
        return Features.FOG.on ? end() : v;
    }

    @ModifyVariable(method = BUF, at = @At("HEAD"), argsOnly = true, ordinal = 4, require = 0)
    private float wardenvisual$skyEnd(float v) {
        return Features.FOG.on ? Math.min(v, end()) : v;
    }

    @ModifyVariable(method = BUF, at = @At("HEAD"), argsOnly = true, ordinal = 5, require = 0)
    private float wardenvisual$cloudEnd(float v) {
        return Features.FOG.on ? Math.min(v, end()) : v;
    }

    // ---- public path ----
    @ModifyVariable(method = PUB, at = @At("HEAD"), argsOnly = true, ordinal = 0, require = 0)
    private int wardenvisual$viewDistance(int chunks) {
        if (!Features.FOG.on) return chunks;
        int c = (int) Math.ceil(end() / 16f);
        return Math.max(1, Math.min(chunks, c));
    }

    @Inject(method = PUB, at = @At("RETURN"), require = 0)
    private void wardenvisual$pubColor(CallbackInfoReturnable<Vector4f> cir) {
        if (!Features.FOG.on) return;
        Diag.fogPub++;
        Vector4f v = cir.getReturnValue();
        if (v == null) return;
        int col = Features.FOG.col.rgb();
        v.set(((col >> 16) & 255) / 255f, ((col >> 8) & 255) / 255f, (col & 255) / 255f, 1f);
    }
}
