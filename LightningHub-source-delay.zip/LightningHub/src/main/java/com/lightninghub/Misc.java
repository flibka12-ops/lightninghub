package com.lightninghub;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;

/** Мелкие функции: фуллбрайт (ночное зрение) и авто-спринт. */
public final class Misc {
	private static boolean fullbrightApplied = false;
	private static boolean sprintApplied = false;

	public static void tick(MinecraftClient mc) {
		ClientPlayerEntity p = mc.player;
		if (p == null) return;
		Config.Settings s = Config.S;

		// Фуллбрайт: бесконечное ночное зрение на стороне клиента.
		if (s.fullbright) {
			if (!p.hasStatusEffect(StatusEffects.NIGHT_VISION)) {
				p.addStatusEffect(new StatusEffectInstance(StatusEffects.NIGHT_VISION, 100000, 0, false, false, false));
			}
			fullbrightApplied = true;
		} else if (fullbrightApplied) {
			p.removeStatusEffect(StatusEffects.NIGHT_VISION);
			fullbrightApplied = false;
		}

		// Авто-спринт: держит клавишу спринта, пока идёшь вперёд.
		if (s.autoSprint) {
			if (mc.currentScreen == null && mc.options.forwardKey.isPressed() && !p.isSneaking()) {
				mc.options.sprintKey.setPressed(true);
				sprintApplied = true;
			}
		} else if (sprintApplied) {
			mc.options.sprintKey.setPressed(false);
			sprintApplied = false;
		}
	}

	private Misc() {
	}
}
