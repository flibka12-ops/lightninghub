package com.wardenvisual;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.render.Camera;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.Vec3d;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/** 2D ESP: Sculk Frame, Ribcage (players only), Soul Bar, Name Tags. Optimized: nearest-N, LOD, cheap lines. */
public final class Esp {
    private static final int MAX_TARGETS = 32;
    private static final Projector FALLBACK = new Projector();
    private static final List<LivingEntity> LIST = new ArrayList<>();
    private static final double[] P = new double[2];

    private static boolean matrix;
    private static double camX, camY, camZ;
    private static int gw, gh;

    public static void render(DrawContext ctx, float tp) {
        if (!(Features.FRAME.on || Features.SKELETON.on || Features.HPBAR.on || Features.NAMES.on)) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        ClientPlayerEntity me = mc.player;
        ClientWorld world = mc.world;
        if (me == null || world == null) return;
        gw = ctx.getScaledWindowWidth();
        gh = ctx.getScaledWindowHeight();
        boolean first = mc.options.getPerspective().isFirstPerson();

        Camera cam = mc.gameRenderer.getCamera();
        Vec3d cp = cam.getCameraPos();
        camX = cp.x;
        camY = cp.y;
        camZ = cp.z;

        matrix = View.prepare() && sane(me, tp, first);
        if (matrix) {
            Diag.matrixFrames++;
            Diag.viewMode = "matrix";
        } else {
            Diag.fallbackFrames++;
            Diag.viewMode = "fallback";
            if (!first) return;
            FALLBACK.setup(me, tp, gw, gh, mc.options.getFov().getValue());
        }

        double r = Features.ESP_RANGE.v("v");
        double r2 = r * r;
        LIST.clear();
        for (Entity e : world.getEntities()) {
            if (e instanceof LivingEntity le && Targets.esp(e, r2)) LIST.add(le);
        }
        if (LIST.isEmpty()) return;
        if (LIST.size() > MAX_TARGETS) {
            LIST.sort(Comparator.comparingDouble(en -> me.squaredDistanceTo(en)));
            while (LIST.size() > MAX_TARGETS) LIST.remove(LIST.size() - 1);
        }
        for (LivingEntity e : LIST) draw(ctx, mc, me, e, tp);
    }

    /** The captured matrices must put a point straight ahead near the screen center. */
    private static boolean sane(ClientPlayerEntity me, float tp, boolean first) {
        if (!first) return true;
        Vec3d look = me.getRotationVec(tp);
        if (!View.project(look.x * 10, look.y * 10, look.z * 10, gw, gh, P)) return false;
        return Math.abs(P[0] - gw / 2.0) < gw * 0.35 && Math.abs(P[1] - gh / 2.0) < gh * 0.35;
    }

    private static boolean proj(double x, double y, double z, double[] out) {
        if (matrix) return View.project(x - camX, y - camY, z - camZ, gw, gh, out);
        double[] s = FALLBACK.project(x, y, z);
        if (s == null) return false;
        out[0] = s[0];
        out[1] = s[1];
        return true;
    }

    private static void draw(DrawContext ctx, MinecraftClient mc, ClientPlayerEntity me, LivingEntity e, float tp) {
        Vec3d pos = e.getLerpedPos(tp);
        double hw = e.getWidth() / 2.0;
        double hh = e.getHeight();
        double minX = 1e9, minY = 1e9, maxX = -1e9, maxY = -1e9;
        for (int i = 0; i < 8; i++) {
            double cx = pos.x + ((i & 1) == 0 ? -hw : hw);
            double cy = pos.y + ((i & 2) == 0 ? 0 : hh);
            double cz = pos.z + ((i & 4) == 0 ? -hw : hw);
            if (!proj(cx, cy, cz, P)) return;
            if (P[0] < minX) minX = P[0];
            if (P[0] > maxX) maxX = P[0];
            if (P[1] < minY) minY = P[1];
            if (P[1] > maxY) maxY = P[1];
        }
        int x1 = (int) minX, y1 = (int) minY, x2 = (int) maxX, y2 = (int) maxY;
        if (x2 < -50 || x1 > gw + 50 || y2 < -50 || y1 > gh + 50) return; // off screen
        if (x2 - x1 < 3 || y2 - y1 < 3) return;
        if (x2 - x1 > gw * 2) return;

        double dist = Math.sqrt(me.squaredDistanceTo(e));
        int hgt = y2 - y1;

        if (Features.SKELETON.on && e instanceof PlayerEntity && dist <= Features.SKELETON.v("range") && hgt >= 14) {
            skeleton(ctx, e, pos, hw, hh, hgt);
        }
        if (Features.FRAME.on) frame(ctx, x1, y1, x2, y2);
        if (Features.HPBAR.on) hpBar(ctx, e, x1, y1, y2);
        if (Features.NAMES.on && hgt >= 10) nameTag(ctx, e, dist, (x1 + x2) / 2, y1);
    }

    // ---- Sculk Frame ----
    private static void frame(DrawContext ctx, int x1, int y1, int x2, int y2) {
        Col c = Features.FRAME.col;
        float pulse = 0.88f + 0.12f * (float) Math.sin(System.currentTimeMillis() / 380.0);
        int col = c.argb(pulse);
        if (Features.FRAME.b("fill")) ctx.fillGradient(x1, y1, x2, y2, c.argb(0.10f), c.argb(0.03f));
        int shadow = 0x99000000;
        if (!Features.FRAME.b("corners")) {
            Ui.outline(ctx, x1 - 1, y1 - 1, x2 + 1, y2 + 1, shadow);
            Ui.outline(ctx, x1, y1, x2, y2, col);
            return;
        }
        int len = Math.max(3, Math.min(14, Math.min(x2 - x1, y2 - y1) / 4));
        corner(ctx, x1, y1, len, 1, 1, shadow, 1);
        corner(ctx, x2, y1, len, -1, 1, shadow, 1);
        corner(ctx, x1, y2, len, 1, -1, shadow, 1);
        corner(ctx, x2, y2, len, -1, -1, shadow, 1);
        corner(ctx, x1, y1, len, 1, 1, col, 0);
        corner(ctx, x2, y1, len, -1, 1, col, 0);
        corner(ctx, x1, y2, len, 1, -1, col, 0);
        corner(ctx, x2, y2, len, -1, -1, col, 0);
    }

    private static void corner(DrawContext ctx, int x, int y, int len, int dx, int dy, int col, int g) {
        int ox = dx > 0 ? x : x - 1;
        int oy = dy > 0 ? y : y - 1;
        int hx1 = dx > 0 ? ox - g : ox - len + 1 - g;
        int hx2 = dx > 0 ? ox + len + g : ox + 1 + g;
        ctx.fill(hx1, oy - g, hx2, oy + 1 + g, col);
        int vy1 = dy > 0 ? oy - g : oy - len + 1 - g;
        int vy2 = dy > 0 ? oy + len + g : oy + 1 + g;
        ctx.fill(ox - g, vy1, ox + 1 + g, vy2, col);
    }

    // ---- Soul Bar ----
    private static void hpBar(DrawContext ctx, LivingEntity e, int x1, int y1, int y2) {
        float hp = e.getHealth();
        float max = Math.max(1f, e.getMaxHealth());
        float ratio = Math.max(0f, Math.min(1f, hp / max));
        int bx = x1 - 5;
        ctx.fill(bx - 1, y1 - 1, bx + 3, y2 + 1, 0xAA000000);
        ctx.fill(bx, y1, bx + 2, y2, 0xFF3A1216);
        int gh2 = Math.round((y2 - y1) * ratio);
        int col = Ui.lerp(0xFFFF3B3B, 0xFF2BFF5A, ratio);
        ctx.fill(bx, y2 - gh2, bx + 2, y2, col);
        if (Features.HPBAR.b("numbers") && y2 - y1 >= 34) {
            String s = Math.round(hp) + "/" + Math.round(max);
            Ui.shadow(ctx, s, bx - 3 - Ui.w(s), (y1 + y2) / 2 - 4, 0xFFFFFFFF);
        }
    }

    // ---- Name tag ----
    private static void nameTag(DrawContext ctx, LivingEntity e, double dist, int cx, int top) {
        String s = e.getName().getString();
        if (Features.NAMES.b("dist")) s += "  " + (int) dist + "m";
        int w = Ui.w(s);
        int x = cx - w / 2;
        int y = top - 14;
        Ui.round(ctx, x - 4, y - 2, x + w + 4, y + 11, 4, 0xB0061014);
        ctx.fill(x - 2, y + 10, x + w + 2, y + 11, Features.FRAME.col.argb(0.8f));
        Ui.shadow(ctx, s, x, y, Features.NAMES.col.argb());
    }

    // ---- Ribcage (players only) ----
    private static boolean pt(Vec3d pos, double rx, double rz, double lat, double y, double[] out) {
        return proj(pos.x + rx * lat, pos.y + y, pos.z + rz * lat, out);
    }

    private static void skeleton(DrawContext ctx, LivingEntity e, Vec3d pos, double hw, double hh, int screenH) {
        double yaw = Math.toRadians(e.getYaw());
        double rx = -Math.cos(yaw), rz = -Math.sin(yaw);
        double headTop = hh * 0.99, headBot = hh * 0.78, shoulderY = hh * 0.76;
        double hipY = hh * 0.44, legTopY = hh * 0.40;
        double sh = hw * 0.95, lh = hw * 0.33;

        double[] ht = new double[2], hb = new double[2], s0 = new double[2], sl = new double[2], sr = new double[2];
        double[] al = new double[2], ar = new double[2], hip = new double[2], ll = new double[2], lr = new double[2];
        double[] fl = new double[2], fr = new double[2];
        if (!pt(pos, rx, rz, 0, headTop, ht) || !pt(pos, rx, rz, 0, headBot, hb) || !pt(pos, rx, rz, 0, shoulderY, s0)
                || !pt(pos, rx, rz, -sh, shoulderY, sl) || !pt(pos, rx, rz, sh, shoulderY, sr)
                || !pt(pos, rx, rz, -sh, hipY, al) || !pt(pos, rx, rz, sh, hipY, ar)
                || !pt(pos, rx, rz, 0, hipY, hip) || !pt(pos, rx, rz, -lh, legTopY, ll)
                || !pt(pos, rx, rz, lh, legTopY, lr) || !pt(pos, rx, rz, -lh, 0, fl)
                || !pt(pos, rx, rz, lh, 0, fr)) return;

        int col = Features.SKELETON.col.argb();
        float t = screenH > 120 ? 2f : 1f;

        double size = Math.abs(hb[1] - ht[1]);
        double cx = (ht[0] + hb[0]) / 2.0;
        int hx1 = (int) (cx - size / 2), hx2 = (int) (cx + size / 2);
        int hy1 = (int) ht[1], hy2 = (int) hb[1];
        if (hy2 > hy1 + 1) Ui.outline(ctx, hx1, hy1, hx2, hy2, col);
        Ui.line(ctx, hb[0], hb[1], s0[0], s0[1], col, t);
        Ui.line(ctx, sl[0], sl[1], sr[0], sr[1], col, t);
        Ui.line(ctx, sl[0], sl[1], al[0], al[1], col, t);
        Ui.line(ctx, sr[0], sr[1], ar[0], ar[1], col, t);
        Ui.line(ctx, s0[0], s0[1], hip[0], hip[1], col, t);
        Ui.line(ctx, hip[0], hip[1], ll[0], ll[1], col, t);
        Ui.line(ctx, hip[0], hip[1], lr[0], lr[1], col, t);
        Ui.line(ctx, ll[0], ll[1], fl[0], fl[1], col, t);
        Ui.line(ctx, lr[0], lr[1], fr[0], fr[1], col, t);
    }

    private Esp() {
    }
}
