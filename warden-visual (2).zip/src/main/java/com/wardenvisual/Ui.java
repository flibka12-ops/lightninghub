package com.wardenvisual;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.text.Style;
import net.minecraft.text.StyleSpriteSource;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import org.joml.Matrix3x2fStack;

import java.util.HashMap;
import java.util.Map;

/** Palette, smooth-ish shapes and text drawing with the bundled regular font. */
public final class Ui {
    public static final int BG = 0xF2091217;
    public static final int PANEL2 = 0xFF0D1A20;
    public static final int CARD = 0xFF102329;
    public static final int CARD_HOVER = 0xFF15303A;
    public static final int ACCENT = 0xFF21D6C4;
    public static final int TEXT = 0xFFE3F6F3;
    public static final int DIM = 0xFF7FA3A8;
    public static final int OFF = 0xFF2A4048;

    private static final Style REG = Style.EMPTY.withFont(new StyleSpriteSource.Font(Identifier.of("wardenvisual", "ui")));
    private static final Style BOLD = Style.EMPTY.withFont(new StyleSpriteSource.Font(Identifier.of("wardenvisual", "ui_bold")));
    private static final Map<String, Text> REG_CACHE = new HashMap<>();
    private static final Map<String, Text> BOLD_CACHE = new HashMap<>();

    private static Text t(String s, boolean bold) {
        Map<String, Text> c = bold ? BOLD_CACHE : REG_CACHE;
        Text x = c.get(s);
        if (x == null) {
            if (c.size() > 600) c.clear();
            x = Text.literal(s).setStyle(bold ? BOLD : REG);
            c.put(s, x);
        }
        return x;
    }

    private static TextRenderer tr() {
        return MinecraftClient.getInstance().textRenderer;
    }

    public static int w(String s) {
        return tr().getWidth(t(s, false));
    }

    public static int wb(String s) {
        return tr().getWidth(t(s, true));
    }

    public static void text(DrawContext c, String s, int x, int y, int col) {
        c.drawText(tr(), t(s, false), x, y, col, false);
    }

    public static void shadow(DrawContext c, String s, int x, int y, int col) {
        c.drawText(tr(), t(s, false), x, y, col, true);
    }

    public static void bold(DrawContext c, String s, int x, int y, int col) {
        c.drawText(tr(), t(s, true), x, y, col, false);
    }

    public static void textR(DrawContext c, String s, int right, int y, int col) {
        text(c, s, right - w(s), y, col);
    }

    public static void textC(DrawContext c, String s, int cx, int y, int col) {
        text(c, s, cx - w(s) / 2, y, col);
    }

    public static int a(int rgb, int alpha) {
        return (Math.max(0, Math.min(255, alpha)) << 24) | (rgb & 0xFFFFFF);
    }

    public static int lerp(int c1, int c2, float t) {
        t = Math.max(0f, Math.min(1f, t));
        int a = (int) (((c1 >>> 24) & 255) * (1 - t) + ((c2 >>> 24) & 255) * t);
        int r = (int) (((c1 >> 16) & 255) * (1 - t) + ((c2 >> 16) & 255) * t);
        int g = (int) (((c1 >> 8) & 255) * (1 - t) + ((c2 >> 8) & 255) * t);
        int b = (int) ((c1 & 255) * (1 - t) + (c2 & 255) * t);
        return (a << 24) | (r << 16) | (g << 8) | b;
    }

    /** Rounded rectangle (row based, radius r). */
    public static void round(DrawContext c, int x1, int y1, int x2, int y2, int r, int argb) {
        r = Math.min(r, Math.min((x2 - x1) / 2, (y2 - y1) / 2));
        if (r <= 1) {
            c.fill(x1, y1, x2, y2, argb);
            return;
        }
        for (int i = 0; i < r; i++) {
            double dy = r - i - 0.5;
            int inset = r - (int) Math.round(Math.sqrt(r * r - dy * dy));
            c.fill(x1 + inset, y1 + i, x2 - inset, y1 + i + 1, argb);
            c.fill(x1 + inset, y2 - i - 1, x2 - inset, y2 - i, argb);
        }
        c.fill(x1, y1 + r, x2, y2 - r, argb);
    }

    /** Rounded ring: outer rounded rect with a thin border drawn by filling outer then inner. */
    public static void roundBorder(DrawContext c, int x1, int y1, int x2, int y2, int r, int border, int fill) {
        round(c, x1, y1, x2, y2, r, border);
        round(c, x1 + 1, y1 + 1, x2 - 1, y2 - 1, Math.max(1, r - 1), fill);
    }

    public static void outline(DrawContext c, int x1, int y1, int x2, int y2, int argb) {
        c.fill(x1, y1, x2, y1 + 1, argb);
        c.fill(x1, y2 - 1, x2, y2, argb);
        c.fill(x1, y1 + 1, x1 + 1, y2 - 1, argb);
        c.fill(x2 - 1, y1 + 1, x2, y2 - 1, argb);
    }

    /** One filled rectangle rotated onto the line (cheap, unlike per-pixel stepping). */
    public static void line(DrawContext c, double x1, double y1, double x2, double y2, int argb, float thick) {
        double dx = x2 - x1, dy = y2 - y1;
        double len = Math.sqrt(dx * dx + dy * dy);
        if (len < 0.5 || len > 6000) return;
        Matrix3x2fStack m = c.getMatrices();
        m.pushMatrix();
        m.translate((float) x1, (float) y1);
        m.rotate((float) Math.atan2(dy, dx));
        m.translate(0f, -thick / 2f);
        c.fill(0, 0, (int) Math.ceil(len), Math.max(1, Math.round(thick)), argb);
        m.popMatrix();
    }

    private Ui() {
    }
}
