package com.lightninghub.mixin;

import com.lightninghub.Esp;
import net.minecraft.entity.Entity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(Entity.class)
public abstract class EntityMixin {
	@Inject(method = "isGlowing", at = @At("HEAD"), cancellable = true)
	private void lightninghub$espGlow(CallbackInfoReturnable<Boolean> cir) {
		if (Esp.shouldGlow((Entity) (Object) this)) {
			cir.setReturnValue(true);
		}
	}
}
