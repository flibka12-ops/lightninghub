package com.lightninghub;

import net.minecraft.client.MinecraftClient;
import org.lwjgl.glfw.GLFW;

import java.util.HashMap;
import java.util.Map;

/** Система биндов: каждой функции можно назначить клавишу (переключение по нажатию). */
public final class Binds {
	/** Особый бинд: клавиша, которую нужно держать, чтобы работала наводка. */
	public static final String AIM_HOLD = "aimHold";

	private static final Map<String, Boolean> previous = new HashMap<>();

	public static int get(String id) {
		Integer k = Config.S.binds.get(id);
		return k == null ? -1 : k;
	}

	public static void set(String id, int key) {
		if (key < 0) Config.S.binds.remove(id);
		else Config.S.binds.put(id, key);
	}

	public static boolean isDown(String id) {
		int k = get(id);
		if (k < 0) return false;
		MinecraftClient mc = MinecraftClient.getInstance();
		if (mc.getWindow() == null) return false;
		return GLFW.glfwGetKey(mc.getWindow().getHandle(), k) == GLFW.GLFW_PRESS;
	}

	/** Вызывается каждый тик: переключает функции по нажатию их клавиш. */
	public static void tick(MinecraftClient mc) {
		for (Modules.Mod m : Modules.ALL) {
			boolean down = isDown(m.id());
			boolean was = previous.getOrDefault(m.id(), false);
			if (down && !was && mc.currentScreen == null) {
				m.toggle();
			}
			previous.put(m.id(), down);
		}
	}

	public static String keyName(int k) {
		if (k < 0) return "нет";
		if (k >= 65 && k <= 90) return String.valueOf((char) k);
		if (k >= 48 && k <= 57) return String.valueOf((char) k);
		if (k >= 290 && k <= 301) return "F" + (k - 289);
		return switch (k) {
			case 32 -> "Пробел";
			case 258 -> "Tab";
			case 257 -> "Enter";
			case 280 -> "Caps";
			case 340 -> "L-Shift";
			case 344 -> "R-Shift";
			case 341 -> "L-Ctrl";
			case 345 -> "R-Ctrl";
			case 342 -> "L-Alt";
			case 346 -> "R-Alt";
			case 262 -> "Вправо";
			case 263 -> "Влево";
			case 264 -> "Вниз";
			case 265 -> "Вверх";
			case 96 -> "`";
			case 45 -> "-";
			case 61 -> "=";
			case 91 -> "[";
			case 93 -> "]";
			case 59 -> ";";
			case 39 -> "'";
			case 44 -> ",";
			case 46 -> ".";
			case 47 -> "/";
			case 92 -> "\\";
			default -> "Клавиша " + k;
		};
	}

	private Binds() {
	}
}
