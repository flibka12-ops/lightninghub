package com.wardenvisual;

import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.decoration.ArmorStandEntity;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.entity.player.PlayerEntity;

public final class Targets {
    /** Type filter only (players / mobs enabled, alive, not self). */
    public static boolean type(Entity e) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || e == mc.player) return false;
        if (!(e instanceof LivingEntity) || e instanceof ArmorStandEntity || !e.isAlive()) return false;
        if (e instanceof PlayerEntity pe) return Features.PLAYERS.on && !pe.isSpectator();
        return e instanceof MobEntity && Features.MOBS.on;
    }

    public static boolean esp(Entity e, double r2) {
        return type(e) && MinecraftClient.getInstance().player.squaredDistanceTo(e) <= r2;
    }

    public static boolean chams(Entity e) {
        if (!Features.CHAMS.on || !type(e)) return false;
        double r = Features.CHAMS.v("range");
        return MinecraftClient.getInstance().player.squaredDistanceTo(e) <= r * r;
    }

    private Targets() {
    }
}
