package com.wardenvisual;

import org.lwjgl.glfw.GLFW;

/** A keybind of up to 3 keys that must all be held together (e.g. Shift + Q + Y). */
public final class Bind {
    public final int[] keys = new int[3];
    public boolean hold;
    boolean was;

    public int count() {
        int n = 0;
        for (int k : keys) if (k != 0) n++;
        return n;
    }

    public boolean isSet() {
        return count() > 0;
    }

    public void clear() {
        keys[0] = keys[1] = keys[2] = 0;
    }

    public boolean down(long handle) {
        if (!isSet()) return false;
        for (int k : keys) {
            if (k != 0 && GLFW.glfwGetKey(handle, k) != GLFW.GLFW_PRESS) return false;
        }
        return true;
    }

    public boolean contains(int k) {
        for (int x : keys) if (x == k) return true;
        return false;
    }

    public String label() {
        if (!isSet()) return "None";
        StringBuilder sb = new StringBuilder();
        for (int k : keys) {
            if (k == 0) continue;
            if (sb.length() > 0) sb.append(" + ");
            sb.append(Keys.name(k));
        }
        return sb.toString();
    }

    public String save() {
        return keys[0] + "," + keys[1] + "," + keys[2] + "," + (hold ? 1 : 0);
    }

    public void load(String s) {
        try {
            String[] p = s.split(",");
            for (int i = 0; i < 3 && i < p.length; i++) keys[i] = Integer.parseInt(p[i].trim());
            if (p.length > 3) hold = p[3].trim().equals("1");
        } catch (Exception ignored) {
        }
    }
}
