package com.lightninghub;

import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.decoration.ArmorStandEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.Vec3d;

/** Общие проверки целей и математика углов. */
public final class Targeting {
	/** Подходит ли сущность как цель (жива, не стойка для брони, не наблюдатель, режим целей). */
	public static boolean valid(ClientPlayerEntity player, Entity e, Config.Targets mode) {
		if (!(e instanceof LivingEntity) || e == player || e instanceof ArmorStandEntity) return false;
		if (!e.isAlive() || e.isSpectator()) return false;
		return mode == Config.Targets.ALL || e instanceof PlayerEntity;
	}

	/** Точка, в которую целимся: голова или корпус. */
	public static Vec3d aimPoint(Entity e, boolean head) {
		double y = head ? e.getEyeY() : e.getY() + e.getHeight() * 0.6;
		return new Vec3d(e.getX(), y, e.getZ());
	}

	/** Нужные углы {yaw, pitch}, чтобы смотреть из точки from в точку to. */
	public static float[] anglesTo(Vec3d from, Vec3d to) {
		double dx = to.x - from.x;
		double dy = to.y - from.y;
		double dz = to.z - from.z;
		double h = Math.sqrt(dx * dx + dz * dz);
		float yaw = (float) (Math.toDegrees(Math.atan2(dz, dx)) - 90.0);
		float pitch = (float) (-Math.toDegrees(Math.atan2(dy, h)));
		return new float[]{yaw, pitch};
	}

	private Targeting() {
	}
}
