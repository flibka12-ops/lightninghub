package com.lightninghub;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

/** Настройки мода. Хранятся в .minecraft/config/lightninghub.json */
public final class Config {
	public enum Targets {
		ALL("Все (игроки, мобы, животные)"),
		PLAYERS("Только игроки");

		public final String label;

		Targets(String label) {
			this.label = label;
		}

		public Targets next() {
			return values()[(ordinal() + 1) % values().length];
		}
	}

	// --- Авто-атака ---
	public static boolean autoAttack = false;
	public static Targets autoAttackTargets = Targets.ALL;
	/** Дальность в блоках (ванильная дальность удара по сущности = 3.0). */
	public static double autoAttackRange = 3.0;
	/** Шанс удара в процентах (0..100). Бросается каждый раз, когда шкала урона заполнена. */
	public static int autoAttackChance = 100;
	/** Бить только тех, кого видно (не через стены). */
	public static boolean autoAttackNeedSight = true;

	// --- ESP ---
	public static boolean esp = false;
	public static Targets espTargets = Targets.ALL;

	private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

	private static Path file() {
		return FabricLoader.getInstance().getConfigDir().resolve("lightninghub.json");
	}

	private static final class Data {
		boolean autoAttack;
		Targets autoAttackTargets = Targets.ALL;
		double autoAttackRange = 3.0;
		int autoAttackChance = 100;
		boolean autoAttackNeedSight = true;
		boolean esp;
		Targets espTargets = Targets.ALL;
	}

	public static void load() {
		Path f = file();
		if (!Files.exists(f)) return;
		try {
			Data d = GSON.fromJson(Files.readString(f), Data.class);
			if (d == null) return;
			autoAttack = d.autoAttack;
			autoAttackTargets = d.autoAttackTargets == null ? Targets.ALL : d.autoAttackTargets;
			autoAttackRange = Math.max(1.0, Math.min(6.0, d.autoAttackRange));
			autoAttackChance = Math.max(0, Math.min(100, d.autoAttackChance));
			autoAttackNeedSight = d.autoAttackNeedSight;
			esp = d.esp;
			espTargets = d.espTargets == null ? Targets.ALL : d.espTargets;
		} catch (Exception ignored) {
			// битый конфиг - остаёмся на значениях по умолчанию
		}
	}

	public static void save() {
		Data d = new Data();
		d.autoAttack = autoAttack;
		d.autoAttackTargets = autoAttackTargets;
		d.autoAttackRange = autoAttackRange;
		d.autoAttackChance = autoAttackChance;
		d.autoAttackNeedSight = autoAttackNeedSight;
		d.esp = esp;
		d.espTargets = espTargets;
		try {
			Files.writeString(file(), GSON.toJson(d));
		} catch (IOException ignored) {
		}
	}

	private Config() {
	}
}
