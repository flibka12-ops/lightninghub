package com.lightninghub;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.SliderWidget;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import org.lwjgl.glfw.GLFW;

import java.util.Locale;
import java.util.function.DoubleConsumer;

/** Жёлтое меню LightningHub. Открывается/закрывается Right Shift. */
public class MenuScreen extends Screen {
	private static final int PANEL_W = 250;
	private static final int PANEL_H = 232;
	private static final int BTN_W = 220;

	private static final int COLOR_BORDER = 0xFFB8860B;
	private static final int COLOR_PANEL = 0xF2FFD93B;
	private static final int COLOR_TITLE = 0xFFFFB800;
	private static final int COLOR_TEXT_DARK = 0xFF2B2100;

	private boolean shiftWasDown = true; // Right Shift ещё зажат в момент открытия

	public MenuScreen() {
		super(Text.literal("LightningHub"));
	}

	@Override
	protected void init() {
		int left = (width - PANEL_W) / 2;
		int top = (height - PANEL_H) / 2;
		int x = left + (PANEL_W - BTN_W) / 2;

		// ---- Авто-атака ----
		addDrawableChild(ButtonWidget.builder(toggleText("Авто-атака", Config.autoAttack), b -> {
			Config.autoAttack = !Config.autoAttack;
			b.setMessage(toggleText("Авто-атака", Config.autoAttack));
		}).dimensions(x, top + 36, BTN_W, 20).build());

		addDrawableChild(ButtonWidget.builder(targetsText("Цели", Config.autoAttackTargets), b -> {
			Config.autoAttackTargets = Config.autoAttackTargets.next();
			b.setMessage(targetsText("Цели", Config.autoAttackTargets));
		}).dimensions(x, top + 60, BTN_W, 20).build());

		addDrawableChild(new Slide(x, top + 84, BTN_W, 20, "Дальность", " бл.", 1.0, 6.0, Config.autoAttackRange,
				false, v -> Config.autoAttackRange = v));

		addDrawableChild(new Slide(x, top + 108, BTN_W, 20, "Шанс попадания", "%", 0, 100, Config.autoAttackChance,
				true, v -> Config.autoAttackChance = (int) Math.round(v)));

		addDrawableChild(ButtonWidget.builder(toggleText("Только в прямой видимости", Config.autoAttackNeedSight), b -> {
			Config.autoAttackNeedSight = !Config.autoAttackNeedSight;
			b.setMessage(toggleText("Только в прямой видимости", Config.autoAttackNeedSight));
		}).dimensions(x, top + 132, BTN_W, 20).build());

		// ---- ESP ----
		addDrawableChild(ButtonWidget.builder(toggleText("ESP", Config.esp), b -> {
			Config.esp = !Config.esp;
			b.setMessage(toggleText("ESP", Config.esp));
		}).dimensions(x, top + 172, BTN_W, 20).build());

		addDrawableChild(ButtonWidget.builder(targetsText("Цели ESP", Config.espTargets), b -> {
			Config.espTargets = Config.espTargets.next();
			b.setMessage(targetsText("Цели ESP", Config.espTargets));
		}).dimensions(x, top + 196, BTN_W, 20).build());
	}

	@Override
	public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
		int left = (width - PANEL_W) / 2;
		int top = (height - PANEL_H) / 2;

		// жёлтая панель
		ctx.fill(left - 2, top - 2, left + PANEL_W + 2, top + PANEL_H + 2, COLOR_BORDER);
		ctx.fill(left, top, left + PANEL_W, top + PANEL_H, COLOR_PANEL);
		ctx.fill(left, top, left + PANEL_W, top + 22, COLOR_TITLE);

		Text title = Text.literal("LightningHub").formatted(Formatting.BOLD);
		ctx.drawText(textRenderer, title, left + (PANEL_W - textRenderer.getWidth(title)) / 2, top + 7,
				COLOR_TEXT_DARK, false);

		ctx.drawText(textRenderer, Text.literal("АВТО-АТАКА"), left + 15, top + 25, COLOR_TEXT_DARK, false);
		ctx.drawText(textRenderer, Text.literal("ESP"), left + 15, top + 161, COLOR_TEXT_DARK, false);

		super.render(ctx, mouseX, mouseY, delta); // кнопки и слайдеры
	}

	/** Без размытия фона - мир остаётся виден за меню. */
	@Override
	public void renderBackground(DrawContext context, int mouseX, int mouseY, float delta) {
	}

	@Override
	public boolean shouldPause() {
		return false;
	}

	@Override
	public void tick() {
		super.tick();
		if (client == null) return;
		boolean down = GLFW.glfwGetKey(client.getWindow().getHandle(), GLFW.GLFW_KEY_RIGHT_SHIFT) == GLFW.GLFW_PRESS;
		if (down && !shiftWasDown) {
			close(); // повторное нажатие Right Shift закрывает меню
		}
		shiftWasDown = down;
	}

	@Override
	public void removed() {
		Config.save();
	}

	private static Text toggleText(String name, boolean on) {
		return Text.literal(name + ": " + (on ? "ВКЛ" : "ВЫКЛ"))
				.formatted(on ? Formatting.YELLOW : Formatting.GRAY);
	}

	private static Text targetsText(String name, Config.Targets t) {
		return Text.literal(name + ": " + t.label).formatted(Formatting.YELLOW);
	}

	/** Слайдер в жёлтом стиле. */
	private static final class Slide extends SliderWidget {
		private final String name;
		private final String unit;
		private final double min;
		private final double max;
		private final boolean integer;
		private final DoubleConsumer setter;

		Slide(int x, int y, int w, int h, String name, String unit, double min, double max, double current,
				boolean integer, DoubleConsumer setter) {
			super(x, y, w, h, Text.empty(), (current - min) / (max - min));
			this.name = name;
			this.unit = unit;
			this.min = min;
			this.max = max;
			this.integer = integer;
			this.setter = setter;
			updateMessage();
		}

		private double actual() {
			double v = min + value * (max - min);
			return integer ? Math.round(v) : Math.round(v * 10.0) / 10.0;
		}

		@Override
		protected void updateMessage() {
			double v = actual();
			String s = integer ? String.valueOf((int) v) : String.format(Locale.ROOT, "%.1f", v);
			setMessage(Text.literal(name + ": " + s + unit).formatted(Formatting.YELLOW));
		}

		@Override
		protected void applyValue() {
			setter.accept(actual());
		}
	}
}
