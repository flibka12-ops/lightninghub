package com.lightninghub;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

import java.util.Random;

/**
 * Наводка (aim assist).
 * - Работает каждый кадр (а не раз в 50 мс) - поворот плавный и реакция мгновенная.
 * - Целится не в центр цели, а в ближайшую к прицелу точку хитбокса: если прицел уже на цели - камера не дёргается.
 * - Залипает на выбранной цели, пока она в зоне, - не прыгает между врагами.
 * - Упреждение: целится чуть впереди движущейся цели с поправкой на пинг.
 * - Если шкала урона почти готова - наводится быстрее, чтобы удар прошёл сразу.
 */
public final class Aim {
	private static final Random RNG = new Random();

	private static long lastFrameNs = 0L;
	private static long lastRunNs = 0L;

	private static Entity current = null;

	// Слежение за скоростью цели (по тикам).
	private static int trackId = -1;
	private static Vec3d trackPos = Vec3d.ZERO;
	private static Vec3d trackVel = Vec3d.ZERO;

	/** Каждый кадр (из HUD-колбэка). */
	public static void frame(MinecraftClient mc) {
		lastFrameNs = System.nanoTime();
		run(mc);
	}

	/** В начале тика: обновляем скорость цели; если кадры не идут (HUD скрыт на F1) - наводим отсюда. */
	public static void tick(MinecraftClient mc) {
		Entity t = current;
		if (t != null && t.isAlive()) {
			Vec3d pos = new Vec3d(t.getX(), t.getY(), t.getZ());
			if (t.getId() == trackId) {
				trackVel = trackVel.multiply(0.5).add(pos.subtract(trackPos).multiply(0.5));
			} else {
				trackId = t.getId();
				trackVel = Vec3d.ZERO;
			}
			trackPos = pos;
		} else {
			trackId = -1;
			trackVel = Vec3d.ZERO;
		}

		if (System.nanoTime() - lastFrameNs > 80_000_000L) {
			run(mc);
		}
	}

	private static void run(MinecraftClient mc) {
		long now = System.nanoTime();
		double dt = Math.min(0.1, Math.max(0.0, (now - lastRunNs) / 1.0e9));
		lastRunNs = now;
		double ticksF = dt * 20.0;

		Config.Settings s = Config.S;
		if (!s.aim) {
			current = null;
			return;
		}

		ClientPlayerEntity p = mc.player;
		if (p == null || mc.world == null || mc.currentScreen != null) {
			current = null;
			return;
		}
		if (!p.isAlive() || p.isSpectator()) {
			current = null;
			return;
		}

		// Режим "по клавише": работает только пока клавиша зажата.
		if (s.aimHold && !Binds.isDown(Binds.AIM_HOLD)) {
			current = null;
			return;
		}

		Vec3d eye = p.getEyePos();
		float curYaw = p.getYaw();
		float curPitch = p.getPitch();
		Vec3d dir = p.getRotationVec(1.0f);

		Entity t = pickTarget(mc, p, s, eye, curYaw, curPitch);
		current = t;
		if (t == null) return;

		// Упреждение: на сколько тиков вперёд сместить цель (задержка сети + ещё немного).
		Vec3d shift = Vec3d.ZERO;
		if (s.aimPredict && t.getId() == trackId) {
			double lead = 0.6 + latencyMs(mc, p) / 100.0;
			lead = MathHelper.clamp(lead, 0.6, 3.0);
			Vec3d v = trackVel;
			// Ограничиваем: не верим слишком большой "скорости" (телепорт, лаг).
			if (v.lengthSquared() < 1.5 * 1.5) {
				shift = new Vec3d(v.x * lead, 0.0, v.z * lead);
			}
		}

		Vec3d spot = Targeting.aimSpot(t, eye, dir, s.aimHead, shift);
		float[] a = Targeting.anglesTo(eye, spot);
		float dYaw = MathHelper.wrapDegrees(a[0] - curYaw);
		float dPitch = a[1] - curPitch;
		double dist = Math.hypot(dYaw, dPitch);
		if (dist < 0.12) return;

		// Скорость: доля оставшегося угла за тик, пересчитанная на реальное время кадра.
		double base = MathHelper.clamp(s.aimSpeed / 100.0, 0.01, 0.999);
		double k = 1.0 - Math.pow(1.0 - base, ticksF);
		// Удар почти готов - подтягиваем прицел быстрее.
		if (p.getAttackCooldownProgress(0.0f) >= 0.9f) k = Math.min(1.0, k * 1.5);

		float max = (float) (s.aimMaxTurn * ticksF);
		float stepYaw = MathHelper.clamp((float) (dYaw * k), -max, max);
		float stepPitch = MathHelper.clamp((float) (dPitch * k), -max, max);

		// Небольшая случайность, чтобы движение не было идеально ровным (слабее у самой цели).
		float jitter = (float) (s.aimRandom * 0.2 * ticksF * Math.min(1.0, dist / 3.0));
		stepYaw += (RNG.nextFloat() - 0.5f) * 2f * jitter;
		stepPitch += (RNG.nextFloat() - 0.5f) * 2f * jitter;

		p.setYaw(curYaw + stepYaw);
		p.setPitch(MathHelper.clamp(curPitch + stepPitch, -90f, 90f));
	}

	/** Выбор цели: прошлая остаётся, пока годится; иначе ближайшая к прицелу в поле зрения. */
	private static Entity pickTarget(MinecraftClient mc, ClientPlayerEntity p, Config.Settings s, Vec3d eye,
			float curYaw, float curPitch) {
		Entity keep = current;
		if (keep != null && keep.isAlive() && Targeting.attackable(p, keep, s.aimTargets)
				&& Targeting.reach(p, keep) <= s.aimRange
				&& delta(eye, keep, s, curYaw, curPitch) <= s.aimFov * 1.25
				&& Targeting.canSeeEntity(p, keep)) {
			return keep;
		}

		Entity best = null;
		double bestDelta = Double.MAX_VALUE;
		double far = (s.aimRange + 4.0) * (s.aimRange + 4.0);
		for (Entity e : mc.world.getEntities()) {
			if (p.squaredDistanceTo(e) > far) continue;
			if (!Targeting.attackable(p, e, s.aimTargets)) continue;
			if (Targeting.reach(p, e) > s.aimRange) continue;
			double d = delta(eye, e, s, curYaw, curPitch);
			if (d > s.aimFov || d >= bestDelta) continue;
			if (!Targeting.canSeeEntity(p, e)) continue;
			bestDelta = d;
			best = e;
		}
		return best;
	}

	private static double delta(Vec3d eye, Entity e, Config.Settings s, float curYaw, float curPitch) {
		float[] a = Targeting.anglesTo(eye, Targeting.aimPoint(e, s.aimHead));
		return Math.hypot(MathHelper.wrapDegrees(a[0] - curYaw), a[1] - curPitch);
	}

	private static double latencyMs(MinecraftClient mc, ClientPlayerEntity p) {
		try {
			if (mc.getNetworkHandler() == null) return 0.0;
			PlayerListEntry e = mc.getNetworkHandler().getPlayerListEntry(p.getUuid());
			return e == null ? 0.0 : Math.max(0, e.getLatency());
		} catch (Throwable t) {
			return 0.0;
		}
	}

	private Aim() {
	}
}
