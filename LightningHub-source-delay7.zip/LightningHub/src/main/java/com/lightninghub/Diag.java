package com.lightninghub;

import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;

/**
 * Журнал ударов: каждая строка - один удар (дистанция, пинг, скорость цели, угол до цели и т.д.) и результат.
 * Файл: .minecraft/config/lightninghub-hits.csv - его можно прислать, чтобы понять, почему удары не проходят.
 */
public final class Diag {
	private static int lines = 0;
	private static boolean started = false;

	private static Path file() {
		return FabricLoader.getInstance().getConfigDir().resolve("lightninghub-hits.csv");
	}

	public static void log(String line) {
		if (lines > 3000) return;
		try {
			Path f = file();
			if (!started) {
				started = true;
				Files.writeString(f, "landed,hpDropped,hurtSeen,dist,pingMs,tgtSpeed,angleDeg,hurtAtSend,selfSprint,selfGround,tgtGround,missStreak,range,rayOnTarget\n");
			}
			Files.writeString(f, line + "\n", StandardOpenOption.CREATE, StandardOpenOption.APPEND);
			lines++;
		} catch (IOException ignored) {
		}
	}

	private Diag() {
	}
}
