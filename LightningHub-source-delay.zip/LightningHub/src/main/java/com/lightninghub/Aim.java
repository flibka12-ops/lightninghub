package com.lightninghub;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

import java.util.Random;

/** Плавная наводка: поворачивает камеру к цели понемногу, а не мгновенно. */
public final class Aim {
	private static final Random RNG = new Random();

	public static void tick(MinecraftClient mc) {
		Config.Settings s = Config.S;
		if (!s.aim) return;

		ClientPlayerEntity p = mc.player;
		if (p == null || mc.world == null || mc.currentScreen != null) return;
		if (!p.isAlive() || p.isSpectator()) return;

		// Режим "по клавише": работает только пока клавиша зажата.
		if (s.aimHold && !Binds.isDown(Binds.AIM_HOLD)) return;

		Vec3d eye = p.getEyePos();
		float curYaw = p.getYaw();
		float curPitch = p.getPitch();

		// Выбираем цель, ближайшую к прицелу, в пределах поля зрения.
		float[] bestAngles = null;
		double bestDelta = Double.MAX_VALUE;
		for (Entity e : mc.world.getEntities()) {
			if (!Targeting.attackable(p, e, s.aimTargets)) continue;
			if (Targeting.reach(p, e) > s.aimRange) continue;
			if (!p.canSee(e)) continue;

			float[] a = Targeting.anglesTo(eye, Targeting.aimPoint(e, s.aimHead));
			double delta = Math.hypot(MathHelper.wrapDegrees(a[0] - curYaw), a[1] - curPitch);
			if (delta <= s.aimFov && delta < bestDelta) {
				bestDelta = delta;
				bestAngles = a;
			}
		}
		if (bestAngles == null || bestDelta < 0.4) return;

		float dYaw = MathHelper.wrapDegrees(bestAngles[0] - curYaw);
		float dPitch = bestAngles[1] - curPitch;

		float k = s.aimSpeed / 100f;
		float max = s.aimMaxTurn;
		float stepYaw = MathHelper.clamp(dYaw * k, -max, max);
		float stepPitch = MathHelper.clamp(dPitch * k, -max, max);

		// Небольшая случайность, чтобы движение не было идеально ровным.
		float jitter = (float) s.aimRandom * 0.2f;
		stepYaw += (RNG.nextFloat() - 0.5f) * 2f * jitter;
		stepPitch += (RNG.nextFloat() - 0.5f) * 2f * jitter;

		p.setYaw(curYaw + stepYaw);
		p.setPitch(MathHelper.clamp(curPitch + stepPitch, -90f, 90f));
	}

	private Aim() {
	}
}
