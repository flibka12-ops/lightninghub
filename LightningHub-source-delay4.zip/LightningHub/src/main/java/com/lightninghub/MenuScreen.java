package com.lightninghub;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.ClickableWidget;
import net.minecraft.client.gui.widget.SliderWidget;
import net.minecraft.text.Style;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.function.BooleanSupplier;
import java.util.function.Consumer;
import java.util.function.DoubleConsumer;
import java.util.function.IntConsumer;
import java.util.function.IntSupplier;
import java.util.function.Supplier;

/**
 * Жёлтое меню LightningHub с разделами (слева) и прокруткой (колесо мыши или кнопки ^ / v).
 * Открывается/закрывается Right Shift или кнопкой в меню паузы.
 */
public class MenuScreen extends Screen {
	private static final String[] TABS = {"Бой", "Визуал", "Интерфейс", "Разное", "Бинды"};
	private static final int SIDEBAR_W = 96;

	private static final int C_BORDER = 0xFFB8860B;
	private static final int C_TITLE = 0xFFFFC800;
	private static final int C_DARK = 0xFF2B2100;

	/** Строка списка: либо заголовок раздела, либо виджет. */
	private static final class Row {
		String header;
		ClickableWidget widget;
		int y; // позиция внутри списка (без учёта прокрутки)
	}

	private final List<Row> rows = new ArrayList<>();
	private final List<ButtonWidget> tabButtons = new ArrayList<>();

	private int tab = 0;
	private int scroll = 0;
	private int maxScroll = 0;

	private int left, top, right, bottom;
	private int cLeft, cRight, cTop, cBottom, cWidth;

	private String listening = null; // id функции, которой сейчас назначаем клавишу
	private boolean needRebuild = false;
	private boolean listenArmed = false; // ждём отпускания всех клавиш перед записью бинда
	private boolean shiftWasDown = true; // Right Shift ещё зажат в момент открытия

	public MenuScreen() {
		super(Text.literal("LightningHub"));
	}

	// ======================================================================= init

	@Override
	protected void init() {
		int pw = Math.min(width - 12, 440);
		int ph = Math.min(height - 12, 300);
		left = (width - pw) / 2;
		top = (height - ph) / 2;
		right = left + pw;
		bottom = top + ph;

		cLeft = left + SIDEBAR_W + 10;
		cRight = right - 14;
		cTop = top + 34;
		cBottom = bottom - 8;
		cWidth = cRight - cLeft;

		// Вкладки слева
		tabButtons.clear();
		for (int i = 0; i < TABS.length; i++) {
			final int idx = i;
			ButtonWidget b = ButtonWidget.builder(tabLabel(i), btn -> {
				tab = idx;
				scroll = 0;
				listening = null;
				refreshTabLabels();
				needRebuild = true;
			}).dimensions(left + 5, top + 34 + i * 22, SIDEBAR_W - 10, 20).build();
			addDrawableChild(b);
			tabButtons.add(b);
		}

		// Кнопки прокрутки
		int half = (SIDEBAR_W - 14) / 2;
		addDrawableChild(ButtonWidget.builder(Text.literal("^").formatted(Formatting.YELLOW), b -> scrollBy(-72))
				.dimensions(left + 5, bottom - 26, half, 20).build());
		addDrawableChild(ButtonWidget.builder(Text.literal("v").formatted(Formatting.YELLOW), b -> scrollBy(72))
				.dimensions(left + 9 + half, bottom - 26, half, 20).build());

		rebuild();
	}

	private Text tabLabel(int i) {
		return i == tab
				? Text.literal(TABS[i]).formatted(Formatting.YELLOW, Formatting.BOLD)
				: Text.literal(TABS[i]).formatted(Formatting.GRAY);
	}

	private void refreshTabLabels() {
		for (int i = 0; i < tabButtons.size(); i++) {
			tabButtons.get(i).setMessage(tabLabel(i));
		}
	}

	// ======================================================================= список

	private void rebuild() {
		for (Row r : rows) {
			if (r.widget != null) remove(r.widget);
		}
		rows.clear();
		setFocused(null);

		switch (tab) {
			case 0 -> buildCombat();
			case 1 -> buildVisuals();
			case 2 -> buildInterface();
			case 3 -> buildMisc();
			default -> buildBinds();
		}
		layout();
	}

	private void header(String text) {
		Row r = new Row();
		r.header = text;
		rows.add(r);
	}

	private void add(ClickableWidget w) {
		addSelectableChild(w);
		Row r = new Row();
		r.widget = w;
		rows.add(r);
	}

	/** Расставляет строки с учётом прокрутки и прячет те, что не помещаются целиком. */
	private void layout() {
		int y = 0;
		for (Row r : rows) {
			r.y = y;
			y += (r.header != null) ? 20 : 24;
		}
		maxScroll = Math.max(0, y - (cBottom - cTop));
		scroll = Math.max(0, Math.min(maxScroll, scroll));

		for (Row r : rows) {
			if (r.widget == null) continue;
			int wy = cTop + r.y - scroll;
			r.widget.setX(cLeft);
			r.widget.setY(wy);
			r.widget.visible = wy >= cTop && wy + 20 <= cBottom;
		}
	}

	private void scrollBy(int delta) {
		scroll += delta;
		layout();
	}

	@Override
	public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
		scrollBy((int) (-verticalAmount * 24));
		return true;
	}

	// ======================================================================= разделы

	private void buildCombat() {
		Config.Settings s = Config.S;

		header("АВТО-АТАКА");
		add(toggle("Авто-атака", () -> s.autoAttack, v -> s.autoAttack = v));
		add(targets("Цели", () -> s.aaTargets, v -> s.aaTargets = v));
		add(slider("Дальность", " бл.", 1.0, 4.5, s.aaRange, false, v -> s.aaRange = v));
		add(slider("Шанс попадания", "%", 0, 100, s.aaChance, true, v -> s.aaChance = (int) Math.round(v)));
		add(toggle("Легит: бить только при наведении", () -> s.aaNeedAim, v -> s.aaNeedAim = v));
		add(toggle("Только в прямой видимости", () -> s.aaNeedSight, v -> s.aaNeedSight = v));
		add(toggle("Мгновенная реакция (каждый кадр, без задержки)", () -> s.aaInstant, v -> s.aaInstant = v));
		add(toggle("Запас +1 тик (если сервер режет урон)", () -> s.aaMargin, v -> s.aaMargin = v));
		add(toggle("Авто-поворот на цель при ударе", () -> s.aaFace, v -> s.aaFace = v));
		add(slider("Угол захвата авто-поворота", "°", 10, 180, s.aaFov, true, v -> s.aaFov = (int) Math.round(v)));
		add(toggle("Залипать на цели", () -> s.aaSticky, v -> s.aaSticky = v));
		add(toggle("Trigger Delay (задержка удара)", () -> s.aaTriggerDelay, v -> s.aaTriggerDelay = v));
		add(slider("Delay от", " мс", 0, 1000, s.aaDelayMin, true, v -> {
			s.aaDelayMin = (int) Math.round(v);
			if (s.aaDelayMax < s.aaDelayMin) {
				s.aaDelayMax = s.aaDelayMin;
				needRebuild = true;
			}
		}));
		add(slider("Delay до", " мс", 0, 1000, s.aaDelayMax, true, v -> {
			s.aaDelayMax = (int) Math.round(v);
			if (s.aaDelayMin > s.aaDelayMax) {
				s.aaDelayMin = s.aaDelayMax;
				needRebuild = true;
			}
		}));
		add(toggle("Криты: ждать падения в прыжке", () -> s.aaCrit, v -> s.aaCrit = v));
		add(prio("Приоритет (без наведения)", () -> s.aaPriority, v -> s.aaPriority = v));
		add(toggle("Не бить союзников по команде", () -> s.ignoreTeam, v -> s.ignoreTeam = v));
		add(slider("Хитбокс врагов (+)", "", 0.0, 0.5, s.hitbox, false, v -> s.hitbox = v));

		header("НАВОДКА (AIM ASSIST)");
		add(toggle("Наводка", () -> s.aim, v -> s.aim = v));
		add(toggle("Только при зажатой клавише", () -> s.aimHold, v -> s.aimHold = v));
		add(targets("Цели наводки", () -> s.aimTargets, v -> s.aimTargets = v));
		add(slider("Поле зрения (FOV)", "°", 5, 180, s.aimFov, true, v -> s.aimFov = (int) Math.round(v)));
		add(slider("Скорость", "%", 5, 100, s.aimSpeed, true, v -> s.aimSpeed = (int) Math.round(v)));
		add(slider("Макс. поворот за тик", "°", 1, 30, s.aimMaxTurn, true, v -> s.aimMaxTurn = (int) Math.round(v)));
		add(slider("Дальность наводки", " бл.", 1.0, 8.0, s.aimRange, false, v -> s.aimRange = v));
		add(slider("Случайность", "", 0.0, 5.0, s.aimRandom, false, v -> s.aimRandom = v));
		add(toggle("Целиться в голову (иначе в корпус)", () -> s.aimHead, v -> s.aimHead = v));
		add(toggle("Упреждение (целиться вперёд цели)", () -> s.aimPredict, v -> s.aimPredict = v));
	}

	private void buildVisuals() {
		Config.Settings s = Config.S;

		header("ESP (КОНТУР СКВОЗЬ СТЕНЫ)");
		add(toggle("ESP", () -> s.esp, v -> s.esp = v));
		add(toggle("Показывать игроков", () -> s.espPlayers, v -> s.espPlayers = v));
		add(toggle("Показывать враждебных мобов", () -> s.espHostile, v -> s.espHostile = v));
		add(toggle("Показывать животных и прочих", () -> s.espPassive, v -> s.espPassive = v));
		add(toggle("Показывать невидимых", () -> s.espInvisible, v -> s.espInvisible = v));

		header("ЦВЕТА");
		add(colorBtn("Цвет игроков", () -> s.espPlayerColor, v -> s.espPlayerColor = v));
		add(colorBtn("Цвет мобов", () -> s.espHostileColor, v -> s.espHostileColor = v));
		add(colorBtn("Цвет животных", () -> s.espPassiveColor, v -> s.espPassiveColor = v));

		header("ДИСТАНЦИЯ");
		add(slider("Макс. дистанция (128 = без лимита)", " бл.", 8, 128, s.espMaxDist, true,
				v -> s.espMaxDist = (int) Math.round(v)));
	}

	private void buildInterface() {
		Config.Settings s = Config.S;

		header("ЗДОРОВЬЕ ВРАГА");
		add(toggle("Таргет-HUD (HP цели)", () -> s.targetHud, v -> s.targetHud = v));

		header("СПИСОК РЯДОМ (ИМЯ + HP + ДИСТАНЦИЯ)");
		add(toggle("Список рядом", () -> s.nearbyList, v -> s.nearbyList = v));
		add(toggle("Только игроки", () -> s.nearbyPlayersOnly, v -> s.nearbyPlayersOnly = v));
		add(slider("Радиус", " бл.", 8, 64, s.nearbyRange, true, v -> s.nearbyRange = (int) Math.round(v)));
		add(slider("Строк в списке", "", 1, 10, s.nearbyCount, true, v -> s.nearbyCount = (int) Math.round(v)));

		header("ОБЩЕЕ");
		add(toggle("Водяной знак + FPS", () -> s.watermark, v -> s.watermark = v));
		add(toggle("Список включённых функций", () -> s.moduleList, v -> s.moduleList = v));
		add(toggle("Координаты", () -> s.coords, v -> s.coords = v));
	}

	private void buildMisc() {
		Config.Settings s = Config.S;

		header("РАЗНОЕ");
		add(toggle("Фуллбрайт (ночное зрение)", () -> s.fullbright, v -> s.fullbright = v));
		add(toggle("Авто-спринт", () -> s.autoSprint, v -> s.autoSprint = v));
		add(toggle("Авто-тотем (во вторую руку)", () -> s.autoTotem, v -> s.autoTotem = v));
	}

	private void buildBinds() {
		header("НАЖМИ НА КНОПКУ, ПОТОМ НА КЛАВИШУ");
		header("Backspace - убрать бинд");
		for (Modules.Mod m : Modules.ALL) {
			add(bindBtn(m.id(), m.name()));
		}
		header("КЛАВИША НАВОДКИ (УДЕРЖИВАТЬ)");
		add(bindBtn(Binds.AIM_HOLD, "Удерживать для наводки"));
	}

	// ======================================================================= виджеты

	private ButtonWidget btn(Supplier<Text> label, Runnable action) {
		return ButtonWidget.builder(label.get(), b -> {
			action.run();
			b.setMessage(label.get());
		}).dimensions(0, 0, cWidth, 20).build();
	}

	private ButtonWidget toggle(String name, BooleanSupplier get, Consumer<Boolean> set) {
		return btn(() -> Text.literal(name + ": " + (get.getAsBoolean() ? "ВКЛ" : "ВЫКЛ"))
						.formatted(get.getAsBoolean() ? Formatting.YELLOW : Formatting.GRAY),
				() -> set.accept(!get.getAsBoolean()));
	}

	private ButtonWidget targets(String name, Supplier<Config.Targets> get, Consumer<Config.Targets> set) {
		return btn(() -> Text.literal(name + ": " + get.get().label).formatted(Formatting.YELLOW),
				() -> set.accept(get.get().next()));
	}

	private ButtonWidget prio(String name, Supplier<Config.Priority> get, Consumer<Config.Priority> set) {
		return btn(() -> Text.literal(name + ": " + get.get().label).formatted(Formatting.YELLOW),
				() -> set.accept(get.get().next()));
	}

	private ButtonWidget colorBtn(String name, IntSupplier get, IntConsumer set) {
		return btn(() -> {
					int i = Math.max(0, Math.min(Config.COLORS.length - 1, get.getAsInt()));
					return Text.literal(name + ": " + Config.COLOR_NAMES[i])
							.setStyle(Style.EMPTY.withColor(Config.COLORS[i]));
				},
				() -> set.accept((get.getAsInt() + 1) % Config.COLORS.length));
	}

	private ButtonWidget bindBtn(String id, String name) {
		return btn(() -> {
					boolean l = id.equals(listening);
					String key = l ? "нажми клавишу..." : Binds.keyName(Binds.get(id));
					return Text.literal(name + ": [" + key + "]")
							.formatted(l ? Formatting.WHITE : Formatting.YELLOW);
				},
				() -> {
					listening = id.equals(listening) ? null : id;
					listenArmed = false;
					needRebuild = true;
				});
	}

	private Slide slider(String name, String unit, double min, double max, double current, boolean integer,
			DoubleConsumer setter) {
		return new Slide(cWidth, name, unit, min, max, current, integer, setter);
	}

	/** Слайдер в жёлтом стиле. */
	private static final class Slide extends SliderWidget {
		private final String name;
		private final String unit;
		private final double min;
		private final double max;
		private final boolean integer;
		private final DoubleConsumer setter;

		Slide(int width, String name, String unit, double min, double max, double current, boolean integer,
				DoubleConsumer setter) {
			super(0, 0, width, 20, Text.empty(), (current - min) / (max - min));
			this.name = name;
			this.unit = unit;
			this.min = min;
			this.max = max;
			this.integer = integer;
			this.setter = setter;
			updateMessage();
		}

		private double actual() {
			double v = min + value * (max - min);
			return integer ? Math.round(v) : Math.round(v * 10.0) / 10.0;
		}

		@Override
		protected void updateMessage() {
			double v = actual();
			String s = integer ? String.valueOf((int) v) : String.format(Locale.ROOT, "%.1f", v);
			setMessage(Text.literal(name + ": " + s + unit).formatted(Formatting.YELLOW));
		}

		@Override
		protected void applyValue() {
			setter.accept(actual());
		}
	}

	// ======================================================================= отрисовка

	@Override
	public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
		// рамка и жёлтая панель
		ctx.fill(left - 2, top - 2, right + 2, bottom + 2, C_BORDER);
		ctx.fillGradient(left, top, right, bottom, 0xFFFFE066, 0xFFFFB800);

		// заголовок
		ctx.fill(left, top, right, top + 26, C_TITLE);
		ctx.fill(left, top + 26, right, top + 27, C_BORDER);
		ctx.drawText(textRenderer, Text.literal("LightningHub").formatted(Formatting.BOLD), left + 10, top + 9,
				C_DARK, false);
		Text hint = Text.literal("Закрыть: Right Shift / Esc");
		ctx.drawText(textRenderer, hint, right - 8 - textRenderer.getWidth(hint), top + 9, 0xFF6B5000, false);

		// боковая панель
		ctx.fill(left, top + 27, left + SIDEBAR_W, bottom, 0x30000000);
		ctx.fill(left + SIDEBAR_W, top + 27, left + SIDEBAR_W + 1, bottom, C_BORDER);

		// заголовки разделов внутри списка
		for (Row r : rows) {
			if (r.header == null) continue;
			int y = cTop + r.y - scroll;
			if (y >= cTop - 2 && y + 14 <= cBottom + 2) {
				ctx.drawText(textRenderer, Text.literal(r.header), cLeft, y + 3, C_DARK, false);
				ctx.fill(cLeft, y + 14, cRight, y + 15, 0xAA8A6100);
			}
		}

		// полоса прокрутки
		if (maxScroll > 0) {
			int trackX = right - 9;
			int trackH = cBottom - cTop;
			ctx.fill(trackX, cTop, trackX + 4, cBottom, 0x40000000);
			int thumbH = Math.max(16, trackH * trackH / (trackH + maxScroll));
			int thumbY = cTop + (trackH - thumbH) * scroll / maxScroll;
			ctx.fill(trackX, thumbY, trackX + 4, thumbY + thumbH, 0xFF8A6100);
		}

		super.render(ctx, mouseX, mouseY, delta); // вкладки и кнопки прокрутки

		// виджеты списка (рисуем сами, чтобы скрывать вылезающие за край)
		for (Row r : rows) {
			if (r.widget != null && r.widget.visible) {
				r.widget.render(ctx, mouseX, mouseY, delta);
			}
		}
	}

	@Override
	public boolean shouldPause() {
		return false;
	}

	// ======================================================================= тик

	@Override
	public void tick() {
		super.tick();
		if (client == null) return;
		try {
			long handle = client.getWindow().getHandle();

			if (needRebuild) {
				needRebuild = false;
				rebuild();
			}

			// Ожидаем клавишу для бинда: сначала ждём, пока все клавиши отпущены.
			if (listening != null) {
				if (!listenArmed) {
					listenArmed = Binds.pollKey(handle) < 0;
				} else {
					int k = Binds.pollKey(handle);
					if (k >= 0) {
						boolean clear = k == GLFW.GLFW_KEY_BACKSPACE || k == GLFW.GLFW_KEY_DELETE;
						Binds.set(listening, clear ? -1 : k);
						listening = null;
						needRebuild = true;
						if (k == GLFW.GLFW_KEY_RIGHT_SHIFT) shiftWasDown = true; // не закрывать меню этим же нажатием
					}
				}
			}

			// Повторное нажатие Right Shift закрывает меню (если не назначаем клавишу)
			boolean down = Binds.keyDown(handle, GLFW.GLFW_KEY_RIGHT_SHIFT);
			if (down && !shiftWasDown && listening == null) {
				close();
			}
			shiftWasDown = down;
		} catch (Throwable t) {
			LightningHubClient.warn(t);
		}
	}

	@Override
	public void removed() {
		Config.save();
	}
}
