package com.wardenvisual;

/** Color with hue / saturation / brightness / alpha and an optional rainbow mode. */
public final class Col {
    public float h, s, b, a = 1f;
    public boolean rainbow;

    public Col(int rgb) {
        set(rgb);
    }

    public void set(int rgb) {
        float r = ((rgb >> 16) & 255) / 255f, g = ((rgb >> 8) & 255) / 255f, bl = (rgb & 255) / 255f;
        float max = Math.max(r, Math.max(g, bl)), min = Math.min(r, Math.min(g, bl));
        float d = max - min;
        b = max;
        s = max == 0 ? 0 : d / max;
        float hh;
        if (d == 0) hh = 0;
        else if (max == r) hh = ((g - bl) / d) % 6f;
        else if (max == g) hh = (bl - r) / d + 2f;
        else hh = (r - g) / d + 4f;
        hh /= 6f;
        if (hh < 0) hh += 1f;
        h = hh;
    }

    public static int hsv(float h, float s, float v) {
        h = h - (float) Math.floor(h);
        float c = v * s;
        float x = c * (1 - Math.abs((h * 6f) % 2f - 1f));
        float m = v - c;
        float r, g, bl;
        int i = (int) (h * 6f);
        switch (i) {
            case 0 -> { r = c; g = x; bl = 0; }
            case 1 -> { r = x; g = c; bl = 0; }
            case 2 -> { r = 0; g = c; bl = x; }
            case 3 -> { r = 0; g = x; bl = c; }
            case 4 -> { r = x; g = 0; bl = c; }
            default -> { r = c; g = 0; bl = x; }
        }
        int ri = Math.round((r + m) * 255), gi = Math.round((g + m) * 255), bi = Math.round((bl + m) * 255);
        return (ri << 16) | (gi << 8) | bi;
    }

    public float hue() {
        return rainbow ? (System.currentTimeMillis() % 5000L) / 5000f : h;
    }

    public int rgb() {
        return hsv(hue(), s, b);
    }

    public int argb() {
        return (Math.round(a * 255) << 24) | rgb();
    }

    /** Same color with another alpha multiplier (0..1). */
    public int argb(float mul) {
        return (Math.max(0, Math.min(255, Math.round(a * mul * 255))) << 24) | rgb();
    }
}
