package com.lightninghub;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.decoration.ArmorStandEntity;
import net.minecraft.text.Text;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;

/** Всё, что рисуется поверх игры: здоровье цели, список рядом, водяной знак, список модулей, координаты. */
public final class Hud {
	private static final int GOLD = 0xFFFFD93B;
	private static final int BORDER = 0xFFB8860B;
	private static final int BG = 0xCC1A1400;

	public static void render(DrawContext ctx, RenderTickCounter tickCounter) {
		MinecraftClient mc = MinecraftClient.getInstance();
		if (mc.player == null || mc.world == null || mc.options.hudHidden) return;
		Config.Settings s = Config.S;
		TextRenderer tr = mc.textRenderer;

		int y = 4;
		if (s.watermark) {
			String t = "LightningHub  |  FPS " + mc.getCurrentFps();
			int w = tr.getWidth(t);
			ctx.fill(2, y - 2, 8 + w, y + 10, BG);
			ctx.fill(2, y - 2, 4, y + 10, GOLD);
			text(ctx, tr, t, 6, y, GOLD);
			y += 16;
		}
		if (s.coords) {
			ClientPlayerEntity p = mc.player;
			String t = String.format(Locale.ROOT, "XYZ: %.0f  %.0f  %.0f", p.getX(), p.getY(), p.getZ());
			int w = tr.getWidth(t);
			ctx.fill(2, y - 2, 8 + w, y + 10, BG);
			ctx.fill(2, y - 2, 4, y + 10, GOLD);
			text(ctx, tr, t, 6, y, 0xFFFFFFFF);
			y += 16;
		}
		// Что сейчас делает авто-атака (и почему не бьёт).
		if (s.autoAttack && AutoAttack.status != null) {
			String t = "АА: " + AutoAttack.status;
			int w = tr.getWidth(t);
			ctx.fill(2, y - 2, 8 + w, y + 10, BG);
			ctx.fill(2, y - 2, 4, y + 10, GOLD);
			text(ctx, tr, t, 6, y, 0xFFFFFFFF);
			y += 16;
		}
		// Ошибка внутри мода (перехвачена, чтобы не ронять игру).
		if (LightningHubClient.lastError != null) {
			String t = "ОШИБКА МОДА: " + LightningHubClient.lastError;
			int w = tr.getWidth(t);
			ctx.fill(2, y - 2, 8 + w, y + 10, 0xCC400000);
			ctx.fill(2, y - 2, 4, y + 10, 0xFFFF3B3B);
			text(ctx, tr, t, 6, y, 0xFFFFB0B0);
			y += 16;
		}
		if (s.nearbyList) {
			nearby(mc, ctx, tr, y);
		}
		if (s.moduleList) {
			moduleList(mc, ctx, tr);
		}
		if (s.targetHud) {
			targetHud(mc, ctx, tr);
		}
	}

	// ---------------------------------------------------------------- Таргет-HUD

	private static LivingEntity hudTarget(MinecraftClient mc) {
		Entity c = Targeting.aimedAt(mc, mc.player, Config.Targets.ALL, 8.0, false, false);
		if (c instanceof LivingEntity le) {
			return le;
		}
		LivingEntity last = AutoAttack.lastTarget;
		if (last != null && last.isAlive() && System.currentTimeMillis() - AutoAttack.lastTargetTime < 3000) {
			return last;
		}
		return null;
	}

	private static void targetHud(MinecraftClient mc, DrawContext ctx, TextRenderer tr) {
		LivingEntity t = hudTarget(mc);
		if (t == null) return;

		int w = AutoAttack.hiddenHp >= 2 ? 196 : 134;
		int h = 50;
		int x = mc.getWindow().getScaledWidth() / 2 + 24;
		int y = mc.getWindow().getScaledHeight() / 2 + 8;

		ctx.fill(x - 1, y - 1, x + w + 1, y + h + 1, BORDER);
		ctx.fill(x, y, x + w, y + h, BG);

		text(ctx, tr, t.getName().getString(), x + 5, y + 4, GOLD);

		float hp = Math.max(0f, t.getHealth());
		float max = Math.max(1f, t.getMaxHealth());
		float abs = Math.max(0f, t.getAbsorptionAmount());
		float ratio = Math.min(1f, hp / max);

		int bx = x + 5;
		int by = y + 17;
		int bw = w - 10;
		ctx.fill(bx, by, bx + bw, by + 7, 0xFF3A3000);
		ctx.fill(bx, by, bx + (int) (bw * ratio), by + 7, hpColor(ratio));
		if (abs > 0f) {
			ctx.fill(bx, by + 7, bx + (int) (bw * Math.min(1f, abs / max)), by + 9, GOLD);
		}

		String info = String.format(Locale.ROOT, "%.1f / %.1f HP", hp, max);
		if (abs > 0f) info += String.format(Locale.ROOT, "  (+%.1f)", abs);
		text(ctx, tr, info, x + 5, y + 27, 0xFFFFFFFF);

		// Сколько ударов авто-атаки реально прошло. Если цель получает урон (краснеет),
		// а HP не меняется - сервер скрывает здоровье игроков.
		if (AutoAttack.sent > 0) {
			boolean hidden = AutoAttack.hiddenHp >= 2;
			String st = "Удары: " + AutoAttack.landed + "/" + AutoAttack.sent;
			if (hidden) st += "  (сервер скрывает HP)";
			text(ctx, tr, st, x + 5, y + 39, hidden ? GOLD : 0xFFB0B0B0);
		}
	}

	// ---------------------------------------------------------------- Список рядом

	private static void nearby(MinecraftClient mc, DrawContext ctx, TextRenderer tr, int startY) {
		Config.Settings s = Config.S;
		ClientPlayerEntity p = mc.player;
		Config.Targets mode = s.nearbyPlayersOnly ? Config.Targets.PLAYERS : Config.Targets.ALL;

		List<LivingEntity> list = new ArrayList<>();
		for (Entity e : mc.world.getEntities()) {
			if (!Targeting.valid(p, e, mode)) continue;
			if (p.distanceTo(e) > s.nearbyRange) continue;
			list.add((LivingEntity) e);
		}
		list.sort(Comparator.<LivingEntity>comparingDouble(e -> p.squaredDistanceTo(e)));

		int y = startY;
		int shown = 0;
		for (LivingEntity e : list) {
			if (shown >= s.nearbyCount) break;
			float hp = Math.max(0f, e.getHealth());
			float max = Math.max(1f, e.getMaxHealth());
			String line = String.format(Locale.ROOT, "%s  %.1f HP  %.0fм",
					e.getName().getString(), hp, p.distanceTo(e));
			int w = tr.getWidth(line);
			ctx.fill(2, y - 2, 8 + w, y + 10, BG);
			ctx.fill(2, y - 2, 4, y + 10, hpColor(Math.min(1f, hp / max)));
			text(ctx, tr, line, 6, y, 0xFFFFFFFF);
			y += 13;
			shown++;
		}
	}

	// ---------------------------------------------------------------- Список модулей

	private static void moduleList(MinecraftClient mc, DrawContext ctx, TextRenderer tr) {
		List<String> names = new ArrayList<>();
		for (Modules.Mod m : Modules.ALL) {
			if (m.enabled()) names.add(m.name());
		}
		names.sort(Comparator.comparingInt((String n) -> tr.getWidth(n)).reversed());

		int right = mc.getWindow().getScaledWidth() - 3;
		int y = 3;
		for (String n : names) {
			int w = tr.getWidth(n);
			ctx.fill(right - w - 7, y - 1, right + 1, y + 10, BG);
			ctx.fill(right - 1, y - 1, right + 1, y + 10, GOLD);
			text(ctx, tr, n, right - w - 4, y + 1, GOLD);
			y += 11;
		}
	}

	// ---------------------------------------------------------------- Утилиты

	private static int hpColor(float ratio) {
		if (ratio > 0.6f) return 0xFF55FF55;
		if (ratio > 0.3f) return 0xFFFFD93B;
		return 0xFFFF5555;
	}

	private static void text(DrawContext ctx, TextRenderer tr, String s, int x, int y, int color) {
		ctx.drawText(tr, Text.literal(s), x, y, color, true);
	}

	private Hud() {
	}
}
