package com.wardenvisual.mixin;

import com.wardenvisual.Diag;
import com.wardenvisual.Features;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.GameRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** FOV changer and zoom: scales the final FOV so sprint/speed effects are kept. */
@Mixin(GameRenderer.class)
public abstract class GameRendererMixin {
    @Inject(method = "getFov", at = @At("RETURN"), cancellable = true, require = 0)
    private void wardenvisual$fov(CallbackInfoReturnable<Float> cir) {
        int target;
        if (Features.ZOOM.on) target = Features.ZOOM.v("v");
        else if (Features.FOV.on) target = Features.FOV.v("v");
        else return;
        double opt = MinecraftClient.getInstance().options.getFov().getValue();
        if (opt < 1) return;
        float base = cir.getReturnValue();
        Diag.fov++;
        cir.setReturnValue((float) (base * (target / opt)));
    }
}
