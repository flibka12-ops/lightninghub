package com.wardenvisual;

import com.mojang.brigadier.Command;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.fabricmc.fabric.api.client.screen.v1.Screens;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.GameMenuScreen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

public class WardenVisualClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        Features.load();

        // HUD: ESP, watermark, potion list, toasts
        HudElementRegistry.attachElementBefore(
                VanillaHudElements.CHAT,
                Identifier.of("wardenvisual", "overlay"),
                (context, tickCounter) -> Hud.render(context, tickCounter));

        // binds (menu key included) + time warp, every client tick
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            Keys.poll();
            if (Features.TIME.on && client.world != null) {
                client.world.setTime(client.world.getTime(), Features.TIME.v("t"), false);
                Diag.time++;
            }
        });

        // /warden opens the menu (works without a keyboard)
        ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) ->
                dispatcher.register(ClientCommandManager.literal("warden").executes(ctx -> {
                    MinecraftClient mc = MinecraftClient.getInstance();
                    mc.send(() -> mc.setScreen(new WardenMenuScreen()));
                    return Command.SINGLE_SUCCESS;
                })));

        // Button on the pause menu (for touch devices)
        ScreenEvents.AFTER_INIT.register((client, screen, scaledWidth, scaledHeight) -> {
            if (screen instanceof GameMenuScreen) {
                Screens.getButtons(screen).add(
                        ButtonWidget.builder(Text.literal("Warden Visual"),
                                        b -> client.setScreen(new WardenMenuScreen()))
                                .dimensions(scaledWidth - 108, 6, 102, 20)
                                .build());
            }
        });
    }
}
