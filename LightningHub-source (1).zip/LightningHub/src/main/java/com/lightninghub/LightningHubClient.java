package com.lightninghub;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.fabricmc.fabric.api.client.screen.v1.Screens;
import net.minecraft.client.gui.screen.GameMenuScreen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.Identifier;
import org.lwjgl.glfw.GLFW;

public class LightningHubClient implements ClientModInitializer {
	public static final String MOD_ID = "lightninghub";

	private static KeyBinding openMenu;

	@Override
	public void onInitializeClient() {
		Config.load();

		// Right Shift открывает меню.
		openMenu = KeyBindingHelper.registerKeyBinding(new KeyBinding(
				"key.lightninghub.menu",
				InputUtil.Type.KEYSYM,
				GLFW.GLFW_KEY_RIGHT_SHIFT,
				KeyBinding.Category.create(Identifier.of(MOD_ID, "main"))
		));

		// Кнопка в меню паузы (Esc) - для телефонов, где нет клавиши Right Shift.
		ScreenEvents.AFTER_INIT.register((client, screen, scaledWidth, scaledHeight) -> {
			if (screen instanceof GameMenuScreen) {
				Screens.getButtons(screen).add(
						ButtonWidget.builder(
								Text.literal("LightningHub").formatted(Formatting.YELLOW),
								b -> client.setScreen(new MenuScreen())
						).dimensions(6, scaledHeight - 26, 110, 20).build()
				);
			}
		});

		// HUD: здоровье цели, список рядом, водяной знак и т.д.
		HudElementRegistry.attachElementBefore(
				VanillaHudElements.CHAT,
				Identifier.of(MOD_ID, "hud"),
				Hud::render
		);

		ClientTickEvents.END_CLIENT_TICK.register(client -> {
			while (openMenu.wasPressed()) {
				if (client.currentScreen == null) {
					client.setScreen(new MenuScreen());
				}
			}
			Binds.tick(client);
			Aim.tick(client);
			AutoAttack.tick(client);
			Misc.tick(client);
		});
	}
}
