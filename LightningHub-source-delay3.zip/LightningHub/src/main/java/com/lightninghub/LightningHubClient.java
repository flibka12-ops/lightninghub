package com.lightninghub;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.fabricmc.fabric.api.client.screen.v1.Screens;
import net.minecraft.client.gui.screen.GameMenuScreen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.Identifier;
import org.lwjgl.glfw.GLFW;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class LightningHubClient implements ClientModInitializer {
	public static final String MOD_ID = "lightninghub";
	private static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

	private static KeyBinding openMenu;
	private static boolean warned = false;

	/** Последняя перехваченная ошибка мода - показывается красной строкой на экране. */
	public static volatile String lastError = null;

	/** Ошибка внутри мода не должна ронять игру: пишем в лог, показываем на экране и идём дальше. */
	public static void warn(Throwable t) {
		String msg = t.getClass().getSimpleName() + ": " + t.getMessage();
		if (msg.length() > 90) msg = msg.substring(0, 90);
		lastError = msg;
		if (warned) return;
		warned = true;
		LOGGER.error("LightningHub: внутренняя ошибка (повторные в лог не выводятся)", t);
	}

	/** Выполняет шаг, не давая его ошибке сломать остальные функции. */
	private static void safe(Runnable r) {
		try {
			r.run();
		} catch (Throwable t) {
			warn(t);
		}
	}

	@Override
	public void onInitializeClient() {
		Config.load();

		// Right Shift открывает меню.
		openMenu = KeyBindingHelper.registerKeyBinding(new KeyBinding(
				"key.lightninghub.menu",
				InputUtil.Type.KEYSYM,
				GLFW.GLFW_KEY_RIGHT_SHIFT,
				KeyBinding.Category.create(Identifier.of(MOD_ID, "main"))
		));

		// Кнопка в меню паузы (Esc) - для телефонов, где нет клавиши Right Shift.
		ScreenEvents.AFTER_INIT.register((client, screen, scaledWidth, scaledHeight) -> {
			if (screen instanceof GameMenuScreen) {
				Screens.getButtons(screen).add(
						ButtonWidget.builder(
								Text.literal("LightningHub").formatted(Formatting.YELLOW),
								b -> client.setScreen(new MenuScreen())
						).dimensions(6, scaledHeight - 26, 110, 20).build()
				);
			}
		});

		// HUD: здоровье цели, список рядом, водяной знак и т.д.
		HudElementRegistry.attachElementBefore(
				VanillaHudElements.CHAT,
				Identifier.of(MOD_ID, "hud"),
				(ctx, tickCounter) -> {
					// Каждый кадр: наводка и авто-атака реагируют сразу, а не раз в 50 мс (тик).
					safe(() -> Aim.frame(net.minecraft.client.MinecraftClient.getInstance()));
					safe(() -> AutoAttack.frame(net.minecraft.client.MinecraftClient.getInstance()));
					safe(() -> Hud.render(ctx, tickCounter));
				}
		);

		// Наводка - в начале тика: новые углы попадут в пакет движения этого же тика,
		// и только потом (в конце тика) произойдёт удар.
		ClientTickEvents.START_CLIENT_TICK.register(client -> safe(() -> Aim.tick(client)));

		ClientTickEvents.END_CLIENT_TICK.register(client -> {
			safe(() -> {
				while (openMenu.wasPressed()) {
					if (client.currentScreen == null) {
						client.setScreen(new MenuScreen());
					}
				}
			});
			safe(() -> Binds.tick(client));
			safe(() -> AutoAttack.tick(client));
			safe(() -> AutoTotem.tick(client));
			safe(() -> Misc.tick(client));
		});
	}
}
