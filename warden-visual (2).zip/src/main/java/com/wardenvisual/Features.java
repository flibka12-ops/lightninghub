package com.wardenvisual;

import net.fabricmc.loader.api.FabricLoader;
import org.lwjgl.glfw.GLFW;

import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

/** All features, their defaults and persistence (config/wardenvisual.properties). */
public final class Features {
    public static final String[] TABS = {"ESP", "WORLD", "HUD", "MISC"};
    public static final List<Feature> ALL = new ArrayList<>();

    private static Feature reg(Feature f) {
        ALL.add(f);
        return f;
    }

    private static final int ACCENT = 0x21D6C4;

    // ---- ESP ----
    public static final Feature ESP_RANGE = reg(new Feature("esprange", "ESP Range", "ESP")
            .sliderRow().slider("v", "Range", 16, 256, 64, " m"));
    public static final Feature PLAYERS = reg(new Feature("players", "Players", "ESP").on(true));
    public static final Feature MOBS = reg(new Feature("mobs", "Mobs", "ESP").on(false));
    public static final Feature FRAME = reg(new Feature("frame", "Sculk Frame", "ESP").on(true).color(ACCENT)
            .toggle("corners", "Corner style", true).toggle("fill", "Soft fill", true));
    public static final Feature SKELETON = reg(new Feature("skeleton", "Ribcage", "ESP").on(true).color(0xE6FFFB)
            .slider("range", "Max distance", 8, 128, 48, " m"));
    public static final Feature HPBAR = reg(new Feature("hpbar", "Soul Bar", "ESP").on(true)
            .toggle("numbers", "HP numbers", true));
    public static final Feature NAMES = reg(new Feature("names", "Name Tags", "ESP").on(true).color(0xFFFFFF)
            .toggle("dist", "Show distance", true));
    public static final Feature CHAMS = reg(new Feature("chams", "Echo Chams", "ESP").on(false).color(ACCENT)
            .slider("range", "Max distance", 8, 128, 48, " m"));

    // ---- WORLD ----
    public static final Feature FOG = reg(new Feature("fog", "Deep Fog", "WORLD").on(false).color(0x0E3B43)
            .slider("dist", "Distance", 8, 256, 64, " m").slider("start", "Fog start", 0, 90, 15, " %"));
    public static final Feature TIME = reg(new Feature("time", "Time Warp", "WORLD").on(false)
            .clock("t", "Time", 18000));
    public static final Feature FOV = reg(new Feature("fov", "FOV", "WORLD").on(false)
            .slider("v", "Field of view", 30, 140, 100, "°"));
    public static final Feature ZOOM = reg(new Feature("zoom", "Zoom", "WORLD").on(false).holdBind()
            .slider("v", "Zoom FOV", 5, 60, 25, "°"));

    // ---- HUD ----
    public static final Feature WATERMARK = reg(new Feature("watermark", "Watermark", "HUD").on(true).color(ACCENT)
            .toggle("nick", "Nickname", true).toggle("ping", "Ping", true)
            .toggle("fps", "FPS", true).toggle("time", "Current time", false));
    public static final Feature POTIONS = reg(new Feature("potions", "Potion List", "HUD").on(true).color(ACCENT));
    public static final Feature TOASTS = reg(new Feature("toasts", "Bind notifications", "HUD").on(true));

    // ---- MISC ----
    public static final Feature MENU = reg(new Feature("menu", "Menu key", "MISC").bindOnly()
            .defaultKeys(GLFW.GLFW_KEY_RIGHT_SHIFT));

    public static List<Feature> tab(String tab) {
        List<Feature> out = new ArrayList<>();
        for (Feature f : ALL) if (f.tab.equals(tab)) out.add(f);
        return out;
    }

    public static void resetAll() {
        for (Feature f : ALL) {
            f.reset();
            if (f == MENU) {
                f.bind.clear();
                f.bind.keys[0] = GLFW.GLFW_KEY_RIGHT_SHIFT;
            } else if (f != ZOOM) {
                f.bind.clear();
            } else {
                f.bind.clear();
            }
        }
        save();
    }

    private static Path file() {
        return FabricLoader.getInstance().getConfigDir().resolve("wardenvisual.properties");
    }

    public static void save() {
        try {
            Properties p = new Properties();
            for (Feature f : ALL) {
                String k = f.id + ".";
                if (!f.transientOn) p.setProperty(k + "on", f.on ? "1" : "0");
                p.setProperty(k + "bind", f.bind.save());
                if (f.col != null) {
                    p.setProperty(k + "h", String.valueOf(f.col.h));
                    p.setProperty(k + "s", String.valueOf(f.col.s));
                    p.setProperty(k + "b", String.valueOf(f.col.b));
                    p.setProperty(k + "a", String.valueOf(f.col.a));
                    p.setProperty(k + "rb", f.col.rainbow ? "1" : "0");
                }
                for (Feature.Opt o : f.opts) p.setProperty(k + "o." + o.id, String.valueOf(o.val));
            }
            try (OutputStream os = Files.newOutputStream(file())) {
                p.store(os, "Warden Visual");
            }
        } catch (Exception ignored) {
        }
    }

    public static void load() {
        try {
            Path path = file();
            if (!Files.exists(path)) return;
            Properties p = new Properties();
            try (InputStream is = Files.newInputStream(path)) {
                p.load(is);
            }
            for (Feature f : ALL) {
                String k = f.id + ".";
                if (!f.transientOn && p.containsKey(k + "on")) f.on = p.getProperty(k + "on").equals("1");
                if (p.containsKey(k + "bind")) f.bind.load(p.getProperty(k + "bind"));
                if (f.col != null) {
                    f.col.h = fl(p, k + "h", f.col.h);
                    f.col.s = fl(p, k + "s", f.col.s);
                    f.col.b = fl(p, k + "b", f.col.b);
                    f.col.a = fl(p, k + "a", f.col.a);
                    f.col.rainbow = "1".equals(p.getProperty(k + "rb"));
                }
                for (Feature.Opt o : f.opts) {
                    String v = p.getProperty(k + "o." + o.id);
                    if (v != null) {
                        try {
                            o.val = Math.max(o.min, Math.min(o.max, Integer.parseInt(v.trim())));
                        } catch (Exception ignored) {
                        }
                    }
                }
            }
        } catch (Exception ignored) {
        }
    }

    private static float fl(Properties p, String key, float def) {
        try {
            String v = p.getProperty(key);
            return v == null ? def : Float.parseFloat(v);
        } catch (Exception e) {
            return def;
        }
    }

    private Features() {
    }
}
