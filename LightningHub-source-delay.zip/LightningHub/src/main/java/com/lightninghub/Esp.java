package com.lightninghub;

import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.decoration.ArmorStandEntity;
import net.minecraft.entity.mob.Monster;
import net.minecraft.entity.player.PlayerEntity;

/** ESP: подсвечивает сущности цветным контуром, виден сквозь стены. */
public final class Esp {
	/** 0 - игрок, 1 - враждебный моб, 2 - животное / прочее. */
	private static int category(Entity e) {
		if (e instanceof PlayerEntity) return 0;
		if (e instanceof Monster) return 1;
		return 2;
	}

	public static boolean shouldGlow(Entity e) {
		Config.Settings s = Config.S;
		if (!s.esp) return false;

		MinecraftClient mc = MinecraftClient.getInstance();
		if (mc.world == null || mc.player == null) return false;
		if (e == mc.player) return false;
		if (!(e instanceof LivingEntity) || e instanceof ArmorStandEntity) return false;
		if (!e.isAlive()) return false;
		if (e.isInvisible() && !s.espInvisible) return false;

		boolean allowed = switch (category(e)) {
			case 0 -> s.espPlayers;
			case 1 -> s.espHostile;
			default -> s.espPassive;
		};
		if (!allowed) return false;

		if (s.espMaxDist < 128 && mc.player.distanceTo(e) > s.espMaxDist) return false;

		// Только клиентские объекты (чтобы не трогать серверные сущности в одиночной игре).
		return mc.world.getEntityById(e.getId()) == e;
	}

	/** Цвет контура (RGB) или -1, если сущность подсвечивать не нужно. */
	public static int colorFor(Entity e) {
		if (!shouldGlow(e)) return -1;
		Config.Settings s = Config.S;
		int idx = switch (category(e)) {
			case 0 -> s.espPlayerColor;
			case 1 -> s.espHostileColor;
			default -> s.espPassiveColor;
		};
		return Config.COLORS[Math.max(0, Math.min(Config.COLORS.length - 1, idx))];
	}

	private Esp() {
	}
}
