package com.lightninghub;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.decoration.ArmorStandEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

import net.minecraft.world.RaycastContext;

import java.util.Optional;

/** Общие проверки целей и математика углов. */
public final class Targeting {
	/** Подходит ли сущность как цель (жива, не стойка для брони, не наблюдатель, режим целей). */
	public static boolean valid(ClientPlayerEntity player, Entity e, Config.Targets mode) {
		if (!(e instanceof LivingEntity) || e == player || e instanceof ArmorStandEntity) return false;
		if (!e.isAlive() || e.isSpectator()) return false;
		return mode == Config.Targets.ALL || e instanceof PlayerEntity;
	}

	/** То же, но ещё пропускает союзников по команде (если включено в настройках). */
	public static boolean attackable(ClientPlayerEntity player, Entity e, Config.Targets mode) {
		if (!valid(player, e, mode)) return false;
		return !(Config.S.ignoreTeam && e.isTeammate(player));
	}

	/** Точка, в которую целимся: голова или корпус. */
	public static Vec3d aimPoint(Entity e, boolean head) {
		double y = head ? e.getEyeY() : e.getY() + e.getHeight() * 0.6;
		return new Vec3d(e.getX(), y, e.getZ());
	}

	/** Нужные углы {yaw, pitch}, чтобы смотреть из точки from в точку to. */
	public static float[] anglesTo(Vec3d from, Vec3d to) {
		double dx = to.x - from.x;
		double dy = to.y - from.y;
		double dz = to.z - from.z;
		double h = Math.sqrt(dx * dx + dz * dz);
		float yaw = (float) (Math.toDegrees(Math.atan2(dz, dx)) - 90.0);
		float pitch = (float) (-Math.toDegrees(Math.atan2(dy, h)));
		return new float[]{yaw, pitch};
	}

	/** Расстояние от глаз игрока до ближайшей точки хитбокса сущности (так считает и сервер). */
	public static double reach(ClientPlayerEntity p, Entity e) {
		Vec3d eye = p.getEyePos();
		Box b = e.getBoundingBox();
		double x = MathHelper.clamp(eye.x, b.minX, b.maxX);
		double y = MathHelper.clamp(eye.y, b.minY, b.maxY);
		double z = MathHelper.clamp(eye.z, b.minZ, b.maxZ);
		return eye.distanceTo(new Vec3d(x, y, z));
	}

	/** Свободен ли путь от глаз игрока до точки (блоки не мешают). Чуть не доходим до точки, чтобы стена за целью не мешала. */
	public static boolean clear(ClientPlayerEntity p, Vec3d to) {
		MinecraftClient mc = MinecraftClient.getInstance();
		if (mc.world == null) return true;
		Vec3d eye = p.getEyePos();
		Vec3d d = to.subtract(eye);
		double len = d.length();
		if (len < 0.2) return true;
		Vec3d end = eye.add(d.multiply(Math.max(0.0, 1.0 - 0.06 / len)));
		BlockHitResult r = mc.world.raycast(new RaycastContext(eye, end,
				RaycastContext.ShapeType.COLLIDER, RaycastContext.FluidHandling.NONE, p));
		return r.getType() == HitResult.Type.MISS;
	}

	/** Видна ли хоть какая-то часть цели: ближайшая точка хитбокса, глаза, центр или ноги. Не требует видеть именно глаза. */
	public static boolean canSeeEntity(ClientPlayerEntity p, Entity e) {
		Vec3d eye = p.getEyePos();
		Box b = e.getBoundingBox();
		Vec3d near = new Vec3d(
				MathHelper.clamp(eye.x, b.minX, b.maxX),
				MathHelper.clamp(eye.y, b.minY, b.maxY),
				MathHelper.clamp(eye.z, b.minZ, b.maxZ));
		if (clear(p, near)) return true;
		if (clear(p, new Vec3d(e.getX(), e.getEyeY(), e.getZ()))) return true;
		if (clear(p, b.getCenter())) return true;
		return clear(p, new Vec3d(e.getX(), b.minY + 0.15, e.getZ()));
	}

	/**
	 * Лучшая точка наводки: ближайшая к текущему лучу прицела точка внутри "безопасной" зоны хитбокса
	 * (голова или корпус, с отступом от краёв). Если прицел уже в этой зоне - точка лежит прямо на луче,
	 * и камера не двигается. shift - упреждение (смещение хитбокса).
	 */
	public static Vec3d aimSpot(Entity e, Vec3d eye, Vec3d dir, boolean head, Vec3d shift) {
		Box b = e.getBoundingBox().offset(shift);
		double h = b.maxY - b.minY;
		double inX = Math.min(0.12, (b.maxX - b.minX) * 0.3);
		double inZ = Math.min(0.12, (b.maxZ - b.minZ) * 0.3);
		double loY;
		double hiY;
		if (head && h > 1.0) {
			loY = b.maxY - h * 0.30;
			hiY = b.maxY - h * 0.06;
		} else {
			loY = b.minY + h * 0.25;
			hiY = b.minY + h * 0.80;
		}
		Vec3d c = b.getCenter();
		double t = Math.max(0.0, dir.dotProduct(c.subtract(eye)));
		Vec3d q = eye.add(dir.multiply(t));
		return new Vec3d(
				MathHelper.clamp(q.x, b.minX + inX, b.maxX - inX),
				MathHelper.clamp(q.y, loY, hiY),
				MathHelper.clamp(q.z, b.minZ + inZ, b.maxZ - inZ));
	}

	/**
	 * Сущность, на которую прямо сейчас направлен прицел (луч из глаз по направлению взгляда),
	 * в пределах range блоков. Считается по текущим углам, а не по прошлому кадру.
	 */
	public static Entity aimedAt(MinecraftClient mc, ClientPlayerEntity p, Config.Targets mode, double range,
			boolean needSight, boolean skipTeam) {
		Vec3d eye = p.getEyePos();
		Vec3d end = eye.add(p.getRotationVec(1.0f).multiply(range));

		Entity best = null;
		double bestDist = Double.MAX_VALUE;
		double far = (range + 6.0) * (range + 6.0);
		for (Entity e : mc.world.getEntities()) {
			if (p.squaredDistanceTo(e) > far) continue;
			boolean ok = skipTeam ? attackable(p, e, mode) : valid(p, e, mode);
			if (!ok) continue;

			Box box = e.getBoundingBox().expand(e.getTargetingMargin() + 0.05);
			double dist;
			Vec3d hitPoint = null;
			if (box.contains(eye)) {
				dist = 0.0;
			} else {
				Optional<Vec3d> hit = box.raycast(eye, end);
				if (hit.isEmpty()) continue;
				hitPoint = hit.get();
				dist = eye.distanceTo(hitPoint);
			}
			if (dist >= bestDist) continue;
			// Проверяем видимость именно точки, в которую смотрит прицел (а не глаз цели).
			if (needSight && hitPoint != null && !clear(p, hitPoint)) continue;

			best = e;
			bestDist = dist;
		}
		return best;
	}

	private Targeting() {
	}
}
