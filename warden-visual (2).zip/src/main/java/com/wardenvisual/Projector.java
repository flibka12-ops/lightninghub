package com.wardenvisual;

import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.util.math.Vec3d;

/** Projects world coordinates onto the (scaled) GUI screen using the player's view. */
public final class Projector {
    private double ex, ey, ez;
    private double fx, fy, fz, rx, ry, rz, ux, uy, uz;
    private double tanY, aspect;
    private int w, h;

    public void setup(ClientPlayerEntity p, float tp, int w, int h, double fovDeg) {
        Vec3d pos = p.getLerpedPos(tp);
        ex = pos.x;
        ey = pos.y + (p.getEyeY() - p.getY());
        ez = pos.z;
        double yaw = Math.toRadians(p.getYaw(tp));
        double pitch = Math.toRadians(p.getPitch(tp));
        double sy = Math.sin(yaw), cy = Math.cos(yaw), sp = Math.sin(pitch), cp = Math.cos(pitch);
        fx = -sy * cp;
        fy = -sp;
        fz = cy * cp;
        rx = -cy;
        ry = 0;
        rz = -sy;
        ux = -sy * sp;
        uy = cp;
        uz = cy * sp;
        this.w = w;
        this.h = h;
        tanY = Math.tan(Math.toRadians(fovDeg) / 2.0);
        aspect = (double) w / (double) h;
    }

    /** Returns {x, y} in GUI coordinates or null if the point is behind the camera. */
    public double[] project(double wx, double wy, double wz) {
        double dx = wx - ex, dy = wy - ey, dz = wz - ez;
        double z = dx * fx + dy * fy + dz * fz;
        if (z < 0.05) return null;
        double x = dx * rx + dy * ry + dz * rz;
        double y = dx * ux + dy * uy + dz * uz;
        double sx = w / 2.0 + (x / z) / (tanY * aspect) * (w / 2.0);
        double sy = h / 2.0 - (y / z) / tanY * (h / 2.0);
        return new double[]{sx, sy};
    }
}
