package com.wardenvisual;

/** Hook status counters, shown in the MISC tab so broken hooks are easy to spot. */
public final class Diag {
    public static volatile long glow, fogBuf, fogPub, fov, view, time, matrixFrames, fallbackFrames;
    public static volatile String viewMode = "-";

    private Diag() {
    }
}
