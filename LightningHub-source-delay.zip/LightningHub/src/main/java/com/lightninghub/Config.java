package com.lightninghub;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.Map;

/** Все настройки мода. Хранятся в .minecraft/config/lightninghub.json */
public final class Config {
	public enum Targets {
		ALL("Все (игроки, мобы, животные)"),
		PLAYERS("Только игроки");

		public final String label;

		Targets(String label) {
			this.label = label;
		}

		public Targets next() {
			return values()[(ordinal() + 1) % values().length];
		}
	}

	/** Кого выбирать, когда рядом несколько целей. */
	public enum Priority {
		CLOSEST("Ближайший"),
		LOWEST_HP("С наименьшим HP"),
		CROSSHAIR("Ближе к прицелу");

		public final String label;

		Priority(String label) {
			this.label = label;
		}

		public Priority next() {
			return values()[(ordinal() + 1) % values().length];
		}
	}

	public static final String[] COLOR_NAMES = {
			"Жёлтый", "Красный", "Зелёный", "Синий", "Голубой", "Фиолетовый", "Белый", "Оранжевый"
	};
	public static final int[] COLORS = {
			0xFFD93B, 0xFF3B3B, 0x3BFF5E, 0x3B6BFF, 0x3BE8FF, 0xC83BFF, 0xFFFFFF, 0xFF9A3B
	};

	public static final class Settings {
		// ---------- Бой: авто-атака ----------
		public boolean autoAttack = false;
		public Targets aaTargets = Targets.ALL;
		/** Дальность до хитбокса цели. Ванильный сервер принимает удары примерно до 4 блоков. */
		public double aaRange = 3.0;
		public int aaChance = 100;
		/** Легитный режим: бить только того, на кого направлен прицел. */
		public boolean aaNeedAim = true;
		public boolean aaNeedSight = true;
		/** УСТАРЕЛО (тики): оставлено только для переноса старых настроек в aaDelayMax. */
		public int aaReaction = 2;
		/** Trigger Delay: пакет удара уходит только после случайной задержки от Min до Max (миллисекунды). */
		public boolean aaTriggerDelay = true;
		public int aaDelayMin = 0;
		public int aaDelayMax = 100;
		/** Если в прыжке - ждать падения, чтобы удар был критическим (+50% урона). */
		public boolean aaCrit = true;
		public Priority aaPriority = Priority.CLOSEST;

		// ---------- Бой: общее ----------
		/** По умолчанию выключено: на многих серверах все игроки в одной команде и бить было бы некого. */
		public boolean ignoreTeam = false;
		/** Версия формата конфига (для миграции старых настроек). */
		public int cfgVersion = 0;
		/** Расширение хитбокса врагов для прицела (в блоках). */
		public double hitbox = 0.0;

		// ---------- Бой: наводка ----------
		public boolean aim = false;
		/** true - работает только пока зажата клавиша наводки; false - всегда. */
		public boolean aimHold = false;
		public Targets aimTargets = Targets.ALL;
		public int aimFov = 60;
		public int aimSpeed = 25;
		public int aimMaxTurn = 8;
		public double aimRange = 4.5;
		public double aimRandom = 1.0;
		public boolean aimHead = true;

		// ---------- Визуал: ESP ----------
		public boolean esp = false;
		public boolean espPlayers = true;
		public boolean espHostile = true;
		public boolean espPassive = false;
		public int espPlayerColor = 1;
		public int espHostileColor = 7;
		public int espPassiveColor = 2;
		/** 128 = без ограничения. */
		public int espMaxDist = 128;
		public boolean espInvisible = true;

		// ---------- Интерфейс ----------
		public boolean targetHud = true;
		public boolean nearbyList = false;
		public boolean nearbyPlayersOnly = true;
		public int nearbyRange = 32;
		public int nearbyCount = 5;
		public boolean watermark = true;
		public boolean moduleList = true;
		public boolean coords = false;

		// ---------- Разное ----------
		public boolean fullbright = false;
		public boolean autoSprint = false;
		public boolean autoTotem = false;

		// ---------- Бинды: id функции -> код клавиши GLFW ----------
		public Map<String, Integer> binds = new HashMap<>();
	}

	public static Settings S = new Settings();

	private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

	private static Path file() {
		return FabricLoader.getInstance().getConfigDir().resolve("lightninghub.json");
	}

	public static void load() {
		Path f = file();
		if (!Files.exists(f)) return;
		try {
			Settings d = GSON.fromJson(Files.readString(f), Settings.class);
			if (d != null) {
				S = d;
				sanitize();
			}
		} catch (Exception ignored) {
			// битый конфиг - остаёмся на значениях по умолчанию
		}
	}

	public static void save() {
		S.cfgVersion = 3;
		try {
			Files.writeString(file(), GSON.toJson(S));
		} catch (IOException ignored) {
		}
	}

	private static int clamp(int v, int lo, int hi) {
		return Math.max(lo, Math.min(hi, v));
	}

	private static double clamp(double v, double lo, double hi) {
		return Math.max(lo, Math.min(hi, v));
	}

	private static void sanitize() {
		Settings s = S;
		if (s.binds == null) s.binds = new HashMap<>();
		if (s.aaTargets == null) s.aaTargets = Targets.ALL;
		if (s.aimTargets == null) s.aimTargets = Targets.ALL;
		if (s.aaPriority == null) s.aaPriority = Priority.CLOSEST;

		// Миграция: в старых конфигах "Не бить союзников" была включена и отсекала всех игроков
		// на серверах, где игроки состоят в одной команде.
		if (s.cfgVersion < 2) {
			s.ignoreTeam = false;
			s.cfgVersion = 2;
		}

		// Миграция: старая реакция в тиках (0..N) -> задержка в миллисекундах (0..N*50).
		if (s.cfgVersion < 3) {
			s.aaDelayMin = 0;
			s.aaDelayMax = clamp(s.aaReaction, 0, 10) * 50;
			s.aaTriggerDelay = true;
			s.cfgVersion = 3;
		}
		s.aaDelayMin = clamp(s.aaDelayMin, 0, 1000);
		s.aaDelayMax = clamp(s.aaDelayMax, 0, 1000);
		if (s.aaDelayMax < s.aaDelayMin) s.aaDelayMax = s.aaDelayMin;

		s.aaRange = clamp(s.aaRange, 1.0, 4.5);
		s.aaChance = clamp(s.aaChance, 0, 100);
		s.hitbox = clamp(s.hitbox, 0.0, 0.5);

		s.aimFov = clamp(s.aimFov, 5, 180);
		s.aimSpeed = clamp(s.aimSpeed, 5, 100);
		s.aimMaxTurn = clamp(s.aimMaxTurn, 1, 30);
		s.aimRange = clamp(s.aimRange, 1.0, 8.0);
		s.aimRandom = clamp(s.aimRandom, 0.0, 5.0);

		s.espPlayerColor = clamp(s.espPlayerColor, 0, COLORS.length - 1);
		s.espHostileColor = clamp(s.espHostileColor, 0, COLORS.length - 1);
		s.espPassiveColor = clamp(s.espPassiveColor, 0, COLORS.length - 1);
		s.espMaxDist = clamp(s.espMaxDist, 8, 128);

		s.nearbyRange = clamp(s.nearbyRange, 8, 64);
		s.nearbyCount = clamp(s.nearbyCount, 1, 10);
	}

	private Config() {
	}
}
