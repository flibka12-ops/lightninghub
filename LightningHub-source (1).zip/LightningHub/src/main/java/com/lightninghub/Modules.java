package com.lightninghub;

import java.util.List;
import java.util.function.BooleanSupplier;
import java.util.function.Consumer;

/** Список функций, которые можно включать по бинду и показывать в списке модулей. */
public final class Modules {
	public record Mod(String id, String name, BooleanSupplier get, Consumer<Boolean> set) {
		public boolean enabled() {
			return get.getAsBoolean();
		}

		public void toggle() {
			set.accept(!get.getAsBoolean());
		}
	}

	public static final List<Mod> ALL = List.of(
			new Mod("autoAttack", "Авто-атака", () -> Config.S.autoAttack, v -> Config.S.autoAttack = v),
			new Mod("aim", "Наводка", () -> Config.S.aim, v -> Config.S.aim = v),
			new Mod("esp", "ESP", () -> Config.S.esp, v -> Config.S.esp = v),
			new Mod("targetHud", "Таргет-HUD", () -> Config.S.targetHud, v -> Config.S.targetHud = v),
			new Mod("nearbyList", "Список рядом", () -> Config.S.nearbyList, v -> Config.S.nearbyList = v),
			new Mod("fullbright", "Фуллбрайт", () -> Config.S.fullbright, v -> Config.S.fullbright = v),
			new Mod("autoSprint", "Авто-спринт", () -> Config.S.autoSprint, v -> Config.S.autoSprint = v)
	);

	private Modules() {
	}
}
