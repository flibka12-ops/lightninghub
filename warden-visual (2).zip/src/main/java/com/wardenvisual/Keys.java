package com.wardenvisual;

import net.minecraft.client.MinecraftClient;
import org.lwjgl.glfw.GLFW;

/** Polls binds through GLFW (up to 3 keys per bind) and toggles features. */
public final class Keys {
    private static long lastPoll = -1;

    public static String name(int k) {
        return switch (k) {
            case GLFW.GLFW_KEY_LEFT_SHIFT -> "L-Shift";
            case GLFW.GLFW_KEY_RIGHT_SHIFT -> "R-Shift";
            case GLFW.GLFW_KEY_LEFT_CONTROL -> "L-Ctrl";
            case GLFW.GLFW_KEY_RIGHT_CONTROL -> "R-Ctrl";
            case GLFW.GLFW_KEY_LEFT_ALT -> "L-Alt";
            case GLFW.GLFW_KEY_RIGHT_ALT -> "R-Alt";
            case GLFW.GLFW_KEY_SPACE -> "Space";
            case GLFW.GLFW_KEY_TAB -> "Tab";
            case GLFW.GLFW_KEY_ENTER -> "Enter";
            case GLFW.GLFW_KEY_BACKSPACE -> "Backspace";
            case GLFW.GLFW_KEY_CAPS_LOCK -> "Caps";
            case GLFW.GLFW_KEY_UP -> "Up";
            case GLFW.GLFW_KEY_DOWN -> "Down";
            case GLFW.GLFW_KEY_LEFT -> "Left";
            case GLFW.GLFW_KEY_RIGHT -> "Right";
            case GLFW.GLFW_KEY_INSERT -> "Insert";
            case GLFW.GLFW_KEY_DELETE -> "Delete";
            case GLFW.GLFW_KEY_HOME -> "Home";
            case GLFW.GLFW_KEY_END -> "End";
            case GLFW.GLFW_KEY_PAGE_UP -> "PgUp";
            case GLFW.GLFW_KEY_PAGE_DOWN -> "PgDn";
            default -> {
                if (k >= GLFW.GLFW_KEY_F1 && k <= GLFW.GLFW_KEY_F25) yield "F" + (k - GLFW.GLFW_KEY_F1 + 1);
                String n = null;
                try {
                    n = GLFW.glfwGetKeyName(k, 0);
                } catch (Throwable ignored) {
                }
                yield n != null ? n.toUpperCase() : "Key" + k;
            }
        };
    }

    /** Called every client tick and every HUD frame; safe to call repeatedly. */
    public static void poll() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.getWindow() == null) return;
        if (WardenMenuScreen.capturing) return;
        long h = mc.getWindow().getHandle();
        boolean inGame = mc.player != null && mc.currentScreen == null;
        boolean inMenu = mc.currentScreen instanceof WardenMenuScreen;

        // pass 1: which binds are fully held
        int n = Features.ALL.size();
        boolean[] held = new boolean[n];
        for (int i = 0; i < n; i++) held[i] = Features.ALL.get(i).bind.down(h);

        // pass 2: a bind is suppressed if a held bind with more keys contains all of its keys
        for (int i = 0; i < n; i++) {
            Feature f = Features.ALL.get(i);
            Bind b = f.bind;
            boolean active = held[i];
            if (active) {
                for (int j = 0; j < n && active; j++) {
                    if (j == i || !held[j]) continue;
                    Bind o = Features.ALL.get(j).bind;
                    if (o.count() > b.count() && containsAll(o, b)) active = false;
                }
            }
            if (f == Features.MENU) {
                if (active && !b.was && (inGame || inMenu)) {
                    if (inMenu) mc.setScreen(null);
                    else mc.setScreen(new WardenMenuScreen());
                }
                b.was = active;
                continue;
            }
            if (!inGame) {
                b.was = active;
                continue;
            }
            if (b.hold && b.isSet()) {
                if (f.on != active) f.on = active;
            } else if (b.hold) {
                // hold mode without keys: nothing to do
            } else if (active && !b.was) {
                f.on = !f.on;
                Hud.toast(f.name + (f.on ? ": ON" : ": OFF"));
                Features.save();
            }
            b.was = active;
        }
    }

    private static boolean containsAll(Bind big, Bind small) {
        for (int k : small.keys) {
            if (k != 0 && !big.contains(k)) return false;
        }
        return true;
    }

    private Keys() {
    }
}
