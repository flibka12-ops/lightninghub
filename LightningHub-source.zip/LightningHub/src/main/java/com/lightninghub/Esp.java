package com.lightninghub;

import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.decoration.ArmorStandEntity;
import net.minecraft.entity.player.PlayerEntity;

/** ESP: подсвечивает сущности контуром (как эффект свечения), виден сквозь стены. */
public final class Esp {
	public static boolean shouldGlow(Entity e) {
		if (!Config.esp) return false;

		MinecraftClient mc = MinecraftClient.getInstance();
		if (mc.world == null || mc.player == null) return false;
		if (e == mc.player) return false;
		if (!(e instanceof LivingEntity) || e instanceof ArmorStandEntity) return false;
		if (Config.espTargets == Config.Targets.PLAYERS && !(e instanceof PlayerEntity)) return false;

		// Только клиентские объекты (чтобы не трогать серверные сущности в одиночной игре).
		return mc.world.getEntityById(e.getId()) == e;
	}

	private Esp() {
	}
}
