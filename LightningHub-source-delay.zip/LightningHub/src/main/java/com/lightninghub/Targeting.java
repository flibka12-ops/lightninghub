package com.lightninghub;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.decoration.ArmorStandEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

import java.util.Optional;

/** Общие проверки целей и математика углов. */
public final class Targeting {
	/** Подходит ли сущность как цель (жива, не стойка для брони, не наблюдатель, режим целей). */
	public static boolean valid(ClientPlayerEntity player, Entity e, Config.Targets mode) {
		if (!(e instanceof LivingEntity) || e == player || e instanceof ArmorStandEntity) return false;
		if (!e.isAlive() || e.isSpectator()) return false;
		return mode == Config.Targets.ALL || e instanceof PlayerEntity;
	}

	/** То же, но ещё пропускает союзников по команде (если включено в настройках). */
	public static boolean attackable(ClientPlayerEntity player, Entity e, Config.Targets mode) {
		if (!valid(player, e, mode)) return false;
		return !(Config.S.ignoreTeam && e.isTeammate(player));
	}

	/** Точка, в которую целимся: голова или корпус. */
	public static Vec3d aimPoint(Entity e, boolean head) {
		double y = head ? e.getEyeY() : e.getY() + e.getHeight() * 0.6;
		return new Vec3d(e.getX(), y, e.getZ());
	}

	/** Нужные углы {yaw, pitch}, чтобы смотреть из точки from в точку to. */
	public static float[] anglesTo(Vec3d from, Vec3d to) {
		double dx = to.x - from.x;
		double dy = to.y - from.y;
		double dz = to.z - from.z;
		double h = Math.sqrt(dx * dx + dz * dz);
		float yaw = (float) (Math.toDegrees(Math.atan2(dz, dx)) - 90.0);
		float pitch = (float) (-Math.toDegrees(Math.atan2(dy, h)));
		return new float[]{yaw, pitch};
	}

	/** Расстояние от глаз игрока до ближайшей точки хитбокса сущности (так считает и сервер). */
	public static double reach(ClientPlayerEntity p, Entity e) {
		Vec3d eye = p.getEyePos();
		Box b = e.getBoundingBox();
		double x = MathHelper.clamp(eye.x, b.minX, b.maxX);
		double y = MathHelper.clamp(eye.y, b.minY, b.maxY);
		double z = MathHelper.clamp(eye.z, b.minZ, b.maxZ);
		return eye.distanceTo(new Vec3d(x, y, z));
	}

	/**
	 * Сущность, на которую прямо сейчас направлен прицел (луч из глаз по направлению взгляда),
	 * в пределах range блоков. Считается по текущим углам, а не по прошлому кадру.
	 */
	public static Entity aimedAt(MinecraftClient mc, ClientPlayerEntity p, Config.Targets mode, double range,
			boolean needSight, boolean skipTeam) {
		Vec3d eye = p.getEyePos();
		Vec3d end = eye.add(p.getRotationVec(1.0f).multiply(range));

		Entity best = null;
		double bestDist = Double.MAX_VALUE;
		for (Entity e : mc.world.getEntities()) {
			boolean ok = skipTeam ? attackable(p, e, mode) : valid(p, e, mode);
			if (!ok) continue;

			Box box = e.getBoundingBox().expand(e.getTargetingMargin() + 0.05);
			double dist;
			if (box.contains(eye)) {
				dist = 0.0;
			} else {
				Optional<Vec3d> hit = box.raycast(eye, end);
				if (hit.isEmpty()) continue;
				dist = eye.distanceTo(hit.get());
			}
			if (dist >= bestDist) continue;
			if (needSight && !p.canSee(e)) continue;

			best = e;
			bestDist = dist;
		}
		return best;
	}

	private Targeting() {
	}
}
