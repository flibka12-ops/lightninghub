package com.lightninghub;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.util.Hand;
import net.minecraft.util.math.Vec3d;

import java.util.Locale;
import java.util.Random;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

/**
 * Авто-атака.
 * - Бьёт только когда шкала урона заполнена полностью (+1 тик запаса на задержку сети).
 * - Критические удары: в прыжке ждёт начала падения.
 * - Легит-режим: бьёт только того, на кого направлен прицел, со случайной задержкой реакции.
 * - Считает, сколько ударов реально прошло, и замечает, если сервер скрывает HP врагов.
 * - Пишет на экран (строка "АА: ...") причину, почему сейчас не бьёт.
 */
public final class AutoAttack {
	private static final Random RNG = new Random();

	/** Последняя атакованная цель - нужна для Таргет-HUD. */
	public static LivingEntity lastTarget = null;
	public static long lastTargetTime = 0L;

	/** Статистика для Таргет-HUD. */
	public static int sent = 0;
	public static int landed = 0;
	/** Сколько раз подряд цель "краснела" от удара, а HP не менялось (сервер скрывает HP). */
	public static int hiddenHp = 0;

	/** Текст для строки "АА: ..." на экране: что делает авто-атака прямо сейчас. */
	public static String status = null;

	private static int ticks = 0;
	private static int pause = 0;
	/** Trigger Delay: момент (мс, System.nanoTime) когда можно слать пакет удара; 0 - задержка не запущена. */
	private static long fireAt = 0L;
	private static Entity delayTarget = null;
	private static long lostSince = 0L;
	/** Будильник: будит главный поток ровно через N мс, а не на следующем тике (тик = 50 мс). */
	private static final ScheduledExecutorService TIMER = Executors.newSingleThreadScheduledExecutor(r -> {
		Thread th = new Thread(r, "LightningHub-delay");
		th.setDaemon(true);
		return th;
	});

	private static long nowMs() {
		return System.nanoTime() / 1_000_000L;
	}
	private static int critWait = 0;

	private static LivingEntity pendingTarget = null;
	private static float pendingHp = 0f;
	private static int pendingAt = 0;
	private static boolean pendingHurt = false;

	public static void tick(MinecraftClient mc) {
		ticks++;
		trackHit();
		process(mc, true);
	}

	/**
	 * Основная логика. tickStep = true - вызов из тика; false - "пробуждение" от таймера Trigger Delay
	 * (тогда счётчики тиков не двигаем, только проверяем всё заново и шлём удар).
	 */
	private static void process(MinecraftClient mc, boolean tickStep) {
		// Пробуждение имеет смысл только если задержка реально запущена.
		if (!tickStep && fireAt == 0L) return;

		Config.Settings s = Config.S;
		if (!s.autoAttack) {
			fireAt = 0L;
			delayTarget = null;
			lostSince = 0L;
			critWait = 0;
			status = null;
			return;
		}

		ClientPlayerEntity p = mc.player;
		if (p == null || mc.world == null || mc.interactionManager == null) {
			status = "нет игрока или мира";
			return;
		}
		if (mc.currentScreen != null) {
			status = "открыто окно (меню / инвентарь)";
			return;
		}
		if (!p.isAlive() || p.isSpectator()) {
			status = "игрок мёртв или наблюдатель";
			return;
		}
		if (p.isUsingItem()) {
			status = "используешь предмет (щит / лук / еда)";
			return;
		}

		if (pause > 0) {
			if (tickStep) pause--;
			status = "пауза (шанс попадания)";
			return;
		}

		// Шкала урона заполнена полностью + 1 тик запаса: сервер считает свою шкалу отдельно,
		// и при задержке удар по "почти полной" шкале теряет урон и крит.
		if (p.getAttackCooldownProgress(-1.0f) < 1.0f) {
			int pct = (int) (p.getAttackCooldownProgress(0.0f) * 100);
			status = "ждёт шкалу урона: " + pct + "%";
			return;
		}

		Entity target = findTarget(mc, p, s);
		if (target == null) {
			// Прицел может на миг соскочить с цели (особенно при наводке) - не сбрасываем
			// Trigger Delay сразу, даём 200 мс, иначе удар при задержке почти никогда не пройдёт.
			if (fireAt != 0L) {
				long nm = nowMs();
				if (lostSince == 0L) lostSince = nm;
				if (nm - lostSince > 200L) {
					fireAt = 0L;
					delayTarget = null;
					lostSince = 0L;
				}
			}
			critWait = 0;
			status = noTargetReason(mc, p, s);
			return;
		}
		lostSince = 0L;

		// Криты: в воздухе ждём, пока начнётся падение (до 14 тиков, потом бьём как есть).
		if (s.aaCrit && critPossible(p) && p.fallDistance <= 0.0 && critWait < 14) {
			if (tickStep) critWait++;
			status = "жду падения для крита";
			return;
		}
		critWait = 0;

		// Trigger Delay: после того как всё готово (цель, шкала урона, крит) ждём случайное
		// время от aaDelayMin до aaDelayMax миллисекунд и только потом шлём пакет удара.
		int dMin = Math.max(0, s.aaDelayMin);
		int dMax = Math.max(dMin, s.aaDelayMax);
		if (s.aaTriggerDelay && dMax > 0) {
			if (delayTarget != target) {
				// новая цель - отсчёт заново
				delayTarget = target;
				fireAt = 0L;
			}
			if (fireAt == 0L) {
				int d = dMin + (dMax > dMin ? RNG.nextInt(dMax - dMin + 1) : 0);
				fireAt = nowMs() + d;
				if (d > 0) {
					TIMER.schedule(() -> mc.execute(() -> {
						try {
							process(mc, false);
						} catch (Throwable ex) {
							LightningHubClient.warn(ex);
						}
					}), d, TimeUnit.MILLISECONDS);
				}
			}
			long left = fireAt - nowMs();
			if (left > 0) {
				status = "Trigger Delay: " + left + " мс";
				return;
			}
		}
		fireAt = 0L;
		delayTarget = null;

		// Шанс попадания.
		if (RNG.nextInt(100) >= s.aaChance) {
			pause = 2 + RNG.nextInt(6);
			status = "промах по шансу";
			return;
		}

		mc.interactionManager.attackEntity(p, target);
		p.swingHand(Hand.MAIN_HAND);
		sent++;
		status = "удар! (всего " + sent + ")";

		if (target instanceof LivingEntity le) {
			lastTarget = le;
			lastTargetTime = System.currentTimeMillis();

			if (pendingTarget != null) finishHit();
			pendingTarget = le;
			pendingHp = le.getHealth() + le.getAbsorptionAmount();
			pendingAt = ticks + 10;
			pendingHurt = false;
		}
	}

	/** Можно ли сейчас нанести критический удар (условия ванильного крита, кроме падения). */
	private static boolean critPossible(ClientPlayerEntity p) {
		return !p.isOnGround() && !p.isTouchingWater() && !p.isClimbing() && !p.hasVehicle()
				&& !p.isSprinting() && !p.hasStatusEffect(StatusEffects.BLINDNESS);
	}

	// ----------------------------------------------------------------- выбор цели

	private static Entity findTarget(MinecraftClient mc, ClientPlayerEntity p, Config.Settings s) {
		// Легитный режим: только то, на что направлен прицел (в пределах дальности).
		if (s.aaNeedAim) {
			return Targeting.aimedAt(mc, p, s.aaTargets, s.aaRange, s.aaNeedSight, true);
		}

		// Обычный режим: лучшая цель в радиусе по выбранному приоритету.
		Vec3d eye = p.getEyePos();
		Vec3d look = p.getRotationVec(1.0f);

		Entity best = null;
		double bestScore = Double.MAX_VALUE;
		for (Entity e : mc.world.getEntities()) {
			if (!Targeting.attackable(p, e, s.aaTargets)) continue;
			double dist = Targeting.reach(p, e);
			if (dist > s.aaRange) continue;
			if (s.aaNeedSight && !p.canSee(e)) continue;

			double score;
			switch (s.aaPriority) {
				case LOWEST_HP -> {
					LivingEntity le = (LivingEntity) e;
					score = le.getHealth() + le.getAbsorptionAmount();
				}
				case CROSSHAIR -> {
					Vec3d to = Targeting.aimPoint(e, false).subtract(eye).normalize();
					score = Math.acos(Math.max(-1.0, Math.min(1.0, look.dotProduct(to))));
				}
				default -> score = dist;
			}
			if (score < bestScore) {
				bestScore = score;
				best = e;
			}
		}
		return best;
	}

	/** Объясняет простыми словами, почему цели нет (показывается в строке "АА: ..."). */
	private static String noTargetReason(MinecraftClient mc, ClientPlayerEntity p, Config.Settings s) {
		int near = 0;
		int team = 0;
		double nearest = Double.MAX_VALUE;
		for (Entity e : mc.world.getEntities()) {
			if (!Targeting.valid(p, e, s.aaTargets)) continue;
			double d = Targeting.reach(p, e);
			if (d > 6.0) continue;
			near++;
			if (s.ignoreTeam && e.isTeammate(p)) {
				team++;
			} else {
				nearest = Math.min(nearest, d);
			}
		}

		if (near == 0) {
			return s.aaTargets == Config.Targets.PLAYERS
					? "рядом нет игроков (до 6 бл.)"
					: "рядом никого нет (до 6 бл.)";
		}
		if (team == near) {
			return "все рядом - союзники по команде (выключи «Не бить союзников»)";
		}
		String dist = String.format(Locale.ROOT, "%.1f", nearest);
		if (s.aaNeedAim) {
			return "наведи прицел на цель (ближайшая: " + dist + " бл.)";
		}
		return "вне дальности или за стеной (ближайшая: " + dist + " бл.)";
	}

	// ----------------------------------------------------------------- статистика попаданий

	/** Следит за последним ударом: упало ли HP цели и краснела ли она (анимация урона). */
	private static void trackHit() {
		if (pendingTarget == null) return;
		if (pendingTarget.hurtTime > 0) pendingHurt = true;
		if (ticks >= pendingAt) finishHit();
	}

	private static void finishHit() {
		LivingEntity t = pendingTarget;
		pendingTarget = null;
		if (t == null) return;

		float now = t.getHealth() + t.getAbsorptionAmount();
		boolean hpDropped = !t.isAlive() || now < pendingHp - 0.01f;

		if (hpDropped || pendingHurt) landed++;
		if (pendingHurt && !hpDropped) {
			hiddenHp++; // цель получила урон, а HP не изменилось
		} else if (hpDropped) {
			hiddenHp = 0;
		}
	}

	private AutoAttack() {
	}
}
