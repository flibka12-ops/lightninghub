package com.lightninghub;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.fabricmc.fabric.api.client.screen.v1.Screens;
import net.minecraft.client.gui.screen.GameMenuScreen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.Identifier;
import org.lwjgl.glfw.GLFW;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class LightningHubClient implements ClientModInitializer {
	public static final String MOD_ID = "lightninghub";
	private static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

	private static KeyBinding openMenu;
	private static boolean warned = false;

	/** Ошибка внутри мода не должна ронять игру: пишем в лог один раз и идём дальше. */
	public static void warn(Throwable t) {
		if (warned) return;
		warned = true;
		LOGGER.error("LightningHub: внутренняя ошибка (повторные не выводятся)", t);
	}

	@Override
	public void onInitializeClient() {
		Config.load();

		// Right Shift открывает меню.
		openMenu = KeyBindingHelper.registerKeyBinding(new KeyBinding(
				"key.lightninghub.menu",
				InputUtil.Type.KEYSYM,
				GLFW.GLFW_KEY_RIGHT_SHIFT,
				KeyBinding.Category.create(Identifier.of(MOD_ID, "main"))
		));

		// Кнопка в меню паузы (Esc) - для телефонов, где нет клавиши Right Shift.
		ScreenEvents.AFTER_INIT.register((client, screen, scaledWidth, scaledHeight) -> {
			if (screen instanceof GameMenuScreen) {
				Screens.getButtons(screen).add(
						ButtonWidget.builder(
								Text.literal("LightningHub").formatted(Formatting.YELLOW),
								b -> client.setScreen(new MenuScreen())
						).dimensions(6, scaledHeight - 26, 110, 20).build()
				);
			}
		});

		// HUD: здоровье цели, список рядом, водяной знак и т.д.
		HudElementRegistry.attachElementBefore(
				VanillaHudElements.CHAT,
				Identifier.of(MOD_ID, "hud"),
				(ctx, tickCounter) -> {
					try {
						Hud.render(ctx, tickCounter);
					} catch (Throwable t) {
						warn(t);
					}
				}
		);

		// Наводка - в начале тика: новые углы попадут в пакет движения этого же тика,
		// и только потом (в конце тика) произойдёт удар.
		ClientTickEvents.START_CLIENT_TICK.register(client -> {
			try {
				Aim.tick(client);
			} catch (Throwable t) {
				warn(t);
			}
		});

		ClientTickEvents.END_CLIENT_TICK.register(client -> {
			try {
				while (openMenu.wasPressed()) {
					if (client.currentScreen == null) {
						client.setScreen(new MenuScreen());
					}
				}
				Binds.tick(client);
				AutoAttack.tick(client);
				AutoTotem.tick(client);
				Misc.tick(client);
			} catch (Throwable t) {
				warn(t);
			}
		});
	}
}
