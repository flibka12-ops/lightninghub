package com.wardenvisual;

import java.util.ArrayList;
import java.util.List;

/** One module: a toggle (or a pure slider row) with optional color, sub-options and a bind. */
public final class Feature {
    public static final class Opt {
        public final String id, name, unit;
        public final boolean toggle, clock;
        public final int min, max, def;
        public int val;

        Opt(String id, String name, boolean toggle, int min, int max, int def, String unit, boolean clock) {
            this.id = id;
            this.name = name;
            this.toggle = toggle;
            this.min = min;
            this.max = max;
            this.def = def;
            this.unit = unit;
            this.clock = clock;
            this.val = def;
        }

        public boolean on() {
            return val != 0;
        }
    }

    public final String id, name, tab;
    public boolean on;
    public boolean defOn;
    public boolean sliderRow;      // shown as a plain slider row (no switch)
    public boolean bindOnly;       // only a bind (menu key)
    public boolean transientOn;    // do not persist "on" (hold-to-use features)
    public final Bind bind = new Bind();
    public Col col;
    public int defCol;
    public final List<Opt> opts = new ArrayList<>();

    Feature(String id, String name, String tab) {
        this.id = id;
        this.name = name;
        this.tab = tab;
    }

    public Feature on(boolean v) {
        on = defOn = v;
        return this;
    }

    public Feature color(int rgb) {
        col = new Col(rgb);
        defCol = rgb;
        return this;
    }

    public Feature toggle(String id, String name, boolean def) {
        opts.add(new Opt(id, name, true, 0, 1, def ? 1 : 0, "", false));
        return this;
    }

    public Feature slider(String id, String name, int min, int max, int def, String unit) {
        opts.add(new Opt(id, name, false, min, max, def, unit, false));
        return this;
    }

    public Feature clock(String id, String name, int def) {
        opts.add(new Opt(id, name, false, 0, 24000, def, "", true));
        return this;
    }

    public Feature sliderRow() {
        sliderRow = true;
        return this;
    }

    public Feature bindOnly() {
        bindOnly = true;
        return this;
    }

    public Feature holdBind() {
        bind.hold = true;
        transientOn = true;
        return this;
    }

    public Feature defaultKeys(int... k) {
        for (int i = 0; i < 3 && i < k.length; i++) bind.keys[i] = k[i];
        return this;
    }

    public Opt opt(String id) {
        for (Opt o : opts) if (o.id.equals(id)) return o;
        return null;
    }

    public int v(String id) {
        Opt o = opt(id);
        return o == null ? 0 : o.val;
    }

    public boolean b(String id) {
        return v(id) != 0;
    }

    public void reset() {
        on = defOn;
        if (col != null) {
            col.set(defCol);
            col.a = 1f;
            col.rainbow = false;
        }
        for (Opt o : opts) o.val = o.def;
    }
}
