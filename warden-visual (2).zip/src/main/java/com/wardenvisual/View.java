package com.wardenvisual;

import org.joml.Matrix4f;

/** Holds the real view/projection matrices captured from WorldRenderer.render. */
public final class View {
    private static final float[] POS = new float[16];
    private static final float[] PROJ = new float[16];
    private static final float[] TMP = new float[16];
    private static boolean havePos, haveProj;
    public static final float[] MVP = new float[16];
    private static boolean mvpOk;

    /** Called for each Matrix4f argument of WorldRenderer.render; classifies it. */
    public static void feed(Matrix4f m) {
        if (m == null) return;
        float m23 = m.m23();
        float m33 = m.m33();
        if (Math.abs(m23 + 1f) < 1e-3f && Math.abs(m33) < 1e-3f) {
            // perspective projection
            {
                store(m, PROJ);
                haveProj = true;
            }
        } else if (Math.abs(m33 - 1f) < 1e-3f && Math.abs(m23) < 1e-3f) {
            store(m, POS);
            havePos = true;
        }
    }

    private static void store(Matrix4f m, float[] a) {
        a[0] = m.m00(); a[1] = m.m01(); a[2] = m.m02(); a[3] = m.m03();
        a[4] = m.m10(); a[5] = m.m11(); a[6] = m.m12(); a[7] = m.m13();
        a[8] = m.m20(); a[9] = m.m21(); a[10] = m.m22(); a[11] = m.m23();
        a[12] = m.m30(); a[13] = m.m31(); a[14] = m.m32(); a[15] = m.m33();
    }

    /** Called once per frame (HUD) after the world was rendered. */
    public static boolean prepare() {
        if (!havePos || !haveProj) {
            mvpOk = false;
            return false;
        }
        // MVP = PROJ * POS (column-major arrays)
        for (int c = 0; c < 4; c++) {
            for (int r = 0; r < 4; r++) {
                float s = 0;
                for (int k = 0; k < 4; k++) s += PROJ[k * 4 + r] * POS[c * 4 + k];
                TMP[c * 4 + r] = s;
            }
        }
        System.arraycopy(TMP, 0, MVP, 0, 16);
        mvpOk = true;
        return true;
    }

    /** Projects camera-relative coordinates into GUI space. out = {x, y}. Returns false if behind camera. */
    public static boolean project(double rx, double ry, double rz, int gw, int gh, double[] out) {
        if (!mvpOk) return false;
        float[] m = MVP;
        double cx = m[0] * rx + m[4] * ry + m[8] * rz + m[12];
        double cy = m[1] * rx + m[5] * ry + m[9] * rz + m[13];
        double cw = m[3] * rx + m[7] * ry + m[11] * rz + m[15];
        if (cw < 0.05) return false;
        out[0] = (cx / cw * 0.5 + 0.5) * gw;
        out[1] = (1.0 - (cy / cw * 0.5 + 0.5)) * gh;
        return true;
    }

    private View() {
    }
}
