package com.lightninghub;

import net.minecraft.client.MinecraftClient;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/** Система биндов: каждой функции можно назначить клавишу (переключение по нажатию). */
public final class Binds {
	/** Особый бинд: клавиша, которую нужно держать, чтобы работала наводка. */
	public static final String AIM_HOLD = "aimHold";

	/**
	 * Допустимые коды клавиш GLFW. Запрос любого другого кода вызывает ошибку GLFW
	 * (INVALID_ENUM) и на некоторых лаунчерах (в т.ч. мобильных) роняет игру.
	 */
	private static final int[] VALID = buildValid();
	private static final boolean[] OK = buildOk();

	private static final Map<String, Boolean> previous = new HashMap<>();

	private static int[] buildValid() {
		List<Integer> l = new ArrayList<>();
		l.add(32);
		l.add(39);
		for (int k = 44; k <= 57; k++) l.add(k);
		l.add(59);
		l.add(61);
		for (int k = 65; k <= 93; k++) l.add(k);
		l.add(96);
		for (int k = 257; k <= 269; k++) l.add(k); // Esc (256) не опрашиваем - он закрывает меню
		for (int k = 280; k <= 284; k++) l.add(k);
		for (int k = 290; k <= 314; k++) l.add(k);
		for (int k = 320; k <= 336; k++) l.add(k);
		for (int k = 340; k <= 348; k++) l.add(k);
		int[] r = new int[l.size()];
		for (int i = 0; i < r.length; i++) r[i] = l.get(i);
		return r;
	}

	private static boolean[] buildOk() {
		boolean[] r = new boolean[400];
		for (int k : VALID) r[k] = true;
		return r;
	}

	public static int get(String id) {
		Integer k = Config.S.binds.get(id);
		return k == null ? -1 : k;
	}

	public static void set(String id, int key) {
		if (key < 0 || key >= OK.length || !OK[key]) Config.S.binds.remove(id);
		else Config.S.binds.put(id, key);
	}

	/** Безопасная проверка: нажата ли клавиша (никогда не бросает исключений). */
	public static boolean keyDown(long handle, int key) {
		if (key < 0 || key >= OK.length || !OK[key]) return false;
		try {
			return GLFW.glfwGetKey(handle, key) == GLFW.GLFW_PRESS;
		} catch (Throwable t) {
			return false;
		}
	}

	/** Первая нажатая допустимая клавиша или -1. */
	public static int pollKey(long handle) {
		for (int k : VALID) {
			if (keyDown(handle, k)) return k;
		}
		return -1;
	}

	public static boolean isDown(String id) {
		int k = get(id);
		if (k < 0) return false;
		MinecraftClient mc = MinecraftClient.getInstance();
		if (mc.getWindow() == null) return false;
		return keyDown(mc.getWindow().getHandle(), k);
	}

	/** Вызывается каждый тик: переключает функции по нажатию их клавиш. */
	public static void tick(MinecraftClient mc) {
		for (Modules.Mod m : Modules.ALL) {
			boolean down = isDown(m.id());
			boolean was = previous.getOrDefault(m.id(), false);
			if (down && !was && mc.currentScreen == null) {
				m.toggle();
			}
			previous.put(m.id(), down);
		}
	}

	public static String keyName(int k) {
		if (k < 0) return "нет";
		if (k >= 65 && k <= 90) return String.valueOf((char) k);
		if (k >= 48 && k <= 57) return String.valueOf((char) k);
		if (k >= 290 && k <= 301) return "F" + (k - 289);
		return switch (k) {
			case 32 -> "Пробел";
			case 258 -> "Tab";
			case 257 -> "Enter";
			case 280 -> "Caps";
			case 340 -> "L-Shift";
			case 344 -> "R-Shift";
			case 341 -> "L-Ctrl";
			case 345 -> "R-Ctrl";
			case 342 -> "L-Alt";
			case 346 -> "R-Alt";
			case 262 -> "Вправо";
			case 263 -> "Влево";
			case 264 -> "Вниз";
			case 265 -> "Вверх";
			case 96 -> "`";
			case 45 -> "-";
			case 61 -> "=";
			case 91 -> "[";
			case 93 -> "]";
			case 59 -> ";";
			case 39 -> "'";
			case 44 -> ",";
			case 46 -> ".";
			case 47 -> "/";
			case 92 -> "\\";
			default -> "Клавиша " + k;
		};
	}

	private Binds() {
	}
}
