package com.lightninghub;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.util.Hand;
import net.minecraft.util.math.Vec3d;

import java.util.Random;

/**
 * Авто-атака.
 * - Бьёт только когда шкала урона заполнена полностью (+1 тик запаса на задержку сети).
 * - Критические удары: в прыжке ждёт начала падения.
 * - Легит-режим: бьёт только того, на кого направлен прицел, со случайной задержкой реакции.
 * - Считает, сколько ударов реально прошло, и замечает, если сервер скрывает HP врагов.
 */
public final class AutoAttack {
	private static final Random RNG = new Random();

	/** Последняя атакованная цель - нужна для Таргет-HUD. */
	public static LivingEntity lastTarget = null;
	public static long lastTargetTime = 0L;

	/** Статистика для Таргет-HUD. */
	public static int sent = 0;
	public static int landed = 0;
	/** Сколько раз подряд цель "краснела" от удара, а HP не менялось (сервер скрывает HP). */
	public static int hiddenHp = 0;

	private static int ticks = 0;
	private static int pause = 0;
	private static int reaction = -1;
	private static int critWait = 0;

	private static LivingEntity pendingTarget = null;
	private static float pendingHp = 0f;
	private static int pendingAt = 0;
	private static boolean pendingHurt = false;

	public static void tick(MinecraftClient mc) {
		ticks++;
		trackHit();

		Config.Settings s = Config.S;
		if (!s.autoAttack) {
			reaction = -1;
			critWait = 0;
			return;
		}

		ClientPlayerEntity p = mc.player;
		if (p == null || mc.world == null || mc.interactionManager == null) return;
		if (mc.currentScreen != null) return;
		if (!p.isAlive() || p.isSpectator() || p.isUsingItem()) return;

		if (pause > 0) {
			pause--;
			return;
		}

		// Шкала урона заполнена полностью + 1 тик запаса: сервер считает свою шкалу отдельно,
		// и при задержке удар по "почти полной" шкале теряет урон и крит.
		if (p.getAttackCooldownProgress(-1.0f) < 1.0f) return;

		Entity target = findTarget(mc, p, s);
		if (target == null) {
			reaction = -1;
			critWait = 0;
			return;
		}

		// Криты: в воздухе ждём, пока начнётся падение (до 14 тиков, потом бьём как есть).
		if (s.aaCrit && critPossible(p) && p.fallDistance <= 0.0 && critWait < 14) {
			critWait++;
			return;
		}
		critWait = 0;

		// Случайная "реакция" после заполнения шкалы - выглядит естественнее.
		if (reaction < 0) {
			reaction = s.aaReaction > 0 ? RNG.nextInt(s.aaReaction + 1) : 0;
		}
		if (reaction > 0) {
			reaction--;
			return;
		}
		reaction = -1;

		// Шанс попадания.
		if (RNG.nextInt(100) >= s.aaChance) {
			pause = 2 + RNG.nextInt(6);
			return;
		}

		mc.interactionManager.attackEntity(p, target);
		p.swingHand(Hand.MAIN_HAND);
		sent++;

		if (target instanceof LivingEntity le) {
			lastTarget = le;
			lastTargetTime = System.currentTimeMillis();

			if (pendingTarget != null) finishHit();
			pendingTarget = le;
			pendingHp = le.getHealth() + le.getAbsorptionAmount();
			pendingAt = ticks + 10;
			pendingHurt = false;
		}
	}

	/** Можно ли сейчас нанести критический удар (условия ванильного крита, кроме падения). */
	private static boolean critPossible(ClientPlayerEntity p) {
		return !p.isOnGround() && !p.isTouchingWater() && !p.isClimbing() && !p.hasVehicle()
				&& !p.isSprinting() && !p.hasStatusEffect(StatusEffects.BLINDNESS);
	}

	// ----------------------------------------------------------------- выбор цели

	private static Entity findTarget(MinecraftClient mc, ClientPlayerEntity p, Config.Settings s) {
		// Легитный режим: только то, на что направлен прицел (в пределах дальности).
		if (s.aaNeedAim) {
			return Targeting.aimedAt(mc, p, s.aaTargets, s.aaRange, s.aaNeedSight, true);
		}

		// Обычный режим: лучшая цель в радиусе по выбранному приоритету.
		Vec3d eye = p.getEyePos();
		Vec3d look = p.getRotationVec(1.0f);

		Entity best = null;
		double bestScore = Double.MAX_VALUE;
		for (Entity e : mc.world.getEntities()) {
			if (!Targeting.attackable(p, e, s.aaTargets)) continue;
			double dist = Targeting.reach(p, e);
			if (dist > s.aaRange) continue;
			if (s.aaNeedSight && !p.canSee(e)) continue;

			double score;
			switch (s.aaPriority) {
				case LOWEST_HP -> {
					LivingEntity le = (LivingEntity) e;
					score = le.getHealth() + le.getAbsorptionAmount();
				}
				case CROSSHAIR -> {
					Vec3d to = Targeting.aimPoint(e, false).subtract(eye).normalize();
					score = Math.acos(Math.max(-1.0, Math.min(1.0, look.dotProduct(to))));
				}
				default -> score = dist;
			}
			if (score < bestScore) {
				bestScore = score;
				best = e;
			}
		}
		return best;
	}

	// ----------------------------------------------------------------- статистика попаданий

	/** Следит за последним ударом: упало ли HP цели и краснела ли она (анимация урона). */
	private static void trackHit() {
		if (pendingTarget == null) return;
		if (pendingTarget.hurtTime > 0) pendingHurt = true;
		if (ticks >= pendingAt) finishHit();
	}

	private static void finishHit() {
		LivingEntity t = pendingTarget;
		pendingTarget = null;
		if (t == null) return;

		float now = t.getHealth() + t.getAbsorptionAmount();
		boolean hpDropped = !t.isAlive() || now < pendingHp - 0.01f;

		if (hpDropped || pendingHurt) landed++;
		if (pendingHurt && !hpDropped) {
			hiddenHp++; // цель получила урон, а HP не изменилось
		} else if (hpDropped) {
			hiddenHp = 0;
		}
	}

	private AutoAttack() {
	}
}
