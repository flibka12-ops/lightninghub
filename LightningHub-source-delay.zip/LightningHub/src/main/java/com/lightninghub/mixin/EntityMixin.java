package com.lightninghub.mixin;

import com.lightninghub.Config;
import com.lightninghub.Esp;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(Entity.class)
public abstract class EntityMixin {
	/** Включает свечение (контур, виден сквозь стены) для ESP. */
	@Inject(method = "isGlowing", at = @At("HEAD"), cancellable = true)
	private void lightninghub$espGlow(CallbackInfoReturnable<Boolean> cir) {
		if (Esp.shouldGlow((Entity) (Object) this)) {
			cir.setReturnValue(true);
		}
	}

	/** Задаёт цвет контура для ESP. Если метод не найден - просто будет белый контур. */
	@Inject(method = "getTeamColorValue", at = @At("HEAD"), cancellable = true, require = 0)
	private void lightninghub$espColor(CallbackInfoReturnable<Integer> cir) {
		int color = Esp.colorFor((Entity) (Object) this);
		if (color != -1) {
			cir.setReturnValue(color);
		}
	}

	/** Расширяет хитбокс врагов для прицела: удобнее попадать, сервер проверяет только дистанцию. */
	@Inject(method = "getTargetingMargin", at = @At("RETURN"), cancellable = true, require = 0)
	private void lightninghub$hitbox(CallbackInfoReturnable<Float> cir) {
		double extra = Config.S.hitbox;
		if (extra <= 0.0) return;

		Entity self = (Entity) (Object) this;
		if (self instanceof LivingEntity && self != MinecraftClient.getInstance().player) {
			cir.setReturnValue(cir.getReturnValue() + (float) extra);
		}
	}
}
