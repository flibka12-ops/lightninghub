package com.lightninghub;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.Hand;

import java.util.Random;

/**
 * Авто-атака. Бьёт только когда шкала урона полностью заполнена (максимальный урон).
 * Легитный режим: бьёт только того, на кого направлен прицел, со случайной задержкой реакции.
 */
public final class AutoAttack {
	private static final Random RNG = new Random();

	/** Последняя атакованная цель - нужна для Таргет-HUD. */
	public static LivingEntity lastTarget = null;
	public static long lastTargetTime = 0L;

	private static int pause = 0;
	private static int reaction = -1;

	public static void tick(MinecraftClient mc) {
		Config.Settings s = Config.S;
		if (!s.autoAttack) return;

		ClientPlayerEntity player = mc.player;
		if (player == null || mc.world == null || mc.interactionManager == null) return;
		if (mc.currentScreen != null) return;
		if (!player.isAlive() || player.isSpectator() || player.isUsingItem()) return;

		if (pause > 0) {
			pause--;
			return;
		}

		// Ждём полного заполнения шкалы урона.
		if (player.getAttackCooldownProgress(0.5f) < 1.0f) return;

		Entity target = findTarget(mc, player, s);
		if (target == null) {
			reaction = -1;
			return;
		}

		// Случайная "реакция" после заполнения шкалы - выглядит естественнее.
		if (reaction < 0) {
			reaction = s.aaReaction > 0 ? RNG.nextInt(s.aaReaction + 1) : 0;
		}
		if (reaction > 0) {
			reaction--;
			return;
		}
		reaction = -1;

		// Шанс попадания.
		if (RNG.nextInt(100) >= s.aaChance) {
			pause = 2 + RNG.nextInt(6);
			return;
		}

		mc.interactionManager.attackEntity(player, target);
		player.swingHand(Hand.MAIN_HAND);

		if (target instanceof LivingEntity le) {
			lastTarget = le;
			lastTargetTime = System.currentTimeMillis();
		}
	}

	private static Entity findTarget(MinecraftClient mc, ClientPlayerEntity player, Config.Settings s) {
		// Легитный режим: только то, на что смотрит прицел.
		if (s.aaNeedAim) {
			Entity e = mc.targetedEntity;
			if (e != null && Targeting.valid(player, e, s.aaTargets) && player.distanceTo(e) <= s.aaRange) {
				return e;
			}
			return null;
		}

		// Обычный режим: ближайшая цель в радиусе.
		Entity best = null;
		double bestDist = Double.MAX_VALUE;
		for (Entity e : mc.world.getEntities()) {
			if (!Targeting.valid(player, e, s.aaTargets)) continue;
			double dist = player.distanceTo(e);
			if (dist > s.aaRange || dist >= bestDist) continue;
			if (s.aaNeedSight && !player.canSee(e)) continue;
			best = e;
			bestDist = dist;
		}
		return best;
	}

	private AutoAttack() {
	}
}
