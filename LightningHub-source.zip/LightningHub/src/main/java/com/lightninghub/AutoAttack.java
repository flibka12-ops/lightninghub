package com.lightninghub;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.decoration.ArmorStandEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.Hand;

import java.util.Random;

/** Авто-атака: бьёт ближайшую цель только когда шкала урона полностью заполнена. */
public final class AutoAttack {
	private static final Random RNG = new Random();
	/** Пауза (в тиках) после "промаха" по шансу. */
	private static int pause = 0;

	public static void tick(MinecraftClient mc) {
		if (!Config.autoAttack) return;

		ClientPlayerEntity player = mc.player;
		if (player == null || mc.world == null || mc.interactionManager == null) return;
		if (mc.currentScreen != null) return;
		if (!player.isAlive() || player.isSpectator() || player.isUsingItem()) return;

		if (pause > 0) {
			pause--;
			return;
		}

		// Ждём, пока шкала урона заполнится на 100% - тогда удар максимальный.
		if (player.getAttackCooldownProgress(0.5f) < 1.0f) return;

		Entity target = findTarget(mc, player);
		if (target == null) return;

		// Шанс попадания: бросаем кубик каждый раз, когда удар готов.
		if (RNG.nextInt(100) >= Config.autoAttackChance) {
			pause = 2 + RNG.nextInt(6);
			return;
		}

		mc.interactionManager.attackEntity(player, target);
		player.swingHand(Hand.MAIN_HAND);
	}

	private static Entity findTarget(MinecraftClient mc, ClientPlayerEntity player) {
		Entity best = null;
		double bestDist = Double.MAX_VALUE;

		for (Entity e : mc.world.getEntities()) {
			if (!(e instanceof LivingEntity living)) continue;
			if (e == player || e instanceof ArmorStandEntity) continue;
			if (!living.isAlive() || living.isSpectator()) continue;
			if (Config.autoAttackTargets == Config.Targets.PLAYERS && !(e instanceof PlayerEntity)) continue;

			double dist = player.distanceTo(e);
			if (dist > Config.autoAttackRange || dist >= bestDist) continue;
			if (Config.autoAttackNeedSight && !player.canSee(e)) continue;

			best = e;
			bestDist = dist;
		}
		return best;
	}

	private AutoAttack() {
	}
}
