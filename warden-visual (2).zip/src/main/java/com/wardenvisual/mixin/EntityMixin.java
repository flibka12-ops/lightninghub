package com.wardenvisual.mixin;

import com.wardenvisual.Diag;
import com.wardenvisual.Features;
import com.wardenvisual.Targets;
import net.minecraft.entity.Entity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Echo Chams: forces the vanilla glow outline (visible through walls) with our color, within a distance cap. */
@Mixin(Entity.class)
public abstract class EntityMixin {
    @Inject(method = "isGlowing", at = @At("HEAD"), cancellable = true, require = 0)
    private void wardenvisual$glow(CallbackInfoReturnable<Boolean> cir) {
        if (Features.CHAMS.on && Targets.chams((Entity) (Object) this)) {
            Diag.glow++;
            cir.setReturnValue(true);
        }
    }

    @Inject(method = "getTeamColorValue", at = @At("HEAD"), cancellable = true, require = 0)
    private void wardenvisual$color(CallbackInfoReturnable<Integer> cir) {
        if (Features.CHAMS.on && Targets.chams((Entity) (Object) this)) {
            cir.setReturnValue(Features.CHAMS.col.rgb());
        }
    }
}
